create view REPORT_OFF_PAR_GRADE as
select count(*) count_,
       P.G id_grade,
       P.GRADE lib_grade
from PAM_OFF_2024 P
group by P.G, P.GRADE
order by P.G
/

