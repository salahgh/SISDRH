create view REPORT_POSTE_REALISE as
select
    postOff.POSTE,
    postOff.SOMME as TED,
    realise.count_ as REALISE_ ,
    TO_CHAR(realise.count_ / postOff.SOMME * 100 , '999') as pourcentage
from POSTE_OFF_TED_2022 postOff left JOIN (
    select
        count(p.MATRICULE) as count_ ,
        rhPoste.ID_POSTE ,
        TRIE_
    from RH_POSTE rhPoste
             left join PAM_OFF_2024 p on rhPoste.ID_POSTE = p.POSTE
    group by rhPoste.ID_POSTE , TRIE_
    order by TRIE_
) realise on realise.ID_POSTE = postOff.POSTE order by realise.TRIE_
/

