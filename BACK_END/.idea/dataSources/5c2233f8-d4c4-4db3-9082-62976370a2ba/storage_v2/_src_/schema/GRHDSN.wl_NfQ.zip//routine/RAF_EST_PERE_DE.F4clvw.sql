create PROCEDURE       RAF_EST_PERE_DE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_PERE_DE@DBL235 where raf='N' and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_PERE_DE  
where  ID_ENF=vcur.ID_ENF and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_PERE_DE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_PERE_DE  
(  ID_ENF ,APC ,PNOM_ENF ,DN_ENF ,PNOMA_ENF ,OBS ,SEX ,REF_BORD ,D_REF_BORD ,MATRICULE ,ID_CONJOIN )  
values(  vcur.ID_ENF ,vcur.APC ,vcur.PNOM_ENF ,vcur.DN_ENF ,vcur.PNOMA_ENF ,vcur.OBS ,vcur.SEX ,vcur.REF_BORD ,vcur.D_REF_BORD ,vcur.MATRICULE ,vcur.ID_CONJOIN 
) ; 
end if ;
else 
update  EST_PERE_DE set  
APC=vcur.APC,
PNOM_ENF=vcur.PNOM_ENF,
DN_ENF=vcur.DN_ENF,
PNOMA_ENF=vcur.PNOMA_ENF,
OBS=vcur.OBS,
SEX=vcur.SEX,
REF_BORD=vcur.REF_BORD,
D_REF_BORD=vcur.D_REF_BORD
where  ID_ENF=vcur.ID_ENF and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ; 
end if ;
else
delete from EST_PERE_DE   
where  ID_ENF=vcur.ID_ENF and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_PERE_DE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_PERE_DE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

