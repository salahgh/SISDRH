create PROCEDURE       RAF_MISE_ROUTE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.MISE_ROUTE@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from MISE_ROUTE  
whe
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.MISE_ROUTE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into MISE_ROUTE  
(  MATRICULE ,D_M_ROUTE ,N_M_ROUTE ,OBS ,CONGE ,TYPE_M_ROUTE ,D_AVIS_MUTATION ,N_AVIS_MUTATION ,FONCTION ,D_MUTATION ,CHAINE ,COMBAT_1 ,COMBAT_2 ,CARTE_MILITAIRE ,CARTE_ASSURANCE ,OLD_UNITE ,NEW_UNITE )  
values(  vcur.MATRICULE ,vcur.D_M_ROUTE ,vcur.N_M_ROUTE ,vcur.OBS ,vcur.CONGE ,vcur.TYPE_M_ROUTE ,vcur.D_AVIS_MUTATION ,vcur.N_AVIS_MUTATION ,vcur.FONCTION ,vcur.D_MUTATION ,vcur.CHAINE ,vcur.COMBAT_1 ,vcur.COMBAT_2 ,vcur.CARTE_MILITAIRE ,vcur.CARTE_ASSURANCE ,vcur.OLD_UNITE ,vcur.NEW_UNITE 
) ; 
end if ;
else 
update  MISE_ROUTE set  

N_M_ROUTE=vcur.N_M_ROUTE,
OBS=vcur.OBS,
CONGE=vcur.CONGE,
TYPE_M_ROUTE=vcur.TYPE_M_ROUTE,
D_AVIS_MUTATION=vcur.D_AVIS_MUTATION,
N_AVIS_MUTATION=vcur.N_AVIS_MUTATION,
FONCTION=vcur.FONCTION,
D_MUTATION=vcur.D_MUTATION,
CHAINE=vcur.CHAINE,
COMBAT_1=vcur.COMBAT_1,
COMBAT_2=vcur.COMBAT_2,
CARTE_MILITAIRE=vcur.CARTE_MILITAIRE,
CARTE_ASSURANCE=vcur.CARTE_ASSURANCE,
OLD_UNITE=vcur.OLD_UNITE,
NEW_UNITE=vcur.NEW_UNITE
where MATRICULE=vcur.MATRICULE and D_M_ROUTE=vcur.D_M_ROUTE
 ; 
end if ;
else
delete from MISE_ROUTE   
where MATRICULE=vcur.MATRICULE and D_M_ROUTE=vcur.D_M_ROUTE
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.MISE_ROUTE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.MISE_ROUTE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

