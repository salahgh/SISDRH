create view BILAN_SIT_GLOBAL_ASS as
SELECT LIB_CSN_AR AS CSN,
          CSN AS C,
          "GM",
          "GEN",
          "COL",
          "LT-COL",
          "CDT",
          "CNE",
          "LT",
          "S-LT",
          "S-LT-A",
          "ASP",
          "EOC",
          "EOA",
          "ADJ_MAJ",
          "ADJ-C",
          "ADJ",
          "SEG-C-A",
          "SEG-C-C",
          "SEG-A",
          "SEG-C",
          "ESOC",
          "SEG-APP",
          "ESOA",
          "CAP-C",
          "CAP",
          "EG",
          "DJ",
          "E-DJ",
          "CAP-C-A",
          "CAP-A",
          "EG-A",
          "DJ-A",
          "E-DJ-A",
          "PCA",
          "PCC"
     FROM (  SELECT C.LIB_CSN_AR, S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE, P.GRADE, P.CSN
                               FROM GRHDSN.PERSONNELS P
                              WHERE     /*(   P.POSITION LIKE '1%'
                                         OR P.POSITION LIKE '2%'
                                         OR P.POSITION LIKE '3%')
                                    AND*/ P.POSITION LIKE '1%'
                                    /*AND P.ARME NOT IN ('31', '42', '94')*/) PIVOT (COUNT (
                                                                                    MATRICULE)
                                                                          FOR GRADE
                                                                          IN  ('16' AS "GM",
                                                                              '18' AS "GEN",
                                                                              '22' AS "COL",
                                                                              '24' AS "LT-COL",
                                                                              '26' AS "CDT",
                                                                              '31' AS "CNE",
                                                                              '33' AS "LT",
                                                                              '35' AS "S-LT",
                                                                              '39' AS "EOA",
                                                                              '60' AS "S-LT-A",
                                                                              '62' AS "ASP",
                                                                              '64' AS "EOC",
                                                                              '40' AS "ADJ_MAJ",
                                                                              '41' AS "ADJ-C",
                                                                              '43' AS "ADJ",
                                                                              '44' AS "SEG-C-A",
                                                                              '45' AS "SEG-C-C",
                                                                              '46' AS "SEG-A",
                                                                              '47' AS "SEG-C",
                                                                              '49' AS "ESOC",
                                                                              '70' AS "SEG-APP",
                                                                              '72' AS "ESOA",
                                                                              '52' AS "CAP-C",
                                                                              '54' AS "CAP",
                                                                              '55' AS "EG",
                                                                              '56' AS "DJ",
                                                                              '58' AS "E-DJ",
                                                                              '80' AS "CAP-C-A",
                                                                              '82' AS "CAP-A",
                                                                              '83' AS "EG-A",
                                                                              '84' AS "DJ-A",
                                                                              '86' AS "E-DJ-A",
                                                                              '90' AS "PCA",
                                                                              '91' AS "PCC"))) S,
                    GRHDSN.R_CSN C
              WHERE C.CSN = S.CSN
           ORDER BY C.CSN)
/

