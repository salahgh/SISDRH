create PROCEDURE       RAF_EST_DIVORCER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_DIVORCER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_DIVORCER  
where  D_DIVORCE=vcur.D_DIVORCE and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_DIVORCER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_DIVORCER  
(  N_ACT_DIVORCE ,D_DIVORCE ,ID_CONJOIN ,REF_BORD ,D_REF_BORD ,OBS ,REF_AVIS_DIV ,D_REF_AVIS_DIV ,APC ,D_INSC_DIV ,MATRICULE )  
values(  vcur.N_ACT_DIVORCE ,vcur.D_DIVORCE ,vcur.ID_CONJOIN ,vcur.REF_BORD ,vcur.D_REF_BORD ,vcur.OBS ,vcur.REF_AVIS_DIV ,vcur.D_REF_AVIS_DIV ,vcur.APC ,vcur.D_INSC_DIV ,vcur.MATRICULE 
) ; 
end if ;
else 
update  EST_DIVORCER set  
N_ACT_DIVORCE=vcur.N_ACT_DIVORCE,
REF_BORD=vcur.REF_BORD,
D_REF_BORD=vcur.D_REF_BORD,
OBS=vcur.OBS,
REF_AVIS_DIV=vcur.REF_AVIS_DIV,
D_REF_AVIS_DIV=vcur.D_REF_AVIS_DIV,
APC=vcur.APC,
D_INSC_DIV=vcur.D_INSC_DIV
where  D_DIVORCE=vcur.D_DIVORCE and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ; 
end if ;
else
delete from EST_DIVORCER   
where  D_DIVORCE=vcur.D_DIVORCE and MATRICULE=vcur.MATRICULE and ID_CONJOIN=vcur.ID_CONJOIN 
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_DIVORCER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_DIVORCER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

