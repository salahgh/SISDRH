create PROCEDURE       RAF_PERMANENCE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.PERMANENCE@DBL235 where raf<>'O'   and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from PERMANENCE  
where  MATRICULE=vcur.MATRICULE and D_PERM=vcur.D_PERM 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.PERMANENCE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into PERMANENCE  
(  MATRICULE ,D_PERM ,POSTE ,OBS ,F_PERM )  
values(  vcur.MATRICULE ,vcur.D_PERM ,vcur.POSTE ,vcur.OBS ,vcur.F_PERM 
) ; 
end if ;
else 
update  PERMANENCE set  
POSTE=vcur.POSTE,
OBS=vcur.OBS,
F_PERM=vcur.F_PERM
where  MATRICULE=vcur.MATRICULE and D_PERM=vcur.D_PERM 
 ; 
end if ;
else
delete from PERMANENCE   
where  MATRICULE=vcur.MATRICULE and D_PERM=vcur.D_PERM 
 ; 
 ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.PERMANENCE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.PERMANENCE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

