create trigger DEM_MIS_TRG
    before insert
    on DEMANDE_MISSION
    for each row
BEGIN
-- For Toad:  Highlight column ID_CONJOIN
IF :new.N_DEMANDE IS NULL THEN
  :new.N_DEMANDE := DEM_MIS_SEQ.nextval;
  END IF;
END DEM_MIS_TRG;
/

