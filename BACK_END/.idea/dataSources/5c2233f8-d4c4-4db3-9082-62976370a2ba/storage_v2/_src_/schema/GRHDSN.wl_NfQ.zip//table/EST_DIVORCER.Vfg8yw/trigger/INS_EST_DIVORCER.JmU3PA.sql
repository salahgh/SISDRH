create trigger INS_EST_DIVORCER
    before insert
    on EST_DIVORCER
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_INSC_DIV', :old.D_INSC_DIV, :new.D_INSC_DIV, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'REF_AVIS_DIV', :old.REF_AVIS_DIV, :new.REF_AVIS_DIV, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_REF_AVIS_DIV', :old.D_REF_AVIS_DIV, :new.D_REF_AVIS_DIV, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'APC', :old.APC, :new.APC, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'N_ACT_DIVORCE', :old.N_ACT_DIVORCE, :new.N_ACT_DIVORCE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_DIVORCE', :old.D_DIVORCE, :new.D_DIVORCE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'ID_CONJOIN', :old.ID_CONJOIN, :new.ID_CONJOIN, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'REF_BORD', :old.REF_BORD, :new.REF_BORD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_REF_BORD', :old.D_REF_BORD, :new.D_REF_BORD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'OBS', :old.OBS, :new.OBS, 'INS'); End;

/

