create view BILAN_SIT_GRADE_ARME as
SELECT LIB_ARME_AR AS ARME,
          "لواء",
          "عميد",
          "عقيد",
          "مقدم",
          "رائد",
          "نقيب",
          "ملازم أول",
          "ملازم",
          "ع ض ط",
          "مساعد أول",
          "مساعد",
          "رقيب أول عامل",
          "رقيب أول متعاقد",
          "رقيب عامل",
          "رقيب متعاقد",
          "ط ض ص م",
          "عريف أول",
          "عريف",
          "طالب رتيب",
          "جندي",
          "طالب جندي"
     FROM (  SELECT A.LIB_ARME_AR, S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE, P.GRADE, P.ARME
                               FROM GRHDSN.PERSONNELS P
                              WHERE     P.POSITION LIKE '1%'
                                    AND GRADE BETWEEN 1 AND 59) PIVOT (COUNT (
                                                                          MATRICULE)
                                                                FOR GRADE
                                                                IN  ('16' AS "لواء",
                                                                    '18' AS "عميد",
                                                                    '22' AS "عقيد",
                                                                    '24' AS "مقدم",
                                                                    '26' AS "رائد",
                                                                    '31' AS "نقيب",
                                                                    '33' AS "ملازم أول",
                                                                    '35' AS "ملازم",
                                                                    '39' AS "ع ض ط",
                                                                    '41' AS "مساعد أول",
                                                                    '43' AS "مساعد",
                                                                    '44' AS "رقيب أول عامل",
                                                                    '45' AS "رقيب أول متعاقد",
                                                                    '46' AS "رقيب عامل",
                                                                    '47' AS "رقيب متعاقد",
                                                                    '49' AS "ط ض ص م",
                                                                    '52' AS "عريف أول",
                                                                    '54' AS "عريف",
                                                                    '55' AS "طالب رتيب",
                                                                    '56' AS "جندي",
                                                                    '58' AS "طالب جندي"))) S,
                    GRHDSN.R_ARME A
              WHERE A.ARME = S.ARME
           ORDER BY A.ARME)
/

