create FUNCTION        GET_DRIVER (mat$o NUMBER)
   RETURN INT
IS
   ch1   INT;
BEGIN
   ch1 := 0;

   SELECT MAX (COMPTE)
     INTO ch1
     FROM (SELECT COUNT (1) AS COMPTE
             FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
            WHERE     A.MATRICULE = mat$o
                  AND A.FONCT = F.FONCTION
                  AND F.LIB_FONCTION_AR LIKE '%سائق%'
           UNION
           SELECT COUNT (1) AS COMPTE
             FROM GRHDSN.EST_AFFECT A
            WHERE A.MATRICULE = mat$o AND A.FONCT_DET LIKE '%سائق%');

   RETURN (ch1);
END GET_DRIVER;
/

