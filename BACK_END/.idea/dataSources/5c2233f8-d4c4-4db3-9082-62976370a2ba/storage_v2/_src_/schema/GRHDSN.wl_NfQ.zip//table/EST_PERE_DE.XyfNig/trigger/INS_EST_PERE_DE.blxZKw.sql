create trigger INS_EST_PERE_DE
    before insert
    on EST_PERE_DE
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'REF_BORD', :old.REF_BORD, :new.REF_BORD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'D_REF_BORD', :old.D_REF_BORD, :new.D_REF_BORD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'ID_CONJOIN', :old.ID_CONJOIN, :new.ID_CONJOIN, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'ID_ENF', :old.ID_ENF, :new.ID_ENF, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'APC', :old.APC, :new.APC, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'PNOM_ENF', :old.PNOM_ENF, :new.PNOM_ENF, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'DN_ENF', :old.DN_ENF, :new.DN_ENF, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'PNOMA_ENF', :old.PNOMA_ENF, :new.PNOMA_ENF, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'OBS', :old.OBS, :new.OBS, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_PERE_DE', 'SEX', :old.SEX, :new.SEX, 'INS'); End;

/

