create FUNCTION        GET_LAST_YEAR_MUT_V2 (MAT IN VARCHAR2)
   RETURN INTEGER
IS
   CURSOR CUR
   IS
        SELECT M.UNITEE,
               M.D_MUTATION,
               M.STAGE,
               C.UNITE,
               SUBSTR (C.CSN, 1, 2) AS STR
          FROM GRHDSN.EST_MUTER M,
               (SELECT * FROM GRHDSN.R_CSN
                UNION
                SELECT * FROM GRHDSN.R_CSN_OLD) C
         WHERE M.MATRICULE = MAT AND C.UNITE(+) = M.UNITEE
      ORDER BY M.D_MUTATION DESC;

   V$RESULTAT   INTEGER := 0;
   V$I          INTEGER := 0;
   V$STR        VARCHAR2 (10);
   V$D_MUT      DATE;
BEGIN
   FOR C IN CUR
   LOOP
      IF (C.STAGE != 1 OR C.STAGE IS NULL) AND V$I = 0
      THEN
         V$STR := C.STR;
         V$RESULTAT := 2024 - TO_CHAR (C.D_MUTATION, 'YYYY');
         V$I := 1;
         V$D_MUT := C.D_MUTATION;
      ELSE
         IF V$I = 1 AND C.STAGE != 1 OR C.STAGE IS NULL
         THEN
            IF V$STR = C.STR
            THEN
               IF (TO_CHAR (V$D_MUT, 'YYYY') - TO_CHAR (C.D_MUTATION, 'YYYY') =
                      0)
               THEN
                  V$RESULTAT :=
                       V$RESULTAT
                     + TO_CHAR (V$D_MUT, 'YYYY')
                     - TO_CHAR (C.D_MUTATION, 'YYYY')
                     + 1;
               ELSE
                  V$RESULTAT :=
                       V$RESULTAT
                     + TO_CHAR (V$D_MUT, 'YYYY')
                     - TO_CHAR (C.D_MUTATION, 'YYYY');
               END IF;

               V$D_MUT := C.D_MUTATION;
            ELSE
               V$I := 2;
            END IF;
         ELSE
            V$D_MUT := C.D_MUTATION;
         END IF;
      END IF;
   END LOOP;

   RETURN V$RESULTAT;
END;
/

