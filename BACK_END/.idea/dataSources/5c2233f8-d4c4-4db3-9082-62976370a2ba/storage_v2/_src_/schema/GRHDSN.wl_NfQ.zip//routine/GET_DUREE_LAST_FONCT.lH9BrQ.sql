create FUNCTION        GET_DUREE_LAST_FONCT (MAT IN VARCHAR2)
    RETURN INTEGER
IS
    CURSOR CUR IS
        SELECT FONCT, D_AFFECTATION
          FROM (SELECT ROWNUM R, AA.*
                  FROM (  SELECT A.FONCT, A.D_AFFECTATION
                            FROM GRHDSN.EST_AFFECT A
                           WHERE A.MATRICULE = MAT AND A.TYPE_FONCT = '0'
                        ORDER BY A.D_AFFECTATION DESC) AA)
         WHERE R < 3;

    V$RESULTAT   INTEGER := 0;
    V$FONCT      VARCHAR2 (13);
    V$I          INTEGER := 0;
BEGIN
    FOR C IN CUR
    LOOP
        IF V$I = 0
        THEN
            V$RESULTAT := TO_DATE ('16/09/2024') - C.D_AFFECTATION;
            V$FONCT := C.FONCT;
            V$I := 1;
        ELSE
            IF GRHDSN.VERIF_AVANT_LAST_FONCT(V$FONCT, C.FONCT) >  0
            THEN
                V$RESULTAT := TO_DATE ('16/09/2024') - C.D_AFFECTATION;
            END IF;
        END IF;
    END LOOP;

    RETURN V$RESULTAT;
END;
/

