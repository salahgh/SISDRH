create trigger MAJ_EST_DIVORCER
    before update
    on EST_DIVORCER
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'OBS', :old.OBS, :new.OBS, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_REF_BORD', :old.D_REF_BORD, :new.D_REF_BORD, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'REF_BORD', :old.REF_BORD, :new.REF_BORD, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'ID_CONJOIN', :old.ID_CONJOIN, :new.ID_CONJOIN, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_DIVORCE', :old.D_DIVORCE, :new.D_DIVORCE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'N_ACT_DIVORCE', :old.N_ACT_DIVORCE, :new.N_ACT_DIVORCE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'APC', :old.APC, :new.APC, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_REF_AVIS_DIV', :old.D_REF_AVIS_DIV, :new.D_REF_AVIS_DIV, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'REF_AVIS_DIV', :old.REF_AVIS_DIV, :new.REF_AVIS_DIV, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DIVORCER', 'D_INSC_DIV', :old.D_INSC_DIV, :new.D_INSC_DIV, 'MAJ'); End;

/

