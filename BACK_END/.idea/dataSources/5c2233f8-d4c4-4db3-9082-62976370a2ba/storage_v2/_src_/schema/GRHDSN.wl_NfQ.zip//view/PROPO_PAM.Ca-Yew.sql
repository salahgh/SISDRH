create view PROPO_PAM as
SELECT "MATRICULE","MAT","NOMA","PNOMA","GRADE","G","LIB_ARME_AR","CSN","C","DUREE_N","DUREE","FONCTION","SUD","DUREE_S"
    FROM (  SELECT TO_CHAR (
                         SUBSTR (P.MATRICULE, 0, 4)
                      || '.'
                      || SUBSTR (P.MATRICULE, 5, 3)
                      || '.'
                      || SUBSTR (P.MATRICULE, 8, 5))
                      AS MATRICULE,
                   P.MATRICULE AS MAT,
                   P.NOMA,
                   P.PNOMA,
                   G.LIB_GRADE_AR AS GRADE,
                   G.GRADE AS G,
                   A.LIB_ARME_AR,
                      'م.خ.و / '
                   || DECODE (C.REGION, 'و.د.و', 'و.د.و', C.WILAYA)
                      AS CSN,
                   P.CSN AS C,
                   GRHDSN.GET_LAST_YEAR_MUT_V2 (P.MATRICULE) AS DUREE_N,
                   DECODE (
                      GRHDSN.GET_LAST_YEAR_MUT_V2 (P.MATRICULE),
                      NULL, 'سنة واحدة',
                      '1', 'سنة واحدة',
                      '2', 'سنتين',
                      GRHDSN.GET_LAST_YEAR_MUT_V2 (P.MATRICULE) || ' سنوات')
                      AS DUREE,
                   RF.LIB_FONCTION_AR AS FONCTION,
                   DECODE (GRHDSN.GET_SUD (P.MATRICULE),
                           'Y', 'نعم',
                           'N', 'لا',
                           '/')
                      AS SUD,
                      DECODE (
                      GRHDSN.GET_DUREE_SUD (P.MATRICULE),
                      NULL, 'سنة واحدة',
                      '1', 'سنة واحدة',
                      '2', 'سنتين',
                      GRHDSN.GET_DUREE_SUD (P.MATRICULE) || ' سنوات')
                      AS  DUREE_S
              FROM GRHDSN.PERSONNELS P,
                   GRHDSN.R_GRADE G,
                   GRHDSN.R_ARME A,
                   GRHDSN.R_CSN C,
                   GRHDSN.EST_AFFECT AF,
                   GRHDSN.R_FONCT RF
             WHERE     AF.MATRICULE = P.MATRICULE
                   AND AF.D_AFFECTATION =
                          (SELECT MAX (AFF.D_AFFECTATION)
                             FROM GRHDSN.EST_AFFECT AFF
                            WHERE     AF.MATRICULE = AFF.MATRICULE
                                  AND AFF.TYPE_FONCT = '0')
                   AND AF.TYPE_FONCT = '0'
                   AND AF.FONCT = RF.FONCTION
                   AND P.GRADE = G.GRADE
                   AND P.ARME = A.ARME
                   AND SUBSTR (P.CSN, 1, 2) || '00' = C.CSN
                   /*AND (   P.GRADE BETWEEN 1 AND 39
                        OR P.GRADE LIKE '4%'
                        OR P.GRADE LIKE '5%')*/
                   --AND (G.GRADE BETWEEN 1 AND 39 OR G.GRADE LIKE '4%' OR G.GRADE LIKE '5%')
                   AND P.GRADE BETWEEN 1 AND 39
                   AND P.POSITION LIKE '1%'
                   AND P.ARME NOT IN ('31', '42', '94')
          --AND SUBSTR (P.CSN, 1, 2) = '51'
          ORDER BY SUBSTR (P.CSN, 1, 2), G.GRADE, P.MATRICULE)
   WHERE    (DUREE_N >= 4 AND C NOT IN ('3101', '3137', '4133', '6198', '6199'))
         OR (DUREE_N >= 3 AND C IN ('3101', '3137', '4133', '6198', '6199')) --AND C != '0000'
ORDER BY C, G, DUREE_N
/

