create FUNCTION        "CREATE_TRIGGER" (V$TABLE    VARCHAR2,
                                                  V$OP       VARCHAR2,
                                                  V$TRAIT    VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
        SELECT T.TABLE_NAME, C.COLUMN_NAME
          FROM SYS.ALL_TABLES T, SYS.ALL_TAB_COLUMNS C
         WHERE     T.OWNER = 'GRHDSN'
               AND T.TABLE_NAME = V$TABLE
               AND C.TABLE_NAME = T.TABLE_NAME
               AND C.OWNER = T.OWNER
      ORDER BY T.TABLE_NAME;

   V$RESULTAT   VARCHAR2 (10000) := '';
BEGIN
   FOR P IN TAB
   LOOP
      V$RESULTAT :=
            V$RESULTAT
         || 'P_CPR(:new.MATRICULE,x$user,'
         || ''''
         ||P.TABLE_NAME
         || ''''
         || ', '
         || ''''
         ||P.COLUMN_NAME
         || ''''
         || ', :old.'
         || P.COLUMN_NAME
         || ', :new.'
         || P.COLUMN_NAME
         || ', '''
         || V$OP
         || ''');';
   END LOOP;
   V$RESULTAT := V$RESULTAT || ' End;';
   RETURN V$RESULTAT;
END;
/

