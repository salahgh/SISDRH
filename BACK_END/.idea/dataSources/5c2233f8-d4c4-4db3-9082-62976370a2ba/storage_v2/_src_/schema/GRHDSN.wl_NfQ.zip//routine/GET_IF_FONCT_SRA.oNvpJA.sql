create FUNCTION        GET_IF_FONCT_SRA (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   RESPONSE   VARCHAR (50);
   COMPTE     INT;
BEGIN
   SELECT COUNT (1)
     INTO COMPTE
     FROM GRHDSN.EST_AFFECT A
    WHERE     A.MATRICULE = MAT
          AND (   A.FONCT LIKE '012018%'
               OR A.FONCT LIKE '012028%'
               OR A.FONCT LIKE '013018%'
               OR A.FONCT LIKE '013028%'
               OR A.FONCT LIKE '013038%'
               OR A.FONCT LIKE '014018%'
               OR A.FONCT LIKE '015018%'
               OR A.FONCT LIKE '016018%'
               OR A.FONCT LIKE '016028%'
               OR A.FONCT LIKE '016038%'
               OR A.FONCT LIKE '017018%');

   IF COMPTE = 0
   THEN
      RESPONSE := '0';
   ELSE
      RESPONSE := '1';
   END IF;

   RETURN RESPONSE;
END;
/

