create FUNCTION        GET_IF_FONCT_SOSN (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   RESPONSE   VARCHAR (50);
   COMPTE     INT;
BEGIN
   SELECT COUNT (1)
     INTO COMPTE
     FROM GRHDSN.EST_AFFECT A
    WHERE     A.MATRICULE = MAT
          AND (   A.FONCT LIKE '012017%'
               OR A.FONCT LIKE '012027%'
               OR A.FONCT LIKE '013017%'
               OR A.FONCT LIKE '013027%'
               OR A.FONCT LIKE '013037%'
               OR A.FONCT LIKE '014017%'
               OR A.FONCT LIKE '015017%'
               OR A.FONCT LIKE '016017%'
               OR A.FONCT LIKE '016027%'
               OR A.FONCT LIKE '016037%'
               OR A.FONCT LIKE '017017%');

   IF COMPTE = 0
   THEN
      RESPONSE := '0';
   ELSE
      RESPONSE := '1';
   END IF;

   RETURN RESPONSE;
END;
/

