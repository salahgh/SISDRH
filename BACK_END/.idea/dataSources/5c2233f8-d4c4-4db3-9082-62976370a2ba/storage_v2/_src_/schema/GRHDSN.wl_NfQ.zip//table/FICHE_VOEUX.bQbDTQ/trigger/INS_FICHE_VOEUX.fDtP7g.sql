create trigger INS_FICHE_VOEUX
    after insert
    on FICHE_VOEUX
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'FICHE_VOEUX';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request := REPLACE (x$request, 'V$ANNEE', :new.ANNEE);
      x$request := REPLACE (x$request, 'V$UNITE_1', :new.UNITE_1);
      x$request := REPLACE (x$request, 'V$UNITE_2', :new.UNITE_2);
      x$request := REPLACE (x$request, 'V$UNITE_3', :new.UNITE_3);
      x$request := REPLACE (x$request, 'V$OBS_1', '''' || :new.OBS_1 || '''');
      x$request := REPLACE (x$request, 'V$OBS_2', '''' || :new.OBS_2 || '''');
      x$request := REPLACE (x$request, 'V$OBS_3', '''' || :new.OBS_3 || '''');
      x$request :=
         REPLACE (x$request, 'V$OBS_CHEF', '''' || :new.OBS_CHEF || '''');
      x$request :=
         REPLACE (x$request, 'V$OBS_SDRH', '''' || :new.OBS_SDRH || '''');
      x$request :=
         REPLACE (x$request, 'V$OBS_DSN', '''' || :new.OBS_DSN || '''');

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR ('-20101', 'خطأ رقم : '||C.ERR||' : '||x$message, TRUE);
      END IF;
   END LOOP;
   
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_DSN',
          :old.OBS_DSN,
          :new.OBS_DSN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_SDRH',
          :old.OBS_SDRH,
          :new.OBS_SDRH,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_CHEF',
          :old.OBS_CHEF,
          :new.OBS_CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_3',
          :old.OBS_3,
          :new.OBS_3,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_2',
          :old.OBS_2,
          :new.OBS_2,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_1',
          :old.OBS_1,
          :new.OBS_1,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_3',
          :old.UNITE_3,
          :new.UNITE_3,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_2',
          :old.UNITE_2,
          :new.UNITE_2,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_1',
          :old.UNITE_1,
          :new.UNITE_1,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'ANNEE',
          :old.ANNEE,
          :new.ANNEE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
   
END;
/

