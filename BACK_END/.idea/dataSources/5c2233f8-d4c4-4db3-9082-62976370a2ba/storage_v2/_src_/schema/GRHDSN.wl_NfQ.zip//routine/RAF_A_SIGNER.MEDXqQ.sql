create PROCEDURE       RAF_A_SIGNER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.A_SIGNER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from A_SIGNER  
where  MATRICULE=vcur.MATRICULE and D_ENG=vcur.D_ENG and GRADE=vcur.GRADE and ARME=vcur.ARME and UNITEE=vcur.UNITEE 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.A_SIGNER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into A_SIGNER  
(  MATRICULE ,D_ENG ,GRADE ,ARME ,UNITEE ,N_ACT ,D_ACT ,AVIS_ENG ,D_AVIS_ENG ,TYPE ,NIVEAU ,DUREE ,TYPE_ENG ,METHOD_ENG )  
values(  vcur.MATRICULE ,vcur.D_ENG ,vcur.GRADE ,vcur.ARME ,vcur.UNITEE ,vcur.N_ACT ,vcur.D_ACT ,vcur.AVIS_ENG ,vcur.D_AVIS_ENG ,vcur.TYPE ,vcur.NIVEAU ,vcur.DUREE ,vcur.TYPE_ENG ,vcur.METHOD_ENG 
) ; 
end if ;
else 
update  A_SIGNER set  
N_ACT=vcur.N_ACT,
D_ACT=vcur.D_ACT,
AVIS_ENG=vcur.AVIS_ENG,
D_AVIS_ENG=vcur.D_AVIS_ENG,
TYPE=vcur.TYPE,
NIVEAU=vcur.NIVEAU,
DUREE=vcur.DUREE,
TYPE_ENG=vcur.TYPE_ENG,
METHOD_ENG=vcur.METHOD_ENG
where  MATRICULE=vcur.MATRICULE and D_ENG=vcur.D_ENG and GRADE=vcur.GRADE and ARME=vcur.ARME and UNITEE=vcur.UNITEE 
 ; 
end if ;
else
delete from A_SIGNER   
where  MATRICULE=vcur.MATRICULE and D_ENG=vcur.D_ENG and GRADE=vcur.GRADE and ARME=vcur.ARME and UNITEE=vcur.UNITEE 
 ; ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.A_SIGNER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.A_SIGNER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

