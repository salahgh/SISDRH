create PROCEDURE        GET_FROM_GRHDSN (P$ID_ARCHIVE    VARCHAR2,
                                                    P$MATRICULE     VARCHAR2)
IS
   V$SQL_CODE   NUMBER;
   V$SQL_ERRM   VARCHAR2 (2000);
   V$INSERT     LONG;
BEGIN
   FOR V$TAB IN (  SELECT TABLE_NAME, COLS
                     FROM GRHDSN.ALL_TAB
                    WHERE TABLE_NAME <> 'D_MOUVEMENT_GRH'
                 ORDER BY NIVEAU)
   LOOP
      BEGIN
         V$INSERT :=
               'INSERT INTO GRHDSN.'
            || V$TAB.TABLE_NAME
            || ' ('
            || V$TAB.COLS
            || ' ) SELECT '
            || V$TAB.COLS
            || '  FROM GRH_ARCHIVE.AR_'
            || V$TAB.TABLE_NAME
            || ' WHERE ID_ARCHIVE = :1';

         EXECUTE IMMEDIATE V$INSERT USING P$ID_ARCHIVE;
      EXCEPTION
         WHEN OTHERS
         THEN
            ROLLBACK;
            V$SQL_CODE := SQLCODE;
            V$SQL_ERRM := SUBSTR (SQLERRM, 1, 2000);

            INSERT INTO GRH_ARCHIVE.A_ARCHIVE_ERROR (TABLE_NAME,
                                                     MATRICULE,
                                                     ID_ARCHIVE,
                                                     SQL_CODE,
                                                     SQL_ERRM,
                                                     OPERATION)
                 VALUES (V$TAB.TABLE_NAME,
                         P$MATRICULE,
                         P$ID_ARCHIVE,
                         V$SQL_CODE,
                         V$SQL_ERRM,
                         'INSERTION');

            COMMIT;
      END;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      V$SQL_CODE := SQLCODE;
      V$SQL_ERRM := SUBSTR (SQLERRM, 1, 2000);

      INSERT INTO GRH_ARCHIVE.A_ARCHIVE_ERROR (TABLE_NAME,
                                               MATRICULE,
                                               ID_ARCHIVE,
                                               SQL_CODE,
                                               SQL_ERRM,
                                               OPERATION)
           VALUES ('XXXXXXX',
                   P$MATRICULE,
                   P$ID_ARCHIVE,
                   V$SQL_CODE,
                   V$SQL_ERRM,
                   'INSERTION');

      COMMIT;
END;
/

