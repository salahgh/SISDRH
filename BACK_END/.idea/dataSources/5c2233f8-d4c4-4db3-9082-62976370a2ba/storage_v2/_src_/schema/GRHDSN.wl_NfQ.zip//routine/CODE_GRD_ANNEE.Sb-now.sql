create FUNCTION        CODE_GRD_ANNEE(mat$o number) RETURN varchar2 IS

ch1 varchar2(4000);
ch2 varchar2(4000);
CURSOR c1 IS select P.MATRICULE, P.GRADE, G.GRADE GRADEN, s.GRADE GRADEIN, to_char(G.D_NOMIN, 'YYYY') ANNEE_GRD, to_char(S.D_ENG , 'YYYY') ANNEE_ENG
                from GRHDSN.PERSONNELS p, GRHDSN.EST_NOMINER_G g, GRHDSN.A_SIGNER s
                where P.MATRICULE = G.MATRICULE
                AND P.MATRICULE = s.MATRICULE
                AND S.D_ENG = (SELECT MIN(SS.D_ENG) FROM GRHDSN.A_SIGNER SS WHERE S.MATRICULE = SS.MATRICULE)
                AND P.MATRICULE = mat$o
                order by P.GRADE ASC, G.GRADE ASC, to_char(G.D_NOMIN, 'YYYY'), to_char(S.D_ENG , 'YYYY');
BEGIN
    ch1 := '';
    ch1 := '';
    FOR r1 IN c1 LOOP
        ch1 := ch1 || r1.GRADEN||r1.ANNEE_GRD||'x';
        ch2 := r1.GRADEIN||r1.ANNEE_ENG;
    END LOOP;
        ch1 := ch1 || ch2||'x';
  return(ch1);
END CODE_GRD_ANNEE;
/

