create view BILAN_SIT_GLOBAL_CSN_ASS as
SELECT LIB_CSN_AR AS CSN,
          "لواء",
          "عميد",
          "عقيد",
          "مقدم",
          "رائد",
          "نقيب",
          "ملازم أول",
          "ملازم",
          "ع ض ط",
          "مساعد أول",
          "مساعد",
          "رقيب أول عامل",
          "رقيب أول متعاقد",
          "رقيب عامل",
          "رقيب متعاقد",
          "ط ض ص م",
          "عريف أول",
          "عريف",
          "طالب رتيب",
          "جندي",
          "طالب جندي",
          "م م ش",
          "م م م"
     FROM (  SELECT S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE,
                                    P.GRADE,
                                    C.LIB_CSN_AR,
                                    C.CSN
                               FROM GRHDSN.PERSONNELS P, GRHDSN.R_CSN C
                              WHERE     P.POSITION LIKE '1%' AND (P.GRADE BETWEEN 1 AND 59 OR P.GRADE LIKE '9%')
                                    AND C.CSN = SUBSTR (P.CSN, 1, 2) || '00') PIVOT (COUNT (
                                                                                        MATRICULE)
                                                                              FOR GRADE
                                                                              IN  ('16' AS "لواء",
                                                                                  '18' AS "عميد",
                                                                                  '22' AS "عقيد",
                                                                                  '24' AS "مقدم",
                                                                                  '26' AS "رائد",
                                                                                  '31' AS "نقيب",
                                                                                  '33' AS "ملازم أول",
                                                                                  '35' AS "ملازم",
                                                                                  '39' AS "ع ض ط",
                                                                                  '60' AS "ملازم إ",
                                                                                  '62' AS "مرشح إ",
                                                                                  '64' AS "ط ض إ",
                                                                                  '41' AS "مساعد أول",
                                                                                  '43' AS "مساعد",
                                                                                  '44' AS "رقيب أول عامل",
                                                                                  '45' AS "رقيب أول متعاقد",
                                                                                  '46' AS "رقيب عامل",
                                                                                  '47' AS "رقيب متعاقد",
                                                                                  '49' AS "ط ض ص م",
                                                                                  '70' AS "رقيب إحتياطي",
                                                                                  '72' AS "ط ص ض إ",
                                                                                  '52' AS "عريف أول",
                                                                                  '54' AS "عريف",
                                                                                  '55' AS "طالب رتيب",
                                                                                  '56' AS "جندي",
                                                                                  '58' AS "طالب جندي",
                                                                                  '80' AS "عريف أول إ",
                                                                                  '82' AS "عريف إ",
                                                                                  '83' AS "ط ر إ",
                                                                                  '84' AS "جندي إحتياطي",
                                                                                  '90' AS "م م ش",
                                                                                  '91' AS "م م م"))) S
           ORDER BY S.CSN)
/

