create FUNCTION        GET_INTERVAL_MUT (MAT     IN VARCHAR2,
                                                    D_MUT   IN DATE)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
        SELECT M.UNITEE,
               TO_CHAR (M.D_MUTATION, 'YYYY') AS ANNEE_MUT,
               M.D_MUTATION AS D_MUTATION
          FROM GRHDSN.EST_MUTER M
         WHERE M.MATRICULE = MAT
      ORDER BY M.D_MUTATION ASC;

   I          INTEGER := 1;
   J          INTEGER := 1;
   RESULTAT   VARCHAR2 (250);
   ANNEE      VARCHAR2 (4);
   COMPTE     INTEGER := 0;
BEGIN
   SELECT COUNT (M.MATRICULE)
     INTO COMPTE
     FROM GRHDSN.EST_MUTER M
    WHERE M.MATRICULE = MAT;

   FOR C IN CUR
   LOOP
      IF (D_MUT = C.D_MUTATION AND I = 1) OR I = 2
      THEN
         IF J < COMPTE AND I != 2
         THEN
            RESULTAT :=
               RESULTAT || '(' || TO_CHAR (C.D_MUTATION, 'YYYY') || '-';
            ANNEE := TO_CHAR (C.D_MUTATION, 'YYYY');
            J := J + 1;
            I := 2;
         ELSE
            IF I = 2
            THEN
               IF ANNEE = TO_CHAR (C.D_MUTATION, 'YYYY')
               THEN
                  RESULTAT := '(' || TO_CHAR (C.D_MUTATION, 'YYYY') || ')';
                  I := 0;
               ELSE
                  RESULTAT :=
                     RESULTAT || TO_CHAR (C.D_MUTATION, 'YYYY') || ')';
                  I := 0;
               END IF;
            ELSE
               RESULTAT := '(' || TO_CHAR (C.D_MUTATION, 'YYYY') || ')';
               I := 0;
            END IF;
         END IF;
      ELSE
         J := J + 1;
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;
/

