create PROCEDURE ins_into_D_MOUVEMENT_GRH_csn  as
V$INSERT LONG ;
V$NBR NUMBER := 0 ;
V$COL_NAME VARCHAR2(4000) ;
BEGIN

FOR V$CSN IN (  SELECT DISTINCT SUBSTR(CSN,1,2) CSN 
                FROM R_CSN 
                /*WHERE  SUBSTR(CSN,2,1) <>'0'*/)
LOOP
        BEGIN
                     V$INSERT :='INSERT INTO r_mouvement@GRHDSN'||V$CSN.CSN||' (code_mouvement,ref_mv,d_ref_mv,annee,d_debut_mv,d_fin_mv,d_echiancier_mv,cat,nature_mouvement )'||
                                'SELECT code_mouvement,ref_mv,d_ref_mv,annee,d_debut_mv,d_fin_mv,d_echiancier_mv,cat,nature_mouvement FROM r_mouvement DD  WHERE NOT EXISTS ( SELECT 1 FROM r_mouvement@GRHDSN'||V$CSN.CSN||' CC WHERE CC.code_mouvement = DD.code_mouvement) ' ;
                   EXECUTE IMMEDIATE V$INSERT;
                     FOR V$TAB IN ( SELECT  TABLE_NAME  TABLE_NAME, COLS FROM GRHDSN.ALL_TAB WHERE TABLE_NAME ='D_MOUVEMENT_GRH' ORDER BY NIVEAU )
                        LOOP
                                 BEGIN
                                
                                 V$COL_NAME   := REPLACE (V$TAB.COLS,', MV_CSN','') ; 
                                 V$INSERT :='BEGIN INSERT INTO GRHDSN.'||V$TAB.TABLE_NAME|| '@GRHDSN'||V$CSN.CSN||' ('||V$COL_NAME|| ') SELECT '|| V$COL_NAME || '  FROM GRHDSN.'||V$TAB.TABLE_NAME|| 
                                 ' CC  WHERE VALIDE =''O''  AND  NOT EXISTS ( SELECT 1 FROM GRHDSN.'||V$TAB.TABLE_NAME|| '@GRHDSN'||V$CSN.CSN||' DD WHERE  DD.ID_MOUVEMENT=CC.ID_MOUVEMENT)  AND ( CC.CSN_ARRIVE LIKE '''||V$CSN.CSN||'%'' OR CC.CSN_DEPART LIKE '''||V$CSN.CSN||'%''); :out := sql%rowcount; end ;' ;
                                 EXECUTE IMMEDIATE V$INSERT USING   OUT V$NBR;
                                 DBMS_OUTPUT.PUT_LINE('Insert count  : ' ||V$NBR||' into csn = '||V$CSN.CSN);
                                 commit;
                                 END ;
                         END LOOP;
                  EXCEPTION WHEN OTHERS THEN  
                 ROLLBACK;
         DBMS_OUTPUT.PUT_LINE('Error : ' ||sqlerrm);
        END ;
END LOOP ;
END ins_into_D_MOUVEMENT_GRH_csn ;
/

