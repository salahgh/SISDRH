create view BILAN_SIT_BETWEEN_15_19 as
SELECT DECODE (
          P.R,
          '0', 'مديرية الخدمة الوطنية/و.د.و',
             'الناحية العسكرية '
          || DECODE (P.R,
                     '1', 'الأولى',
                     '2', 'الثانية',
                     '3', 'الثالثة',
                     '4', 'الرابعة',
                     '5', 'الخامسة',
                     '6', 'السادسة',
                     NULL))
          AS REGION,
       P."رقيب أول متعاقد",
       P."رقيب متعاقد",
       P."عريف أول",
       P."عريف",
       P."جندي"
  FROM (  SELECT S.*
            FROM (SELECT *
                    FROM (SELECT P.MATRICULE, P.GRADE, U.REGION AS R
                            FROM GRHDSN.PERSONNELS P,
                                 GRHDSN.R_CSN C,
                                 GRHDSN.R_UNITEE U
                           WHERE     (   P.POSITION LIKE '1%'
                                      OR P.POSITION LIKE '2%')
                                 AND (  TO_CHAR (SYSDATE, 'YYYY')
                                      - SUBSTR (P.MATRICULE, 1, 4)) BETWEEN 15
                                                                        AND 19
                                 AND P.GRADE IN ('45', '47', '52', '54', '56')
                                 AND C.CSN = P.CSN
                                 AND U.UNITEE = C.UNITE) PIVOT (COUNT (
                                                                   MATRICULE)
                                                         FOR GRADE
                                                         IN  ('45' AS "رقيب أول متعاقد",
                                                             '47' AS "رقيب متعاقد",
                                                             '52' AS "عريف أول",
                                                             '54' AS "عريف",
                                                             '56' AS "جندي"))) S
        ORDER BY S.R) P
/

