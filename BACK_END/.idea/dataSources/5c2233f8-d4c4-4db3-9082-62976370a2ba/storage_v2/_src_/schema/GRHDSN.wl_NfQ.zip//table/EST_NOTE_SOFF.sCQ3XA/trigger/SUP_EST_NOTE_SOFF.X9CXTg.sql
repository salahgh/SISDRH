create trigger SUP_EST_NOTE_SOFF
    before delete
    on EST_NOTE_SOFF
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'EST_NOTE_SOFF';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request :=
         REPLACE (x$request, 'V$FONCTION', '''' || :new.FONCTION || '''');
      x$request := REPLACE (x$request, 'V$UNITE', :new.UNITE);
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request :=
         REPLACE (x$request,
                  'V$D_D_NOTATION',
                  '''' || :new.D_D_NOTATION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$D_F_NOTATION',
                  '''' || :new.D_F_NOTATION || '''');
      x$request := REPLACE (x$request, 'V$CAUSE_NOT', :new.CAUSE_NOT);
      x$request :=
         REPLACE (x$request,
                  'V$AUTRE_CAUSE',
                  '''' || :new.AUTRE_CAUSE || '''');
      x$request := REPLACE (x$request, 'V$PHYSIQUE', :new.PHYSIQUE);
      x$request := REPLACE (x$request, 'V$EDUCATION', :new.EDUCATION);
      x$request := REPLACE (x$request, 'V$APPARENCE', :new.APPARENCE);
      x$request := REPLACE (x$request, 'V$INTILLIGENCE', :new.INTILLIGENCE);
      x$request := REPLACE (x$request, 'V$CONVERSATION', :new.CONVERSATION);
      x$request := REPLACE (x$request, 'V$TRAVAIL', :new.TRAVAIL);
      x$request := REPLACE (x$request, 'V$MAITRISE_SOI', :new.MAITRISE_SOI);
      x$request := REPLACE (x$request, 'V$COMMANDEMENT', :new.COMMANDEMENT);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_PARTICIP', :new.ESPRIT_PARTICIP);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_COLLECT', :new.ESPRIT_COLLECT);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_DISPLINE', :new.ESPRIT_DISPLINE);
      x$request := REPLACE (x$request, 'V$PREOCCUP_SUB', :new.PREOCCUP_SUB);
      x$request := REPLACE (x$request, 'V$FORMATION_SUB', :new.FORMATION_SUB);
      x$request :=
         REPLACE (x$request, 'V$QUALITEE_INSTRCUT', :new.QUALITEE_INSTRCUT);
      x$request := REPLACE (x$request, 'V$NOTE_FONCTION', :new.NOTE_FONCTION);
      x$request :=
         REPLACE (x$request,
                  'V$AMELIOR_FONCTION',
                  '''' || :new.AMELIOR_FONCTION || '''');
      x$request := REPLACE (x$request, 'V$NOTE_GLOBAL', :new.NOTE_GLOBAL);
      x$request :=
         REPLACE (x$request, 'V$GRADE_SUP', '''' || :new.GRADE_SUP || '''');
      x$request := REPLACE (x$request, 'V$DERNIER_GRADE', :new.DERNIER_GRADE);
      x$request :=
         REPLACE (x$request, 'V$EXP_GRADE', '''' || :new.EXP_GRADE || '''');
      x$request :=
         REPLACE (x$request,
                  'V$DEPASSE_GRADE',
                  '''' || :new.DEPASSE_GRADE || '''');
      x$request :=
         REPLACE (x$request, 'V$DETAIL', '''' || :new.DETAIL || '''');
      x$request := REPLACE (x$request, 'V$APPRECIATION', :new.APPRECIATION);
      x$request := REPLACE (x$request, 'V$CHEF', '''' || :new.CHEF || '''');
      x$request := REPLACE (x$request, 'V$OBS_NOTE', :new.OBS_NOTE);
      x$request :=
         REPLACE (x$request, 'V$OBS_CHEF', '''' || :new.OBS_CHEF || '''');
      x$request :=
         REPLACE (x$request, 'V$CHEF_UNITE', '''' || :new.CHEF_UNITE || '''');

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;

   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CHEF_UNITE',
          :old.CHEF_UNITE,
          :new.CHEF_UNITE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'OBS_CHEF',
          :old.OBS_CHEF,
          :new.OBS_CHEF,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'OBS_NOTE',
          :old.OBS_NOTE,
          :new.OBS_NOTE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CHEF',
          :old.CHEF,
          :new.CHEF,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'APPRECIATION',
          :old.APPRECIATION,
          :new.APPRECIATION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DETAIL',
          :old.DETAIL,
          :new.DETAIL,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DEPASSE_GRADE',
          :old.DEPASSE_GRADE,
          :new.DEPASSE_GRADE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'EXP_GRADE',
          :old.EXP_GRADE,
          :new.EXP_GRADE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DERNIER_GRADE',
          :old.DERNIER_GRADE,
          :new.DERNIER_GRADE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'GRADE_SUP',
          :old.GRADE_SUP,
          :new.GRADE_SUP,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'NOTE_GLOBAL',
          :old.NOTE_GLOBAL,
          :new.NOTE_GLOBAL,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'AMELIOR_FONCTION',
          :old.AMELIOR_FONCTION,
          :new.AMELIOR_FONCTION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'NOTE_FONCTION',
          :old.NOTE_FONCTION,
          :new.NOTE_FONCTION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'QUALITEE_INSTRCUT',
          :old.QUALITEE_INSTRCUT,
          :new.QUALITEE_INSTRCUT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'FORMATION_SUB',
          :old.FORMATION_SUB,
          :new.FORMATION_SUB,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'PREOCCUP_SUB',
          :old.PREOCCUP_SUB,
          :new.PREOCCUP_SUB,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_DISPLINE',
          :old.ESPRIT_DISPLINE,
          :new.ESPRIT_DISPLINE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_COLLECT',
          :old.ESPRIT_COLLECT,
          :new.ESPRIT_COLLECT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_PARTICIP',
          :old.ESPRIT_PARTICIP,
          :new.ESPRIT_PARTICIP,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'COMMANDEMENT',
          :old.COMMANDEMENT,
          :new.COMMANDEMENT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'MAITRISE_SOI',
          :old.MAITRISE_SOI,
          :new.MAITRISE_SOI,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'TRAVAIL',
          :old.TRAVAIL,
          :new.TRAVAIL,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CONVERSATION',
          :old.CONVERSATION,
          :new.CONVERSATION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'INTILLIGENCE',
          :old.INTILLIGENCE,
          :new.INTILLIGENCE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'APPARENCE',
          :old.APPARENCE,
          :new.APPARENCE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'EDUCATION',
          :old.EDUCATION,
          :new.EDUCATION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'PHYSIQUE',
          :old.PHYSIQUE,
          :new.PHYSIQUE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'AUTRE_CAUSE',
          :old.AUTRE_CAUSE,
          :new.AUTRE_CAUSE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CAUSE_NOT',
          :old.CAUSE_NOT,
          :new.CAUSE_NOT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'D_F_NOTATION',
          :old.D_F_NOTATION,
          :new.D_F_NOTATION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'D_D_NOTATION',
          :old.D_D_NOTATION,
          :new.D_D_NOTATION,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'UNITE',
          :old.UNITE,
          :new.UNITE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'SUP');
END;

/* Formatted on 10/09/2020 10:20:34 (QP5 v5.215.12089.38647) */
/

