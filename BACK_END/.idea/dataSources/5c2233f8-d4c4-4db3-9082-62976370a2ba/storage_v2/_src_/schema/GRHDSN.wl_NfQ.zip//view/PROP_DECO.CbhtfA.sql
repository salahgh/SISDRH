create view PROP_DECO as
SELECT MATRICULE,
         NOMA,
         PNOMA,
         POSITION,
         CSN,
         GRADE,
         ARME,
         ANNEE_ENG,
         DECO
    FROM (SELECT P.MATRICULE,
                 P.NOMA,
                 P.PNOMA,
                 P.POSITION,
                 P.CSN,
                 TO_CHAR (E.D_ENG, 'YYYY') AS ANNEE_ENG,
                 G.LIB_GRADE_AR AS GRADE,
                 A.LIB_ARME_AR AS ARME,
                 'وسام الإستحقاق' AS DECO,
                 P.GRADE AS G
            FROM GRHDSN.PERSONNELS P,
                 GRHDSN.A_SIGNER E,
                 GRHDSN.R_ARME A,
                 GRHDSN.R_GRADE G,
                 GRHDSN.R_CSN C
           WHERE     P.MATRICULE = E.MATRICULE
                 AND P.GRADE = G.GRADE
                 AND P.ARME = A.ARME
                 AND P.CSN = C.CSN
                 AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                                  FROM GRHDSN.A_SIGNER EE
                                 WHERE E.MATRICULE = EE.MATRICULE)
                 AND 2022 - TO_CHAR (E.D_ENG, 'YYYY') > 20
                 AND P.MATRICULE NOT IN (SELECT MATRICULE
                                           FROM GRHDSN.EST_DECORER
                                          WHERE TYPE_DECO = '2')
                 AND P.ARME NOT IN ('31', '42', '94')
                 AND P.GRADE <= 59
          UNION
          SELECT P.MATRICULE,
                 P.NOMA,
                 P.PNOMA,
                 P.POSITION,
                 P.CSN,
                 TO_CHAR (E.D_ENG, 'YYYY') AS ANNEE_ENG,
                 G.LIB_GRADE_AR AS GRADE,
                 A.LIB_ARME_AR AS ARME,
                 'وسام الجيش الوطني الشعبي شارة الأولى'
                    AS DECO,
                 P.GRADE AS G
            FROM GRHDSN.PERSONNELS P,
                 GRHDSN.A_SIGNER E,
                 GRHDSN.R_ARME A,
                 GRHDSN.R_GRADE G,
                 GRHDSN.R_CSN C
           WHERE     P.MATRICULE = E.MATRICULE
                 AND P.GRADE = G.GRADE
                 AND P.ARME = A.ARME
                 AND P.CSN = C.CSN
                 AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                                  FROM GRHDSN.A_SIGNER EE
                                 WHERE E.MATRICULE = EE.MATRICULE)
                 AND 2022 - TO_CHAR (E.D_ENG, 'YYYY') > 15
                 AND P.MATRICULE NOT IN (SELECT MATRICULE
                                           FROM GRHDSN.EST_DECORER
                                          WHERE TYPE_DECO = '3')
                 AND P.ARME NOT IN ('31', '42', '94')
                 AND P.GRADE <= 59
          UNION
          SELECT P.MATRICULE,
                 P.NOMA,
                 P.PNOMA,
                 P.POSITION,
                 P.CSN,
                 TO_CHAR (E.D_ENG, 'YYYY') AS ANNEE_ENG,
                 G.LIB_GRADE_AR AS GRADE,
                 A.LIB_ARME_AR AS ARME,
                 'وسام الجيش الوطني الشعبي شارة الثانية'
                    AS DECO,
                 P.GRADE AS G
            FROM GRHDSN.PERSONNELS P,
                 GRHDSN.A_SIGNER E,
                 GRHDSN.R_ARME A,
                 GRHDSN.R_GRADE G,
                 GRHDSN.R_CSN C
           WHERE     P.MATRICULE = E.MATRICULE
                 AND P.GRADE = G.GRADE
                 AND P.ARME = A.ARME
                 AND P.CSN = C.CSN
                 AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                                  FROM GRHDSN.A_SIGNER EE
                                 WHERE E.MATRICULE = EE.MATRICULE)
                 AND 2022 - TO_CHAR (E.D_ENG, 'YYYY') > 25
                 AND P.MATRICULE NOT IN (SELECT MATRICULE
                                           FROM GRHDSN.EST_DECORER
                                          WHERE TYPE_DECO = '4')
                 AND P.ARME NOT IN ('31', '42', '94')
                 AND P.GRADE <= 59
          UNION
          SELECT P.MATRICULE,
                 P.NOMA,
                 P.PNOMA,
                 P.POSITION,
                 P.CSN,
                 SUBSTR (P.MATRICULE, 1, 4) AS ANNEE_ENG,
                 'م م ش' AS GRADE,
                 '/' AS ARME,
                 'وسام الجيش الوطني الشعبي بدون شارة'
                    AS DECO,
                 90 AS G
            FROM GRHDSN.PERSONNELS P, GRHDSN.R_CSN C
           WHERE     P.CSN = C.CSN
                 AND 2022 - SUBSTR (P.MATRICULE, 1, 4) > 15
                 AND P.MATRICULE NOT IN (SELECT MATRICULE
                                           FROM GRHDSN.EST_DECORER
                                          WHERE TYPE_DECO = '6')
                 AND P.GRADE = 90) WHERE POSITION BETWEEN 10 AND 39
ORDER BY "G", GRHDSN.CODE_GRD_ANNEE (MATRICULE)
/

