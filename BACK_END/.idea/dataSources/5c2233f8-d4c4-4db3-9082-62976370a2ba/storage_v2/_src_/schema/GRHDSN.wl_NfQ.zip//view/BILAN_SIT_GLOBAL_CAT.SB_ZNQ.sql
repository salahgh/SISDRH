create view BILAN_SIT_GLOBAL_CAT as
SELECT LIB_CSN_AR AS "الهيئة",
          "OFF"  AS "ضباط",
          "SOFF"  AS "ضباط الصف",
          "HDR"  AS "رجال الصف",
          "OFF_A"  AS "ضباط إحتياط",
          "SOFF_A"  AS "ضباط صف إحتياط",
          "HDR_A"  AS "رجال الصف إحتياط",
          "PCA"  AS "مستخدمين مدنيين"
     FROM (  SELECT C.LIB_CSN_AR, S.*
               FROM (SELECT *
                       FROM (SELECT *
                               FROM (SELECT P.MATRICULE,
                                            DECODE (G.CAT_GRADE,
                                                    '2', '1',
                                                    '3', '1',
                                                    '11', '4',
                                                    '10', '9',
                                                    G.CAT_GRADE)
                                               AS CAT_GRADE,
                                            P.CSN
                                       FROM GRHDSN.PERSONNELS P,
                                            GRHDSN.R_GRADE G
                                      WHERE     P.POSITION LIKE '1%'
                                            AND P.GRADE = G.GRADE)) PIVOT (COUNT (
                                                                              MATRICULE)
                                                                    FOR CAT_GRADE
                                                                    IN  ('1' AS "OFF",
                                                                        '4' AS "SOFF",
                                                                        '5' AS "HDR",
                                                                        '6' AS "OFF_A",
                                                                        '7' AS "SOFF_A",
                                                                        '8' AS "HDR_A",
                                                                        '9' AS "PCA"))) S,
                    GRHDSN.R_CSN C
              WHERE C.CSN = S.CSN
           ORDER BY C.CSN)
/

