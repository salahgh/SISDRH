create PROCEDURE        ABS_P_ARME
AS
   CURSOR ABSENCE
   IS
      SELECT P.MATRICULE
        FROM GRHDSN.PERSONNELS P
       WHERE     P.MATRICULE NOT IN
                    ( (SELECT II.MATRICULE
                         FROM GRHDSN.EST_INDISPONIBLE II
                        WHERE TRUNC (SYSDATE) BETWEEN II.D_D_ABS
                                                  AND II.D_F_ABS)
                     UNION
                     (SELECT A.MATRICULE
                        FROM GRHDSN.EST_PRESENT A
                       WHERE TRUNC (SYSDATE) = TRUNC (A.JOUR)))
             AND P.CSN = '0000'
             AND P.MATRICULE != '198324004044'
             AND P.POSITION LIKE '1%'
             AND MV_CSN = '00';
V$DOW NUMBER(1) := 0;
BEGIN
   SELECT TO_CHAR(SYSDATE, 'D') INTO V$DOW FROM DUAL;
   IF V$DOW != 5 AND V$DOW != 6 THEN
   FOR ABSC IN ABSENCE
   LOOP
      INSERT INTO GRHDSN.EST_INDISPONIBLE
           VALUES (ABSC.MATRICULE,
                   '1',
                   TRUNC (SYSDATE),
                   TRUNC (SYSDATE),
                   '',
                   '',
                   '',
                   '',
                   '00');
   END LOOP;
   END IF;
END;
/

