create PROCEDURE       RAF_DEMANDE_PERMISSION (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.DEMANDE_PERMISSION@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from DEMANDE_PERMISSION  
where  MATRICULE=vcur.MATRICULE and D_DEM_PERM=vcur.D_DEM_PERM  ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.DEMANDE_PERMISSION@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into DEMANDE_PERMISSION  
(  MATRICULE ,D_DEM_PERM ,NBR_JOURS ,D_D_PERM ,D_F_PERM ,APC ,MOTIF ,ACCORDER )  
values(  vcur.MATRICULE ,vcur.D_DEM_PERM ,vcur.NBR_JOURS ,vcur.D_D_PERM ,vcur.D_F_PERM ,vcur.APC ,vcur.MOTIF ,vcur.ACCORDER 
) ; 
end if ;
else 
update  DEMANDE_PERMISSION set  
NBR_JOURS=vcur.NBR_JOURS,
D_D_PERM=vcur.D_D_PERM,
D_F_PERM=vcur.D_F_PERM,
APC=vcur.APC,
MOTIF=vcur.MOTIF,
ACCORDER=vcur.ACCORDER
where  MATRICULE=vcur.MATRICULE and D_DEM_PERM=vcur.D_DEM_PERM 
 ; 
end if ;
else
delete from DEMANDE_PERMISSION   
where  MATRICULE=vcur.MATRICULE and D_DEM_PERM=vcur.D_DEM_PERM 
 ; 
 
 ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.DEMANDE_PERMISSION@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.DEMANDE_PERMISSION@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

