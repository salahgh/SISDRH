create FUNCTION        GET_DIPLOME_MIL_SANS_SPEC (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
        SELECT LIB_DIP_AR 
  FROM (  SELECT LIB_DIP_AR, MIN (NIVEAU)
            FROM (SELECT D.LIB_DIP_AR, D.NIVEAU
                    FROM GRHDSN.EST_STAGIERE S, GRHDSN.R_DIPLOME D
                   WHERE     S.MATRICULE = MAT
                         AND S.D_F_STAGE =
                                (SELECT MAX (SS.D_F_STAGE)
                                   FROM GRHDSN.EST_STAGIERE SS
                                  WHERE     SS.MATRICULE = S.MATRICULE
                                        AND SS.DIPLOME LIKE '1%')
                         AND S.DIPLOME LIKE '1%'
                         AND S.DIPLOME = D.DIP)
        GROUP BY LIB_DIP_AR);

   V$RESULTAT   VARCHAR2 (500) := 0;
BEGIN
   FOR C IN CUR
   LOOP
         V$RESULTAT := C.LIB_DIP_AR;
   END LOOP;

   RETURN V$RESULTAT;
END;
/

