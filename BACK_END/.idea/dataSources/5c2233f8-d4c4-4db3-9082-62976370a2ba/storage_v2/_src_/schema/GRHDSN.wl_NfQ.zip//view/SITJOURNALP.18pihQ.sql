create view SITJOURNALP as
SELECT "SGRADE",
            "SCAT_GRADE",
            "ABS_ILG",
            "DESR",
            "SPEC",
            "PERM",
            "CONGE",
            "MISSION",
            "RETARD",
            "ABS_RAS",
            "RETAR",
            "CONVAL",
            "MATERNITE",
            "MALADIE",
            "RECUP",
            "14",
            "RETMISSION",
            "RETCONVAL",
            "RETCONGE",
            "TR"
       FROM (SELECT SMATRICULE,
                    CODE_ABS,
                    SGRADE,
                    SCAT_GRADE
               FROM SITJOURNAL) PIVOT (SUM (SMATRICULE)
                                FOR CODE_ABS
                                IN  (1 AS ABS_ILG,
                                    2 AS DESR,
                                    3 AS SPEC,
                                    4 AS PERM,
                                    5 AS CONGE,
                                    6 AS MISSION,
                                    7 AS RETARD,
                                    8 AS ABS_RAS,
                                    9 AS RETAR,
                                    10 AS CONVAL,
                                    11 AS MATERNITE,
                                    12 AS MALADIE,
                                    13 AS RECUP,
                                    14,
                                    15 AS RETMISSION,
                                    16 AS RETCONVAL,
                                    17 AS RETCONGE,
                                    22 AS TR))
   ORDER BY SCAT_GRADE, SGRADE

/

