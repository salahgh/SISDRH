create FUNCTION        GET_LAST_YEAR_MUT (MAT IN VARCHAR2)
   RETURN INTEGER
IS
   CURSOR CUR
   IS
        SELECT M.UNITEE, M.D_MUTATION, M.STAGE
          FROM GRHDSN.EST_MUTER M
         WHERE M.MATRICULE = MAT
      ORDER BY M.D_MUTATION DESC;

   V$RESULTAT   INTEGER := 0;
   V$I          INTEGER := 0;
   V$UNITE      VARCHAR2 (10);
   V$D_MUT      DATE;
BEGIN
   FOR C IN CUR
   LOOP
      IF C.STAGE != 1 AND V$I = 0
      THEN
         V$UNITE := C.UNITEE;
         V$RESULTAT :=
            TO_CHAR (SYSDATE, 'YYYY') - TO_CHAR (C.D_MUTATION, 'YYYY');
         V$I := 1;
         V$D_MUT := C.D_MUTATION;
      ELSE
         IF V$I = 1 AND C.STAGE != 1
         THEN
            IF V$UNITE = C.UNITEE
            THEN
               V$RESULTAT :=
                    V$RESULTAT
                  + TO_CHAR (V$D_MUT, 'YYYY')
                  - TO_CHAR (C.D_MUTATION, 'YYYY');
               V$D_MUT := C.D_MUTATION;
            ELSE
               V$I := 2;
            END IF;
         ELSE
            V$D_MUT := C.D_MUTATION;
         END IF;
      END IF;
   END LOOP;

   RETURN V$RESULTAT;
END;
/

