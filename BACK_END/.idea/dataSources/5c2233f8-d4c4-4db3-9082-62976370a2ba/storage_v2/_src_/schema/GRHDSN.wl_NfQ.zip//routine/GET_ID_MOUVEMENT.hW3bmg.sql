create FUNCTION        GET_ID_MOUVEMENT (P$CSN_DEPART VARCHAR2 , P$CSN_ARRIVE VARCHAR2 ,P$TYPE_MUTATION VARCHAR2 ,P$ANNEE VARCHAR2 ) RETURN VARCHAR2 AS 
V$NBRE NUMBER ;
V$ID_MOUVEMENT VARCHAR2(12); 
V$COUNT NUMBER; 
BEGIN

    SELECT NVL(COUNT(1),0)  INTO V$NBRE FROM   r_type_mouvement WHERE type_mutation = P$TYPE_MUTATION ;
    IF V$NBRE  = 0 THEN
        RETURN -5;
    END IF;
    
    CASE                --When Mouvement Interne CSN->BSN Or BSN->
                       WHEN P$TYPE_MUTATION IN ('0', '9') THEN  
                                 SELECT NVL(COUNT(1),0) INTO V$NBRE FROM R_CSN WHERE CSN = P$CSN_DEPART OR CSN = P$CSN_ARRIVE  ;
                                 IF P$CSN_DEPART IS NULL OR P$CSN_ARRIVE IS NULL OR SUBSTR(P$CSN_DEPART,1,2) <> SUBSTR(P$CSN_ARRIVE,1,2) OR (P$CSN_ARRIVE <>P$CSN_DEPART AND V$NBRE <2 ) OR (P$CSN_ARRIVE = P$CSN_DEPART AND V$NBRE <> 1  ) THEN
                                      RETURN -1 ;
                                 END IF;
                                 V$ID_MOUVEMENT := SUBSTR(P$CSN_DEPART,1,2)|| SUBSTR(P$CSN_DEPART,1,2) ;
                       WHEN P$TYPE_MUTATION = '1' THEN
                                 SELECT NVL(COUNT(1),0) INTO V$NBRE FROM R_CSN WHERE CSN = P$CSN_DEPART OR CSN = P$CSN_ARRIVE  ;
                                 IF P$CSN_DEPART IS NULL OR P$CSN_ARRIVE IS NULL OR SUBSTR(P$CSN_DEPART,1,2) = SUBSTR(P$CSN_ARRIVE,1,2) OR V$NBRE < 2 THEN
                                                  RETURN -2000 ;
                                 END IF;
                                 V$ID_MOUVEMENT := SUBSTR(P$CSN_DEPART,1,2)|| SUBSTR(P$CSN_ARRIVE,1,2) ;
                       WHEN P$TYPE_MUTATION IN ( '2' , '4' , '8' ) THEN 
                               SELECT NVL(COUNT(1),0) INTO V$NBRE FROM R_CSN WHERE CSN = P$CSN_ARRIVE  ;
                                   IF P$CSN_DEPART IS NOT NULL OR P$CSN_ARRIVE IS NULL OR V$NBRE < 1 THEN
                                                              RETURN -1 ;
                                   END IF;
                                   IF P$TYPE_MUTATION IN ( '2' , '8' ) THEN  --If gain  personnel Formation/Cx 
                                   
                                         V$ID_MOUVEMENT := '00' || SUBSTR(P$CSN_ARRIVE,1,2) ;
                                  ELSE 
                                        V$ID_MOUVEMENT := 'XX' || SUBSTR(P$CSN_ARRIVE,1,2) ;
                                  END IF ;
                       WHEN P$TYPE_MUTATION IN ('3' , '5' , '6'  )THEN 
                                  SELECT NVL(COUNT(1),0) INTO V$NBRE FROM R_CSN WHERE CSN = P$CSN_DEPART ;
                                  IF P$CSN_DEPART IS  NULL OR P$CSN_ARRIVE IS NOT NULL OR V$NBRE < 1  THEN
                                                              RETURN -1 ;
                                   END IF;
                                 V$ID_MOUVEMENT := SUBSTR(P$CSN_DEPART,1,2) || 'XX' ;
                        ELSE
                            RETURN -1;
     END CASE;
 

              EXECUTE IMMEDIATE 'SELECT SEQ_INS_PAM_'||P$ANNEE||'.NEXTVAL FROM DUAL ' INTO V$COUNT ;
              V$ID_MOUVEMENT :=  V$ID_MOUVEMENT|| V$COUNT  ;
  RETURN V$ID_MOUVEMENT ;
  EXCEPTION WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE(sqlcode||'----'||sqlerrm);
       RETURN -500;
END GET_ID_MOUVEMENT;
/

