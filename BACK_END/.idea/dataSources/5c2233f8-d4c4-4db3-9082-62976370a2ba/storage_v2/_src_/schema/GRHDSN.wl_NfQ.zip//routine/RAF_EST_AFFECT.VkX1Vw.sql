create PROCEDURE       RAF_EST_AFFECT (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_AFFECT@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_AFFECT  
whe
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_AFFECT@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_AFFECT  
(  MATRICULE ,D_AFFECTATION ,FONCT ,REF_DECISION ,D_REF_DECISION ,REF_CESS_FONCTION ,D_REF_CESS_FONCTION ,UNITE ,FONCT_DET ,STRUCT ,TYPE_FONCT )  
values(  vcur.MATRICULE ,vcur.D_AFFECTATION ,vcur.FONCT ,vcur.REF_DECISION ,vcur.D_REF_DECISION ,vcur.REF_CESS_FONCTION ,vcur.D_REF_CESS_FONCTION ,vcur.UNITE ,vcur.FONCT_DET ,vcur.STRUCT ,vcur.TYPE_FONCT 
) ; 
end if ;
else 
update  EST_AFFECT set  
MATRICULE=vcur.MATRICULE,
D_AFFECTATION=vcur.D_AFFECTATION,
FONCT=vcur.FONCT,
REF_DECISION=vcur.REF_DECISION,
D_REF_DECISION=vcur.D_REF_DECISION,
REF_CESS_FONCTION=vcur.REF_CESS_FONCTION,
D_REF_CESS_FONCTION=vcur.D_REF_CESS_FONCTION,
UNITE=vcur.UNITE,
FONCT_DET=vcur.FONCT_DET,
STRUCT=vcur.STRUCT,
TYPE_FONCT=vcur.TYPE_FONCT
where
MATRICULE=vcur.MATRICULE and D_AFFECTATION=vcur.D_AFFECTATION and FONCT=vcur.FONCT and STRUCT=vcur.STRUCT
 ; 
end if ;
else
delete from EST_AFFECT   
where
MATRICULE=vcur.MATRICULE and D_AFFECTATION=vcur.D_AFFECTATION and FONCT=vcur.FONCT and STRUCT=vcur.STRUCT
 ; 
  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_AFFECT@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_AFFECT@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

