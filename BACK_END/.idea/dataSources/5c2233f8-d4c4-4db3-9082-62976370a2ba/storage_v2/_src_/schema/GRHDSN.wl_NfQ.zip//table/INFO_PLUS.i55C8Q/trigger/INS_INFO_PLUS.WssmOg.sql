create trigger INS_INFO_PLUS
    before insert
    on INFO_PLUS
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'INFO_PLUS';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request := REPLACE (x$request, 'V$NCM', '''' || :new.NCM || '''');
      x$request :=
         REPLACE (x$request, 'V$D_E_CM', '''' || :new.D_E_CM || '''');
      x$request :=
         REPLACE (x$request, 'V$D_F_CM', '''' || :new.D_F_CM || '''');
      x$request := REPLACE (x$request, 'V$NCA', '''' || :new.NCA || '''');
      x$request :=
         REPLACE (x$request, 'V$D_E_CA', '''' || :new.D_E_CA || '''');
      x$request :=
         REPLACE (x$request, 'V$D_F_CA', '''' || :new.D_F_CA || '''');
      x$request := REPLACE (x$request, 'V$N_CN', '''' || :new.N_CN || '''');
      x$request := REPLACE (x$request, 'V$T_CN', '''' || :new.T_CN || '''');
      x$request := REPLACE (x$request, 'V$L_D_CN', :new.L_D_CN);
      x$request :=
         REPLACE (x$request, 'V$D_E_CN', '''' || :new.D_E_CN || '''');
      x$request :=
         REPLACE (x$request, 'V$D_F_CN', '''' || :new.D_F_CN || '''');
      x$request := REPLACE (x$request, 'V$N_PP', '''' || :new.N_PP || '''');
      x$request := REPLACE (x$request, 'V$L_D_PP', :new.L_D_PP);
      x$request :=
         REPLACE (x$request, 'V$D_E_PP', '''' || :new.D_E_PP || '''');
      x$request :=
         REPLACE (x$request, 'V$D_F_PP', '''' || :new.D_F_PP || '''');
      x$request := REPLACE (x$request, 'V$T_PC', '''' || :new.T_PC || '''');
      x$request := REPLACE (x$request, 'V$N_PC', '''' || :new.N_PC || '''');
      x$request := REPLACE (x$request, 'V$L_PC', :new.L_PC);
      x$request :=
         REPLACE (x$request, 'V$D_E_PC', '''' || :new.D_E_PC || '''');
      x$request :=
         REPLACE (x$request, 'V$D_F_PC', '''' || :new.D_F_PC || '''');

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;


   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_F_PC',
          :old.D_F_PC,
          :new.D_F_PC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_E_PC',
          :old.D_E_PC,
          :new.D_E_PC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'L_PC',
          :old.L_PC,
          :new.L_PC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'N_PC',
          :old.N_PC,
          :new.N_PC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'T_PC',
          :old.T_PC,
          :new.T_PC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_F_PP',
          :old.D_F_PP,
          :new.D_F_PP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_E_PP',
          :old.D_E_PP,
          :new.D_E_PP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'L_D_PP',
          :old.L_D_PP,
          :new.L_D_PP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'N_PP',
          :old.N_PP,
          :new.N_PP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_F_CN',
          :old.D_F_CN,
          :new.D_F_CN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_E_CN',
          :old.D_E_CN,
          :new.D_E_CN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'L_D_CN',
          :old.L_D_CN,
          :new.L_D_CN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'T_CN',
          :old.T_CN,
          :new.T_CN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'N_CN',
          :old.N_CN,
          :new.N_CN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_F_CA',
          :old.D_F_CA,
          :new.D_F_CA,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_E_CA',
          :old.D_E_CA,
          :new.D_E_CA,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'NCA',
          :old.NCA,
          :new.NCA,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_F_CM',
          :old.D_F_CM,
          :new.D_F_CM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'D_E_CM',
          :old.D_E_CM,
          :new.D_E_CM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'NCM',
          :old.NCM,
          :new.NCM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'INFO_PLUS',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
END;
/

