create trigger MAJ_EST_MUTER
    before update
    on EST_MUTER
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'OLD_UNITE', :old.OLD_UNITE, :new.OLD_UNITE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'PLAN', :old.PLAN, :new.PLAN, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'D_REF_MUT', :old.D_REF_MUT, :new.D_REF_MUT, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'REF_MUT', :old.REF_MUT, :new.REF_MUT, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'UNITEE', :old.UNITEE, :new.UNITEE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'D_MUTATION', :old.D_MUTATION, :new.D_MUTATION, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_MUTER', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'MAJ'); End;
/

