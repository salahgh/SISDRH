create FUNCTION        GET_D_BET_MUT (MAT     IN NUMBER,
                                                 D_MUT   IN DATE)
   RETURN DATE
IS
   CURSOR CUR
   IS
        SELECT M.D_MUTATION
          FROM GRHDSN.EST_MUTER M
         WHERE M.D_MUTATION > D_MUT AND M.MATRICULE = MAT
      ORDER BY M.D_MUTATION;

   V$DEBUT   INTEGER := 1;
   V$I       INTEGER := 0;
   V$DATE    DATE;
BEGIN
   SELECT COUNT (*)
     INTO V$I
     FROM GRHDSN.EST_MUTER M
    WHERE M.D_MUTATION > D_MUT AND M.MATRICULE = MAT;

   IF V$I = 0
   THEN
      V$DATE := TRUNC (SYSDATE);
   ELSE
      FOR M IN CUR
      LOOP
         IF V$DEBUT = 1
         THEN
            V$DATE := M.D_MUTATION;
            V$DEBUT := 0;
         ELSE
            V$DEBUT := 0;
         END IF;
      END LOOP;
   END IF;
   RETURN V$DATE;
END;
/

