create FUNCTION        "SOMME_PRIS_V2" (MAT IN VARCHAR2, DDEBUT IN DATE, DFIN IN DATE)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT SUM(S.JOURS) AS SOMME
                    FROM EST_SANCTIONNE S, GRHDSN.EST_MUTER M
                   WHERE     S.MATRICULE = MAT
                         AND S.MATRICULE = M.MATRICULE
                         AND M.D_MUTATION = (SELECT MAX (MM.D_MUTATION)
                                               FROM GRHDSN.EST_MUTER MM
                                              WHERE M.MATRICULE = MM.MATRICULE)
                         AND S.D_SANCTION >= M.D_MUTATION
                         AND S.D_SANCTION BETWEEN DDEBUT AND DFIN;

   RESULTAT   VARCHAR2 (250);
BEGIN
   FOR P IN TAB
   LOOP
      RESULTAT := P.SOMME;
   END LOOP;

   RETURN RESULTAT;
END;
/

