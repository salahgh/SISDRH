create PROCEDURE        UPDATE_FONCTION
AS
   CURSOR CUR
   IS
        SELECT '018' || SUBSTR (F.FONCTION, 4, 10) AS FONCTION,
               F.LIB_FONCTION_AR,
               F.LIB_FONCTION_FR,
               F.LIB_STRUCTURE_AR,
               F.LIB_STRUCTURE_FR,
               F.CATEGORIE,
               F.ARME,
               F.NBR,
               F.QUALIFICATION,
               F.POSTE,
               F.DJ,
               F.CAP,
               F.CAP_C,
               F.SG,
               F.SGC_C,
               F.ADJ,
               F.ADJ_C,
               F.S_LT,
               F.LT,
               F.CPN,
               F.CDT,
               F.LT_COL,
               F.COL,
               F.PCA
          FROM GRHDSN.R_FONCT F
         WHERE SUBSTR (F.FONCTION, 1, 3) = '010'
      ORDER BY F.FONCTION;
BEGIN
   FOR C IN CUR
   LOOP
      INSERT INTO GRHDSN.R_FONCT
           VALUES (C.FONCTION,
                   C.LIB_FONCTION_AR,
                   C.LIB_FONCTION_FR,
                   C.LIB_STRUCTURE_AR,
                   C.LIB_STRUCTURE_FR,
                   C.CATEGORIE,
                   C.ARME,
                   C.NBR,
                   C.QUALIFICATION,
                   C.POSTE,
                   C.DJ,
                   C.CAP,
                   C.CAP_C,
                   C.SG,
                   C.SGC_C,
                   C.ADJ,
                   C.ADJ_C,
                   C.S_LT,
                   C.LT,
                   C.CPN,
                   C.CDT,
                   C.LT_COL,
                   C.COL,
                   C.PCA);
   END LOOP;
END;
/

