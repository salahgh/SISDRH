create trigger INS_EST_NOMINER_G
    before insert
    on EST_NOMINER_G
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_NOMINER_G', 'D_REF_NOMIN', :old.D_REF_NOMIN, :new.D_REF_NOMIN, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_NOMINER_G', 'REF_NOMIN', :old.REF_NOMIN, :new.REF_NOMIN, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_NOMINER_G', 'GRADE', :old.GRADE, :new.GRADE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_NOMINER_G', 'D_NOMIN', :old.D_NOMIN, :new.D_NOMIN, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_NOMINER_G', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'INS'); End;
/

