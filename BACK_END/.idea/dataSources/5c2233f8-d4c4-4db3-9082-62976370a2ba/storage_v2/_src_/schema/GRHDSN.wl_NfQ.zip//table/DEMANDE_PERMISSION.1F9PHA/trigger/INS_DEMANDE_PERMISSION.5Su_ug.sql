create trigger INS_DEMANDE_PERMISSION
    before insert
    on DEMANDE_PERMISSION
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;
   
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_DEM_PERM',
          :old.D_DEM_PERM,
          :new.D_DEM_PERM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'NBR_JOURS',
          :old.NBR_JOURS,
          :new.NBR_JOURS,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_D_PERM',
          :old.D_D_PERM,
          :new.D_D_PERM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_F_PERM',
          :old.D_F_PERM,
          :new.D_F_PERM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'APC',
          :old.APC,
          :new.APC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'MOTIF',
          :old.MOTIF,
          :new.MOTIF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'ACCORDER',
          :old.ACCORDER,
          :new.ACCORDER,
          'INS');
END;
/

