create PROCEDURE       RAF_EST_INDISPONIBLE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_INDISPONIBLE@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
EXT_delet varchar2(1):='O';
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_INDISPONIBLE  
where  MATRICULE=vcur.MATRICULE and CODE_ABS=vcur.CODE_ABS and D_D_ABS=vcur.D_D_ABS 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_INDISPONIBLE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
EXT_delet :='N';
else
insert into EST_INDISPONIBLE  
(  MATRICULE ,CODE_ABS ,D_D_ABS ,D_F_ABS ,NBR_JOURS ,CODE_DIST ,MOTIF ,OBS )  
values(  vcur.MATRICULE ,vcur.CODE_ABS ,vcur.D_D_ABS ,vcur.D_F_ABS ,vcur.NBR_JOURS ,vcur.CODE_DIST ,vcur.MOTIF ,vcur.OBS 
) ; 
end if ;
else 
update  EST_INDISPONIBLE set  
D_F_ABS=vcur.D_F_ABS,
NBR_JOURS=vcur.NBR_JOURS,
CODE_DIST=vcur.CODE_DIST,
MOTIF=vcur.MOTIF,
OBS=vcur.OBS
where  MATRICULE=vcur.MATRICULE and CODE_ABS=vcur.CODE_ABS and D_D_ABS=vcur.D_D_ABS 
 ; 
end if ;
else
ext  :=0;
SELECT COUNT(1) into ext from EST_INDISPONIBLE   where  MATRICULE=vcur.MATRICULE and CODE_ABS=vcur.CODE_ABS and D_D_ABS=vcur.D_D_ABS ;
if (ext !=0) then
delete from EST_INDISPONIBLE   
where  MATRICULE=vcur.MATRICULE and CODE_ABS=vcur.CODE_ABS and D_D_ABS=vcur.D_D_ABS  ; 
end if ;
end if ;
if (EXT_delet <>'N') then
delete from  GRHDSNJ.EST_INDISPONIBLE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_INDISPONIBLE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

