create PROCEDURE       RAF_PERSONNELS (v_csn varchar2,n number) 
as 
i number:=1;         
cursor cur_j is select * from GRHDSNJ.PERSONNELS@DBL235 where raf<>'O' and csnj= v_csn   order by d_op  for update; 
EXT number:=0;   
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop 
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
 
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then 
insert into PERSONNELS  
(  NOMA ,PHONE2 ,PREVENIR_ABS ,
--DETACHE  ,
APC ,NOM ,PMERE ,GS ,MAIL ,TYPE ,ARCHIVER ,
BSN ,PNOM ,NMERE ,SEX ,CSN ,PHONE_ABS ,ARME ,CCP ,
--NCM ,
MATRICULE ,PNOMA ,ADRESSE ,SITUATION ,GRADE ,DN ,PPERE ,PHONE ,
--NCA ,
CSN_ORG 
)  
values(  vcur.NOMA ,vcur.PHONE2 ,vcur.PREVENIR_ABS ,
--vcur.DETACHE,
vcur.APC ,vcur.NOM ,vcur.PMERE ,vcur.GS ,vcur.MAIL ,vcur.TYPE ,vcur.ARCHIVER ,
vcur.BSN ,vcur.PNOM ,vcur.NMERE ,vcur.SEX ,vcur.CSN ,vcur.PHONE_ABS ,vcur.ARME ,vcur.CCP ,
--vcur.NCM ,
vcur.MATRICULE ,vcur.PNOMA ,
vcur.ADRESSE ,vcur.SITUATION ,vcur.GRADE ,vcur.DN ,vcur.PPERE ,vcur.PHONE ,
--vcur.NCA ,
vcur.CSN_ORG 
) ;  
else 
update PERSONNELS set 
NOMA =vcur.NOMA ,
PHONE2 =vcur.PHONE2 ,
PREVENIR_ABS =vcur.PREVENIR_ABS ,
--DETACHE =vcur.DETACHE  ,
APC =vcur.APC ,
NOM =vcur.NOM ,
PMERE =vcur.PMERE ,
GS =vcur.GS ,
MAIL =vcur.MAIL ,
TYPE =vcur.TYPE ,
ARCHIVER =vcur.ARCHIVER ,
BSN =vcur.BSN ,
PNOM =vcur.PNOM ,
NMERE =vcur.NMERE ,
SEX =vcur.SEX ,
CSN =vcur.CSN ,
PHONE_ABS =vcur.PHONE_ABS ,
ARME =vcur.ARME ,
CCP =vcur.CCP ,
--NCM =vcur.NCM ,
--MATRICULE =vcur.MATRICULE ,
PNOMA =vcur.PNOMA ,
ADRESSE =vcur.ADRESSE ,
SITUATION =vcur.SITUATION ,
GRADE =vcur.GRADE ,
DN =vcur.DN ,
PPERE =vcur.PPERE ,
PHONE =vcur.PHONE ,
--NCA =vcur.NCA ,
CSN_ORG =vcur.CSN_ORG 
where  MATRICULE=vcur.MATRICULE  ; 
end if ;


ELSE
--begin 
/*
SELECT COUNT(1) into ext from EST_MARIER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_MARIER	      where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_PERE_DE where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_PERE_DE	      where matricule =vcur.MATRICULE;end if ;
SELECT COUNT(1) into ext from EST_DIVORCER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_DIVORCER       where	matricule =vcur.MATRICULE;end if ;
SELECT COUNT(1) into ext from CONJOIN where   MAT_CONJOIN=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.CONJOIN            where MAT_CONJOIN =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from ELEMENTS_MISSION where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.ELEMENTS_MISSION   where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_MUTER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then

delete from GRHDSN.EST_MUTER          where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_MARIER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_NOMINER_G      where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from DEMANDE_PERMISSION where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.DEMANDE_PERMISSION where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from DICISION where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.DICISION           where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_AFFECT where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_AFFECT      where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_ARRETE where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_ARRETE         where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_DECORER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_DECORER        where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_INDISPONIBLE where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_INDISPONIBLE   where	matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_RADIER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_RADIER	      where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_RECOMPENSE where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_RECOMPENSE	  where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_MARIER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_SANCTIONNE     where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from EST_STAGIERE where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.EST_STAGIERE	      where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from INFO_PCA where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.INFO_PCA           where matricule =vcur.MATRICULE;end if ;


SELECT COUNT(1) into ext from EST_MARIER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.P_CLASSEMENT	      where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from A_SIGNER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.A_SIGNER           where matricule =vcur.MATRICULE;end if ;

SELECT COUNT(1) into ext from A_DESERTER where   MATRICULE=vcur.MATRICULE  ; 
if (ext =0) then
delete from GRHDSN.A_DESERTER         where matricule =vcur.MATRICULE;end if ;

delete from GRHDSN.personnels         where matricule =vcur.MATRICULE;
*/
update    GRHDSNJ.PERSONNELS@DBL235  set  raf='O' where  current of cur_j; 
end if;  

--- vider la table de journalisation 
delete from  GRHDSNJ.PERSONNELS@DBL235 where current of cur_j; i:=i+1;  
exception when others then 
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.PERSONNELS@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; 
end;
end loop; 
 commit;
end;
/

