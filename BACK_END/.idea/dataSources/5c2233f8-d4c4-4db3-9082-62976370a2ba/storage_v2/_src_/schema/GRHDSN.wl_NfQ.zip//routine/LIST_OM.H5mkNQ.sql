create FUNCTION        "LIST_OM" (V$ID_MISSION   IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT G.ABR_GRADE_AR,
             P.NOMA,
             P.PNOMA,
             P.MATRICULE
        FROM PERSONNELS P, ELEMENTS_MISSION E, R_GRADE G
       WHERE     P.MATRICULE = E.MATRICULE
             AND E.PROFIL <> 0
             AND E.ID_MISSION = V$ID_MISSION
             AND P.GRADE = G.GRADE;

   LIST   VARCHAR2 (500) := NULL;
BEGIN
   FOR P IN TAB
   LOOP
      LIST :=
            LIST
         || 'ال'
         || P.ABR_GRADE_AR
         || ' '
         || P.NOMA
         || ' '
         || P.PNOMA
         || '،  ';
   END LOOP;

   IF LIST IS NULL
   THEN
      RETURN '.';
   ELSE
      LIST := 'مرفوقا بـ' || LIST;
      RETURN LIST;
   END IF;
END;
/

