create view SITJOUR2 as
SELECT P.MATRICULE,
          G.LIB_GRADE_AR,
          g.GRADE,
          DECODE (TO_CHAR (P.TYPE),
                  '3', '1',
                  '4', '2',
                  --'5', 'CTG' || SUBSTR (E.CTG, 6, 1),
                  '5', E.CTG,
                  6, 1,
                  P.TYPE)
             T,
          DECODE (CAT_GRADE,
                  1, 'مجموع العمداء',
                  2, 'مجموع الضباط',
                  3, 'مجموع الضباط',
                  4, 'مجموع صف ضباط',
                  5, 'مجموع رجال الصف',
                  9, 'مجموع م م ش',
                  6, 'مجموع الضباط',
                  7, 'مجموع صف ضباط',
                  8, 'مجموع رجال الصف')
             AS COMPTE,
          ABS_ILG,
          DESR,
          SPEC,
          PERM,
          CONGE,
          MISSION,
          RETARD,
          ABS_RAS,
          RETAR,
          CONVAL,
          MATERNITE,
          MALADIE,
          RECUP,
          "14",
          RETMISSION,
          RETCONVAL,
          RETCONGE,
          TR
     FROM R_GRADE G,
          PERSONNELS P,
          EST_INCORPORER E,
          SITJOURNALP S
    WHERE     P.MATRICULE = E.MATRICULE(+)
          AND P.MATRICULE != 0
          AND P.GRADE = SGRADE(+)
          AND G.GRADE = P.GRADE
          AND P.ARCHIVER = 0
          AND (   TO_CHAR (P.TYPE) IN
                     ('1', '2', '3', '4', '5', '2015/1', '2015/2', '2015/3')
               OR P.TYPE IS NULL)

/

