create view PREVISION_CEM as
SELECT "LIB_CSN_AR","D_DIPLOME","POSITION","DIPLOME","D_NOMIN","GRADE","LIB_METHODE_AR","D_ENG","AGE","DN","PNOMA","NOMA","MATRICULE","DIFF_STAGE"
       FROM (SELECT C.LIB_CSN_AR,
                    DECODE (GET_D_DIPLOME_MIL (P.MATRICULE),
                            '0', '/',
                            GET_D_DIPLOME_MIL (P.MATRICULE))
                       AS D_DIPLOME,
                    PS.LIB_POSITION_AR AS POSITION,
                    DECODE (GET_DIPLOME_MIL (P.MATRICULE),
                            '0', '/',
                            GET_DIPLOME_MIL (P.MATRICULE))
                       AS DIPLOME,
                    N.D_NOMIN,
                    G.LIB_GRADE_AR AS GRADE,
                    M.LIB_METHODE_AR,
                    E.D_ENG,
                    TRUNC ( (TO_DATE ('01/09/2023') - P.DN) / 365) AS AGE,
                    P.DN,
                    P.PNOMA,
                    P.NOMA,
                    P.MATRICULE,
                    TRUNC ( (TO_DATE ('01/09/2023') - S.D_F_STAGE) / 365) AS DIFF_STAGE
               FROM GRHDSN.PERSONNELS P,
                    GRHDSN.R_POSITION PS,
                    GRHDSN.R_GRADE G,
                    GRHDSN.R_CSN C,
                    GRHDSN.EST_NOMINER_G N,
                    GRHDSN.A_SIGNER E,
                    GRHDSN.R_METHODE_ENGAGEMENT M,
                    GRHDSN.EST_STAGIERE S
              WHERE     P.GRADE <= '31'
                    AND P.POSITION LIKE '1%'
                    AND P.GRADE = G.GRADE
                    AND P.POSITION = PS.POSITION
                    AND P.CSN = C.CSN
                    AND P.MATRICULE = S.MATRICULE
                    AND S.D_F_STAGE =
                           (SELECT MAX (SS.D_F_STAGE)
                              FROM GRHDSN.EST_STAGIERE SS
                             WHERE     S.MATRICULE = SS.MATRICULE
                                   AND SUBSTR (SS.DIPLOME, 1, 1) = '1')
                    AND SUBSTR (S.DIPLOME, 1, 1) = '1'
                    AND S.DIPLOME = '1006'
                    AND TRUNC ( (TO_DATE ('01/09/2023') - P.DN) / 365) <= 40
                    AND P.MATRICULE = N.MATRICULE
                    AND N.D_NOMIN = (SELECT MAX (NN.D_NOMIN)
                                       FROM GRHDSN.EST_NOMINER_G NN
                                      WHERE N.MATRICULE = NN.MATRICULE)
                    AND E.MATRICULE = P.MATRICULE
                    AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                                     FROM GRHDSN.A_SIGNER EE
                                    WHERE E.MATRICULE = EE.MATRICULE)
                    AND E.METHOD_ENG = M.METHODE
             UNION
             SELECT C.LIB_CSN_AR,
                    DECODE (GET_D_DIPLOME_MIL (P.MATRICULE),
                            '0', '/',
                            GET_D_DIPLOME_MIL (P.MATRICULE))
                       AS D_DIPLOME,
                    PS.LIB_POSITION_AR AS POSITION,
                    DECODE (GET_DIPLOME_MIL (P.MATRICULE),
                            '0', '/',
                            GET_DIPLOME_MIL (P.MATRICULE))
                       AS DIPLOME,
                    N.D_NOMIN,
                    G.LIB_GRADE_AR AS GRADE,
                    M.LIB_METHODE_AR,
                    E.D_ENG,
                    TRUNC ( (TO_DATE ('01/09/2023') - P.DN) / 365) AS AGE,
                    P.DN,
                    P.PNOMA,
                    P.NOMA,
                    P.MATRICULE,
                    TRUNC ( (TO_DATE ('01/09/2023') - S.D_F_STAGE) / 365) AS DIFF_STAGE
               FROM GRHDSN.PERSONNELS P,
                    GRHDSN.R_POSITION PS,
                    GRHDSN.R_GRADE G,
                    GRHDSN.R_CSN C,
                    GRHDSN.EST_NOMINER_G N,
                    GRHDSN.A_SIGNER E,
                    GRHDSN.R_METHODE_ENGAGEMENT M,
                    GRHDSN.EST_STAGIERE S
              WHERE     P.GRADE = '33'
                    AND P.MATRICULE = S.MATRICULE
                    AND P.MATRICULE = N.MATRICULE
                    AND N.D_NOMIN = (SELECT MAX (NN.D_NOMIN)
                                       FROM GRHDSN.EST_NOMINER_G NN
                                      WHERE N.MATRICULE = NN.MATRICULE)
                    AND S.D_F_STAGE =
                           (SELECT MAX (SS.D_F_STAGE)
                              FROM GRHDSN.EST_STAGIERE SS
                             WHERE     S.MATRICULE = SS.MATRICULE
                                   AND SUBSTR (SS.DIPLOME, 1, 1) = '1')
                    AND SUBSTR (S.DIPLOME, 1, 1) = '1'
                    AND S.DIPLOME = '1006'
                    AND TRUNC ( (TO_DATE ('01/09/2023') - P.DN) / 365) <= 40
                    AND 2022 - TO_CHAR (N.D_NOMIN, 'YYYY') >= 4
                    AND P.MATRICULE = N.MATRICULE
                    AND N.D_NOMIN = (SELECT MAX (NN.D_NOMIN)
                                       FROM GRHDSN.EST_NOMINER_G NN
                                      WHERE N.MATRICULE = NN.MATRICULE)
                    AND E.MATRICULE = P.MATRICULE
                    AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                                     FROM GRHDSN.A_SIGNER EE
                                    WHERE E.MATRICULE = EE.MATRICULE)
                    AND E.METHOD_ENG = M.METHODE
                    AND P.GRADE = G.GRADE
                    AND P.POSITION = PS.POSITION
                    AND P.CSN = C.CSN)
      WHERE DIFF_STAGE >= 3
   ORDER BY GRHDSN.CODE_GRD_ANNEE (MATRICULE)
/

