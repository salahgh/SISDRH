create FUNCTION        GET_STRUCT_AVANT_V1 (MAT   IN VARCHAR2,
                                                       D        DATE)
   RETURN VARCHAR2
IS
   V$STR     VARCHAR (10);
   V$COUNT   VARCHAR2 (10);
BEGIN
   SELECT COUNT (1)
     INTO V$COUNT
     FROM (SELECT ROWNUM R, X.*
             FROM (  SELECT SUBSTR (C.CSN, 1, 2) AS STR
                       FROM GRHDSN.EST_MUTER M, R_CSN C
                      WHERE     M.MATRICULE = MAT
                            AND C.UNITE(+) = M.UNITEE
                            AND M.D_MUTATION < D
                   ORDER BY M.D_MUTATION DESC) X)
    WHERE R = '1';

   IF (V$COUNT != '0')
   THEN
      SELECT STR
        INTO V$STR
        FROM (SELECT ROWNUM R, X.*
                FROM (  SELECT SUBSTR (C.CSN, 1, 2) AS STR
                          FROM GRHDSN.EST_MUTER M, R_CSN C
                         WHERE     M.MATRICULE = MAT
                               AND C.UNITE(+) = M.UNITEE
                               AND M.D_MUTATION < D
                      ORDER BY M.D_MUTATION DESC) X)
       WHERE R = '1';
   ELSE
      V$STR := 'XXX';
   END IF;

   RETURN V$STR;
END;
/

