create trigger SUP_FICHE_VOEUX
    before delete
    on FICHE_VOEUX
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_DSN',
          :old.OBS_DSN,
          :new.OBS_DSN,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_SDRH',
          :old.OBS_SDRH,
          :new.OBS_SDRH,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_CHEF',
          :old.OBS_CHEF,
          :new.OBS_CHEF,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_3',
          :old.OBS_3,
          :new.OBS_3,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_2',
          :old.OBS_2,
          :new.OBS_2,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'OBS_1',
          :old.OBS_1,
          :new.OBS_1,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_3',
          :old.UNITE_3,
          :new.UNITE_3,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_2',
          :old.UNITE_2,
          :new.UNITE_2,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'UNITE_1',
          :old.UNITE_1,
          :new.UNITE_1,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'ANNEE',
          :old.ANNEE,
          :new.ANNEE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'FICHE_VOEUX',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'SUP');
          INSERT INTO CORBEILLE.FICHE_VOEUX ( MATRICULE,ANNEE,UNITE_1,UNITE_2,UNITE_3,OBS_1,OBS_2,OBS_3,OBS_CHEF,OBS_SDRH,OBS_DSN,OBS_BSN ) VALUES ( :OLD.MATRICULE,:OLD.ANNEE,:OLD.UNITE_1,:OLD.UNITE_2,:OLD.UNITE_3,:OLD.OBS_1,:OLD.OBS_2,:OLD.OBS_3,:OLD.OBS_CHEF,:OLD.OBS_SDRH,:OLD.OBS_DSN,:OLD.OBS_BSN );

END;
/

