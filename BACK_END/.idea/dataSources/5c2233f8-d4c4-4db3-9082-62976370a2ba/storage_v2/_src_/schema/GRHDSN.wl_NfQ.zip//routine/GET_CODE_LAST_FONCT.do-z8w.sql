create FUNCTION        GET_CODE_LAST_FONCT (MAT         IN VARCHAR2,
                                                  TYPE_FONC   IN VARCHAR2)
   RETURN VARCHAR2
IS
   UNIT       VARCHAR (50);
   RESULTAT   VARCHAR2 (250);
BEGIN
   SELECT A.UNITE
     INTO UNIT
     FROM GRHDSN.EST_AFFECT A
    WHERE     A.D_AFFECTATION = (SELECT MAX (AA.D_AFFECTATION)
                                   FROM GRHDSN.EST_AFFECT AA
                                  WHERE AA.MATRICULE = MAT)
          AND A.MATRICULE = MAT;

   SELECT F.POSTE
     INTO RESULTAT
     FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
    WHERE     F.FONCTION = A.FONCT
          AND A.UNITE = UNIT
          AND A.MATRICULE = MAT
          AND A.TYPE_FONCT = TYPE_FONC
          AND A.D_AFFECTATION =
                 (SELECT MAX (AA.D_AFFECTATION)
                    FROM GRHDSN.EST_AFFECT AA
                   WHERE     AA.MATRICULE = MAT
                         AND AA.TYPE_FONCT = TYPE_FONC
                         AND AA.UNITE = UNIT);

   RETURN RESULTAT;
END;
/

