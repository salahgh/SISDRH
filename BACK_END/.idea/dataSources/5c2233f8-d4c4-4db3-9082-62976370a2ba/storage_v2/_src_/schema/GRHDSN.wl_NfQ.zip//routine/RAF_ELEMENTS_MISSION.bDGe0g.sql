create PROCEDURE       RAF_ELEMENTS_MISSION (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.ELEMENTS_MISSION@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from ELEMENTS_MISSION  
where  MATRICULE=vcur.MATRICULE and N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.ELEMENTS_MISSION@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into ELEMENTS_MISSION  
(  MATRICULE ,N_REF_OM ,D_REF_OM ,PROFIL )  
values(  vcur.MATRICULE ,vcur.N_REF_OM ,vcur.D_REF_OM ,vcur.PROFIL 
) ; 
end if ;
else 
update  ELEMENTS_MISSION set  
PROFIL=vcur.PROFIL
where  MATRICULE=vcur.MATRICULE and N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM 
 ; 
end if ;
else
delete from ELEMENTS_MISSION   
where  MATRICULE=vcur.MATRICULE and N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM 
 ; 
  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.ELEMENTS_MISSION@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.ELEMENTS_MISSION@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

