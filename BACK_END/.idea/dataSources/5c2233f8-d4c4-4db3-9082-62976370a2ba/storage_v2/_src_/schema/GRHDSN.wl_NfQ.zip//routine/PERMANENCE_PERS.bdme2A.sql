create FUNCTION "PERMANENCE_PERS" (MAT IN VARCHAR2, X IN INT)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT P.NOMA, P.PNOMA, TRIM (G.LIB_GRADE_AR) AS GRADE
        FROM PERSONNELS P, R_GRADE G
       WHERE P.MATRICULE = MAT AND G.GRADE = P.GRADE;

   RESULTAT   VARCHAR2 (250);
BEGIN
   FOR P IN TAB
   LOOP
      IF X = 1
      THEN
         RESULTAT := P.NOMA || ' ' || P.PNOMA || '   (' || P.GRADE || ')';
      ELSE
         IF X = 2
         THEN
            RESULTAT := P.NOMA || ' ' || P.PNOMA;
         ELSE
            RESULTAT := P.GRADE || ' : ' || P.NOMA || ' ' || P.PNOMA;
         END IF;
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;


/

