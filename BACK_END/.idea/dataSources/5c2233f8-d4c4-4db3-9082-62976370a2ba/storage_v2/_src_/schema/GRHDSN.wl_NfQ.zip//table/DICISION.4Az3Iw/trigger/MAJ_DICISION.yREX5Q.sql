create trigger MAJ_DICISION
    after update
    on DICISION
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'DICISION';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request :=
         REPLACE (x$request, 'V$D_DICISION', '''' || :new.D_DICISION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$REF_DICISION',
                  '''' || :new.REF_DICISION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$D_REF_DICISION',
                  '''' || :new.D_REF_DICISION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$CONTENU_DICISION',
                  '''' || :new.CONTENU_DICISION || '''');
      x$request :=
         REPLACE (x$request, 'V$FONCTION', '''' || :new.FONCTION || '''');
      x$request := REPLACE (x$request, 'V$OBS', '''' || :new.OBS || '''');
      x$request :=
         REPLACE (x$request, 'V$DEGRER', '''' || :new.DEGRER || '''');
      x$request :=
         REPLACE (x$request, 'V$CATEGORIE', '''' || :new.CATEGORIE || '''');
      x$request :=
         REPLACE (x$request, 'V$N_IND_REF', '''' || :new.N_IND_REF || '''');
      x$request :=
         REPLACE (x$request,
                  'V$N_IND_REF_BAS',
                  '''' || :new.N_IND_REF_BAS || '''');

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR ('-20101', 'خطأ رقم : '||C.ERR||' : '||x$message, TRUE);
      END IF;
   END LOOP;
   
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'N_IND_REF_BAS',
          :old.N_IND_REF_BAS,
          :new.N_IND_REF_BAS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'N_IND_REF',
          :old.N_IND_REF,
          :new.N_IND_REF,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'CATEGORIE',
          :old.CATEGORIE,
          :new.CATEGORIE,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'DEGRER',
          :old.DEGRER,
          :new.DEGRER,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'OBS',
          :old.OBS,
          :new.OBS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'CONTENU_DICISION',
          :old.CONTENU_DICISION,
          :new.CONTENU_DICISION,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'D_REF_DICISION',
          :old.D_REF_DICISION,
          :new.D_REF_DICISION,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'REF_DICISION',
          :old.REF_DICISION,
          :new.REF_DICISION,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'D_DICISION',
          :old.D_DICISION,
          :new.D_DICISION,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DICISION',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'MAJ');
   
END;
/

