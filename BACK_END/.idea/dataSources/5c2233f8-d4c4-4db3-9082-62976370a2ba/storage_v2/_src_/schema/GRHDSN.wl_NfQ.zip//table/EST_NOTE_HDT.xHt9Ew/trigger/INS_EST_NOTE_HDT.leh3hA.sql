create trigger INS_EST_NOTE_HDT
    before insert
    on EST_NOTE_HDT
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'EST_NOTE_HDT';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request :=
         REPLACE (x$request,
                  'V$D_D_NOTATION',
                  '''' || :new.D_D_NOTATION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$D_F_NOTATION',
                  '''' || :new.D_F_NOTATION || '''');
      x$request :=
         REPLACE (x$request, 'V$OBS_CHEF', '''' || :new.OBS_CHEF || '''');
      x$request :=
         REPLACE (x$request, 'V$CHEF_UNITE', '''' || :new.CHEF_UNITE || '''');
      x$request :=
         REPLACE (x$request, 'V$FONCTION', '''' || :new.FONCTION || '''');
      x$request := REPLACE (x$request, 'V$UNITE', :new.UNITE);

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;

   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'UNITE',
          :old.UNITE,
          :new.UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'CHEF_UNITE',
          :old.CHEF_UNITE,
          :new.CHEF_UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'OBS_CHEF',
          :old.OBS_CHEF,
          :new.OBS_CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'D_F_NOTATION',
          :old.D_F_NOTATION,
          :new.D_F_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'D_D_NOTATION',
          :old.D_D_NOTATION,
          :new.D_D_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_HDT',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
END;


/* Formatted on 10/09/2020 10:24:43 (QP5 v5.215.12089.38647) */
/

