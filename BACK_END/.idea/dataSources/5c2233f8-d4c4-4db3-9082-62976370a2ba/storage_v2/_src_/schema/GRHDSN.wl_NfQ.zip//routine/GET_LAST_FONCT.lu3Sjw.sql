create FUNCTION        GET_LAST_FONCT (MAT         IN VARCHAR2,
                                                  TYPE_FONC   IN VARCHAR2)
   RETURN VARCHAR2
IS
   UNIT       VARCHAR (50);
   RESULTAT   VARCHAR2 (250);
BEGIN
   SELECT A.UNITE
     INTO UNIT
     FROM GRHDSN.EST_AFFECT A
    WHERE     A.D_AFFECTATION = (SELECT MAX (AA.D_AFFECTATION)
                                   FROM GRHDSN.EST_AFFECT AA
                                  WHERE AA.MATRICULE = MAT)
          AND A.MATRICULE = MAT;

   IF TYPE_FONC = '1'
   THEN
      SELECT DECODE (A.FONCT_DET, '/', F.LIB_FONCTION_AR, A.FONCT_DET)
        INTO RESULTAT
        FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
       WHERE     F.FONCTION = A.FONCT
             AND A.UNITE = UNIT
             AND A.MATRICULE = MAT
             AND A.TYPE_FONCT = TYPE_FONC
             AND A.D_REF_CESS_FONCTION IS NULL
             AND A.D_AFFECTATION =
                    (SELECT MAX (AA.D_AFFECTATION)
                       FROM GRHDSN.EST_AFFECT AA
                      WHERE     AA.MATRICULE = MAT
                            AND AA.TYPE_FONCT = TYPE_FONC
                            AND AA.UNITE = UNIT);
   ELSE
      SELECT DECODE (A.FONCT_DET, '/', F.LIB_FONCTION_AR, A.FONCT_DET)
        INTO RESULTAT
        FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
       WHERE     F.FONCTION = A.FONCT
             AND A.UNITE = UNIT
             AND A.MATRICULE = MAT
             AND A.TYPE_FONCT = TYPE_FONC
             AND A.D_AFFECTATION =
                    (SELECT MAX (AA.D_AFFECTATION)
                       FROM GRHDSN.EST_AFFECT AA
                      WHERE     AA.MATRICULE = MAT
                            AND AA.TYPE_FONCT = TYPE_FONC
                            AND AA.UNITE = UNIT);
   END IF;

   RETURN RESULTAT;
END;
/

