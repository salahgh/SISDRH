create FUNCTION        SIT_GLOBAL_ABS (STR IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT 'ال' || G.LIB_GRADE_AR || ' ' || P.NOMA || ' ' || P.PNOMA
                AS IDENTITE
        FROM GRHDSN.PERSONNELS P,
             GRHDSN.EST_INDISPONIBLE I,
             GRHDSN.R_GRADE G,
             GRHDSN.EST_AFFECTER A
       WHERE     P.MATRICULE = I.MATRICULE
             AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
             AND P.GRADE = G.GRADE
             AND (A.MATRICULE, A.D_AFFECTATION) IN
                    (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                         FROM GRHDSN.EST_AFFECTER AA
                     GROUP BY AA.MATRICULE)
             AND P.MATRICULE = A.MATRICULE
             AND A.STRUCT = STR
             ORDER BY P.MATRICULE;

   CURSOR COUNTE
   IS
      SELECT COUNT (*) AS CPT
        FROM GRHDSN.PERSONNELS P,
             GRHDSN.EST_INDISPONIBLE I,
             GRHDSN.R_GRADE G,
             GRHDSN.EST_AFFECTER A
       WHERE     P.MATRICULE = I.MATRICULE
             AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
             AND P.GRADE = G.GRADE
             AND (A.MATRICULE, A.D_AFFECTATION) IN
                    (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                         FROM GRHDSN.EST_AFFECTER AA
                     GROUP BY AA.MATRICULE)
             AND P.MATRICULE = A.MATRICULE
             AND A.STRUCT = STR
             ORDER BY P.MATRICULE;

   COMPTE     INTEGER := 0;
   I          INTEGER := 1;


   RESULTAT   VARCHAR2 (600);
BEGIN
   FOR C IN COUNTE
   LOOP
      COMPTE := C.CPT;
   END LOOP;

   FOR P IN TAB
   LOOP
      IF I < COMPTE
      THEN
         RESULTAT := RESULTAT || '' || P.IDENTITE || ' <br> ';
         I := I + 1;
      ELSE
         RESULTAT := RESULTAT || '' || P.IDENTITE;
         
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;

/

