create PROCEDURE       RAF_GRH (vcsn varchar2, n number) as 
 begin 
------niveau 1 
begin RAF_PERSONNELS(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_PERSONNELS',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
  begin 
RAF_MISSION(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_MISSION',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 -----niveau 2 
  begin
 RAF_CONJOIN(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_CONJOIN',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 

 
 begin 
RAF_A_DESERTER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_A_DESERTER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 
 begin 
RAF_A_SIGNER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_A_SIGNER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;


 begin 
RAF_COURIER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_COURIER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_DEMANDE_PERMISSION(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_DEMANDE_PERMISSION',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_DICISION(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_DICISION',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 begin 
RAF_EST_AFFECT(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_AFFECT',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_ARRETE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_ARRETE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_DECORER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_DECORER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 begin 
RAF_EST_INCORPORER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_INCORPORER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_INDISPONIBLE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_INDISPONIBLE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_MARIER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_MARIER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_MUTER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_MUTER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_NOMINER_G(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_NOMINER_G',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_NOTE_OFF(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_NOTE_OFF',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_NOTE_SOFF(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_NOTE_SOFF',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_PERE_DE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_PERE_DE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 begin 
RAF_EST_RADIER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_RADIER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_RECOMPENSE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_RECOMPENSE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_RECRUTE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_RECRUTE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_SANCTIONNE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_SANCTIONNE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_EST_STAGIERE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_STAGIERE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 begin 
RAF_MISE_ROUTE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_MISE_ROUTE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;


 begin 
RAF_PERMANENCE(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_PERMANENCE',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 begin 
RAF_PHOTOS(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_PHOTOS',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 begin 
RAF_TRACES(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_TRACES',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
----niveau 3
  begin 
RAF_ELEMENTS_MISSION(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_ELEMENTS_MISSION',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;
 
  begin 
RAF_EST_DIVORCER(vcsn,n); 
 exception when others then 
null;--insert into DSN.journal_refresh (vm,d_refresh,RESULTAT,csn) values('RAF_EST_DIVORCER',to_char(sysdate,'DD-MM-YYYY HH:MI:SS'),'N',vcsn);
 end;

 end;
/

