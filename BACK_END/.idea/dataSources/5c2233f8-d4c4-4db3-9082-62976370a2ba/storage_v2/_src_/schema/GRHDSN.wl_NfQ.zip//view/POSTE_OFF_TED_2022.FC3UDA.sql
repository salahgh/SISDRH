create view POSTE_OFF_TED_2022 as
SELECT POSTE, SOMME
        FROM (SELECT SOMME,
                     POSTE,
                     DECODE (POSTE,
                             'G2B', '1',
                             'G3B', '2',
                             'G4', '3',
                             'G4A', '4',
                             'A', '5',
                             'B', '6',
                             'C', '7',
                             'D', '8')    AS ORDRE
                FROM (  SELECT COUNT (1) AS SOMME, F.POSTE
                          FROM GRHDSN.R_FONCT F
                         WHERE F.FONCTION LIKE '1%' AND F.CATEGORIE <= '3'
                      GROUP BY F.POSTE))
    ORDER BY ORDRE
/

