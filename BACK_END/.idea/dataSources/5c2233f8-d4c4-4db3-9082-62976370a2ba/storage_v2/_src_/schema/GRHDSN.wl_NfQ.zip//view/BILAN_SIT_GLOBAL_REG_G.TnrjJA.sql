create view BILAN_SIT_GLOBAL_REG_G as
SELECT REGION AS REGION,
   OFF,
   SOFF,
   HDR,
   CIV,
   R
     FROM (  SELECT DECODE (
                       S.R,
                       '0', 'مديرية الخدمة الوطنية/و.د.و',
                          'الناحية العسكرية '
                       || DECODE (S.R,
                                  '1', 'الأولى',
                                  '2', 'الثانية',
                                  '3', 'الثالثة',
                                  '4', 'الرابعة',
                                  '5', 'الخامسة',
                                  '6', 'السادسة',
                                  NULL))
                       AS REGION,
                    S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE, DECODE (G.CAT_GRADE,
                                            '1', '1',
                                            '2', '1',
                                            '3', '1',
                                            '6', '1',
                                            '4', '2',
                                            '7', '2',
                                            '11', '2',
                                            '5', '3',
                                            '8', '3',
                                            '9', '4',
                                            G.CAT_GRADE)
                                       AS CAT_GRADE, U.REGION AS R
                               FROM GRHDSN.PERSONNELS P,
                                    GRHDSN.R_CSN C,
                                    GRHDSN.R_UNITEE U,
                                    GRHDSN.R_GRADE G
                              WHERE     P.POSITION LIKE '1%'
                                    AND G.GRADE = P.GRADE
                                    AND C.CSN = P.CSN
                                    AND C.UNITE = U.UNITEE) PIVOT (COUNT (
                                                                      MATRICULE)
                                                            FOR CAT_GRADE
                                                            IN  ('1' AS "OFF",
                                                                                  '2' AS "SOFF",
                                                                                  '3' AS "HDR",
                                                                                  '4' AS "CIV"))) S
           ORDER BY S.R)
/

