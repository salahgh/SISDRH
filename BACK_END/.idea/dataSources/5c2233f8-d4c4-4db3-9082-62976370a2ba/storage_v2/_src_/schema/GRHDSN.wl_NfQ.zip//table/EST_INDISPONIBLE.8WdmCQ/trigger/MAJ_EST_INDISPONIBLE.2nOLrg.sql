create trigger MAJ_EST_INDISPONIBLE
    before update
    on EST_INDISPONIBLE
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'OBS',
          :old.OBS,
          :new.OBS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'MOTIF',
          :old.MOTIF,
          :new.MOTIF,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'CODE_DIST',
          :old.CODE_DIST,
          :new.CODE_DIST,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'NBR_JOURS',
          :old.NBR_JOURS,
          :new.NBR_JOURS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'D_F_ABS',
          :old.D_F_ABS,
          :new.D_F_ABS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'D_D_ABS',
          :old.D_D_ABS,
          :new.D_D_ABS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'CODE_ABS',
          :old.CODE_ABS,
          :new.CODE_ABS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'MAJ');
END;
/

