create trigger INS_EST_RADIER
    before insert
    on EST_RADIER
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'D_RAD', :old.D_RAD, :new.D_RAD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'UNITEE', :old.UNITEE, :new.UNITEE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'GRADE', :old.GRADE, :new.GRADE, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'REF_RAD', :old.REF_RAD, :new.REF_RAD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'D_REF_RAD', :old.D_REF_RAD, :new.D_REF_RAD, 'INS');P_CPR(:new.MATRICULE,x$user,'EST_RADIER', 'MOTIF_RAD', :old.MOTIF_RAD, :new.MOTIF_RAD, 'INS'); End;

/

