create PROCEDURE INS_MOUVEMENT_MANUEL_G_V1  AS

    V$ID_ARCHIVE NUMBER ;
    V_SQLERRM VARCHAR2(200);
    V_SQLCODE VARCHAR2(100); 
EX NUMBER(2):=0;
INS_COMPLETE NUMBER(2):=0;
V$LINK_DEP   VARCHAR2(30);
V$LINK_ARR   VARCHAR2(30);
V$SCHEMA_DEP VARCHAR2(30) := 'GRHDSN_ARCHIVE.';
V$SCHEMA_ARR VARCHAR2(30) := 'GRHDSN.';
V$GET_ID_ARCHIVE VARCHAR2(1000);
BEGIN

        FOR V$PER IN  ( SELECT M.MATRICULE, SUBSTR(M.CSN_DEPART, 1, 2) AS DEP, SUBSTR(M.CSN_ARRIVE, 1, 2) AS ARR 
                        FROM GRHDSN.A_MOUVEMENT M 
                        WHERE M.TYPE_MUTATION = '1'
                        AND SUBSTR(M.CSN_ARRIVE, 1, 2) != '53'
                        AND SUBSTR(M.CSN_DEPART, 1, 2) != '53'
                        )
        LOOP 
                    SELECT  DECODE (V$PER.DEP ,'00' ,'ID_ARCHIVE_DSN' , 'ID_ARCHIVE' ) , 
                            DECODE (V$PER.DEP ,'00' ,NULL , '@GRHDSN'||V$PER.DEP ) , 
                            DECODE (V$PER.ARR ,'00' ,NULL , '@GRHDSN'||V$PER.ARR ) 
                            INTO  V$GET_ID_ARCHIVE,
                                  V$LINK_DEP, 
                                  V$LINK_ARR           
                    FROM DUAL ;
                    
                    EXECUTE IMMEDIATE 'SELECT NVL(MAX('||V$GET_ID_ARCHIVE||'),0) 
                                       FROM '||V$SCHEMA_DEP||'PERSONNELS'||V$LINK_DEP||'
                                       WHERE MATRICULE = :1' 
                                       INTO V$ID_ARCHIVE USING  V$PER.MATRICULE;
                    
                    FOR V$TAB IN (  SELECT TABLE_NAME ,COLS  FROM ALL_TAB ORDER BY NIVEAU )
                    LOOP
                          BEGIN
                                 DBMS_OUTPUT.PUT_LINE('INSERT INTO '||V$SCHEMA_ARR||V$TAB.TABLE_NAME||V$LINK_ARR||' ('||V$TAB.COLS||') 
                                                    SELECT  '||V$TAB.COLS||'  FROM '||V$SCHEMA_DEP||V$TAB.TABLE_NAME||V$LINK_DEP||' 
                                                    WHERE  '||V$GET_ID_ARCHIVE||'= '||V$ID_ARCHIVE||';');
                               EXCEPTION WHEN OTHERS THEN 
                                  V_SQLERRM :=  SUBSTR(SQLERRM,1,200);
                                  V_SQLCODE :=SQLCODE ;
                                  INSERT INTO A_JOURNAL_MOUVEMENT_MAN_ERROR (IDENTIFIANT,TABLE_NAME,SQL_ERR_CODE,SQL_ERR_MSG, DATE_ERR,MATRICULE) VALUES ('PROC: INS_MOUVEMENT_MANUEL_G','XXXXXX' ,V_SQLCODE, V_SQLERRM, SYSDATE,NULL);                            
                          END;
                    END LOOP;
        END LOOP ;
        
        EXCEPTION WHEN OTHERS THEN 
                V_SQLERRM :=  SUBSTR(SQLERRM,1,200);
                V_SQLCODE :=SQLCODE ;
                INSERT INTO A_JOURNAL_MOUVEMENT_MAN_ERROR (IDENTIFIANT,TABLE_NAME,SQL_ERR_CODE,SQL_ERR_MSG, DATE_ERR,MATRICULE) VALUES ('PROC: INS_MOUVEMENT_MANUEL_G','XXXXXX' ,V_SQLCODE, V_SQLERRM, SYSDATE,NULL);  

END;
/

