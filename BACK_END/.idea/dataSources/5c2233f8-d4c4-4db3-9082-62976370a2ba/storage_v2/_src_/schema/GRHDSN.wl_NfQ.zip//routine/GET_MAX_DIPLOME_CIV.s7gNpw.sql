create FUNCTION        GET_MAX_DIPLOME_CIV (MAT IN VARCHAR2)
    RETURN VARCHAR2
IS
    CURSOR CUR IS
        SELECT LIB_DIP_AR || ' (' || LIB_SPEC_AR || ')'     AS LIB_DIP_AR
          FROM (SELECT ROWNUM R, FF.*
                  FROM (  SELECT F.*
                            FROM (SELECT *
                                    FROM GRHDSN.EST_STAGIERE S,
                                         GRHDSN.R_DIPLOME   D,
                                         GRHDSN.R_SPECIALITE SP
                                   WHERE     S.MATRICULE = MAT
                                         AND D.DIP = S.DIPLOME
                                         AND S.SPECIALITE = SP.SPEC
                                         AND SUBSTR (D.DIP, 1, 1) = '0') F
                        ORDER BY F.NIVEAU) FF)
         WHERE R = '1';

    V$RESULTAT   VARCHAR2 (500) := 0;
BEGIN
    FOR C IN CUR
    LOOP
        V$RESULTAT := C.LIB_DIP_AR;
    END LOOP;

    RETURN V$RESULTAT;
END;
/

