create PROCEDURE       RAF_TRACES (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.TRACES@DBL235 where raf<>'O'  and csn= v_csn  order by d_op  for update; 
begin  
for vcur in cur_j loop  
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
begin  
delete from TRACES   
whe
 ; 
exception when others then null; end;  
 
insert into TRACES  
(  VAL_OLD ,
--DETAIL_TRANSACTION ,
VAL_NEW ,UT ,CHAMPS ,CSN ,
--ID ,
IDENTIFIANT ,DATE_TRANSACTION ,MATRICULE ,TYPE_TRANSACTION )  
values(  vcur.VAL_OLD ,
--vcur.DETAIL_TRANSACTION ,
vcur.VAL_NEW ,vcur.UT ,vcur.CHAMPS ,vcur.CSN ,
--vcur.ID ,
vcur.IDENTIFIANT ,vcur.DATE_TRANSACTION ,vcur.MATRICULE ,vcur.TYPE_TRANSACTION 
) ; 
begin  
delete from TRACES  
whe
 ; 
exception when others then null; end; end if;  
delete from  GRHDSNJ.TRACES@DBL235 where current of cur_j; i:=i+1;  end loop; 
 commit; end;
/

