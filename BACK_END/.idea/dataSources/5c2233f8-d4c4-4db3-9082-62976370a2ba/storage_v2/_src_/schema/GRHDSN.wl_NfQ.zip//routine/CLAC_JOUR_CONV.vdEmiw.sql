create FUNCTION        CLAC_JOUR_CONV (MAT     IN NUMBER,
                                                 D_DEBUT   IN DATE,
                                                 D_FIN   IN DATE)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
   SELECT I.MATRICULE,
       I.D_D_ABS,
       I.D_F_ABS,
       I.D_F_ABS - I.D_D_ABS + 1 AS NBR_JOUR
  FROM GRHDSN.EST_INDISPONIBLE I
 WHERE I.CODE_ABS IN ('10', '11', '12', '13', '23') AND I.D_D_ABS BETWEEN D_DEBUT AND D_FIN AND I.MATRICULE = MAT;
 COMPTE     INTEGER := 0;
 BEGIN
 FOR I IN CUR
   LOOP
   COMPTE := COMPTE + I.NBR_JOUR;
   END LOOP;
   RETURN COMPTE;
 END;
/

