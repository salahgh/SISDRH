create trigger MAJ_EST_DECORER
    before update
    on EST_DECORER
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'OBS', :old.OBS, :new.OBS, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'D_REF_ACT_DECO', :old.D_REF_ACT_DECO, :new.D_REF_ACT_DECO, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'REF_ACT_DECO', :old.REF_ACT_DECO, :new.REF_ACT_DECO, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'TYPE_DECO', :old.TYPE_DECO, :new.TYPE_DECO, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'D_DECO', :old.D_DECO, :new.D_DECO, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_DECORER', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'MAJ'); End;
/

