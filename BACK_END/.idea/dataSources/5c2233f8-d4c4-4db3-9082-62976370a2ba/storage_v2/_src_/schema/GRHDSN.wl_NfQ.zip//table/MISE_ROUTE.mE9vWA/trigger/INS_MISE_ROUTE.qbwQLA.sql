create trigger INS_MISE_ROUTE
    after insert
    on MISE_ROUTE
    for each row
DECLARE
   x$user   VARCHAR2 (40);
   V$PAM    INTEGER;
   V$PAM_0 VARCHAR2(2);
   V$MOUV_0 VARCHAR2(2);
BEGIN
   x$user := SECTION_EN_COURS;
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'NEW_UNITE',
          :old.NEW_UNITE,
          :new.NEW_UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'OLD_UNITE',
          :old.OLD_UNITE,
          :new.OLD_UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'CARTE_ASSURANCE',
          :old.CARTE_ASSURANCE,
          :new.CARTE_ASSURANCE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'CARTE_MILITAIRE',
          :old.CARTE_MILITAIRE,
          :new.CARTE_MILITAIRE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'COMBAT_2',
          :old.COMBAT_2,
          :new.COMBAT_2,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'COMBAT_1',
          :old.COMBAT_1,
          :new.COMBAT_1,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'CHAINE',
          :old.CHAINE,
          :new.CHAINE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'D_MUTATION',
          :old.D_MUTATION,
          :new.D_MUTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'N_AVIS_MUTATION',
          :old.N_AVIS_MUTATION,
          :new.N_AVIS_MUTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'D_AVIS_MUTATION',
          :old.D_AVIS_MUTATION,
          :new.D_AVIS_MUTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'TYPE_M_ROUTE',
          :old.TYPE_M_ROUTE,
          :new.TYPE_M_ROUTE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'CONGE',
          :old.CONGE,
          :new.CONGE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'OBS',
          :old.OBS,
          :new.OBS,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'N_M_ROUTE',
          :old.N_M_ROUTE,
          :new.N_M_ROUTE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'D_M_ROUTE',
          :old.D_M_ROUTE,
          :new.D_M_ROUTE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'MISE_ROUTE',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
 ----------------------------------------------- TOUT TYPE DE MOUVEMENT SAUF MUTATION INTERNE ----------------------------------------------- 
  SELECT NVL(COUNT(1),0) INTO  V$PAM FROM  A_MOUVEMENT  WHERE MATRICULE = :NEW.MATRICULE AND (ANNEE = TO_CHAR(SYSDATE, 'YYYY') OR ANNEE+1 = TO_CHAR(SYSDATE, 'YYYY')) AND SUBSTR(CSN_DEPART,1,2)='00' AND NEW_UNITE <> OLD_UNITE AND TYPE_MUTATION <> '0';
   IF V$PAM > 0 THEN   
 UPDATE A_MOUVEMENT SET MR_DEPART = :NEW.N_M_ROUTE,D_MR_DEPART =:NEW.D_M_ROUTE WHERE MATRICULE = :NEW.MATRICULE AND (ANNEE = TO_CHAR(SYSDATE, 'YYYY') OR ANNEE+1 = TO_CHAR(SYSDATE, 'YYYY')) ; 
 UPDATE PERSONNELS SET POSITION= (SELECT POSITION FROM A_MOUVEMENT WHERE MATRICULE=:NEW.MATRICULE) WHERE MATRICULE=:NEW.MATRICULE; 
   END IF;
 ----------------------------------------------- MUTATION INTERNE AND UNITE OLD DIFFERENT UNITE NEW --------------------------------------------    
  SELECT NVL(COUNT(1),0) INTO  V$PAM_0 FROM  A_MOUVEMENT  WHERE MATRICULE = :NEW.MATRICULE AND (ANNEE = TO_CHAR(SYSDATE, 'YYYY') OR ANNEE+1 = TO_CHAR(SYSDATE, 'YYYY')) AND SUBSTR(CSN_DEPART,1,2)='00' AND NEW_UNITE <> OLD_UNITE AND TYPE_MUTATION = '0';
   IF V$PAM_0 > 0 THEN  
   SELECT NVL(COUNT(1),0) INTO  V$MOUV_0 FROM A_MOUVEMENT  WHERE MATRICULE = :NEW.MATRICULE AND D_MR_DEPART IS NULL;
   IF V$MOUV_0 > 0 THEN 
 UPDATE A_MOUVEMENT SET MR_DEPART = :NEW.N_M_ROUTE,D_MR_DEPART =:NEW.D_M_ROUTE WHERE MATRICULE = :NEW.MATRICULE AND (ANNEE = TO_CHAR(SYSDATE, 'YYYY') OR ANNEE+1 = TO_CHAR(SYSDATE, 'YYYY')) ; 
 ELSE
  UPDATE A_MOUVEMENT SET MR_ARRIVE = :NEW.N_M_ROUTE,D_MR_ARRIVE =:NEW.D_M_ROUTE WHERE MATRICULE = :NEW.MATRICULE AND (ANNEE = TO_CHAR(SYSDATE, 'YYYY') OR ANNEE+1 = TO_CHAR(SYSDATE, 'YYYY')) ; 
 UPDATE PERSONNELS SET POSITION= (SELECT POSITION FROM A_MOUVEMENT WHERE MATRICULE=:NEW.MATRICULE) WHERE MATRICULE=:NEW.MATRICULE; 
   END IF;
   END IF;

END;
/

