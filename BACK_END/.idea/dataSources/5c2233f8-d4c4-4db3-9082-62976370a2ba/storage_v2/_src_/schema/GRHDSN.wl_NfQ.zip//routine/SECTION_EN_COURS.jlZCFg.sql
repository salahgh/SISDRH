create FUNCTION "SECTION_EN_COURS" return varchar2 is
n number;
u varchar2(50);
BEGIN
  Select count(*) Into n From UT_SESSION S where S.ID_SESSION = sys_context('USERENV','SESSIONID');
  If n = 1 then
    Select UT Into u From UT_SESSION S where S.ID_SESSION = sys_context('USERENV','SESSIONID');
    Return (upper(u));
  Else
    Return (upper(user));
  End If;
END;


/

