create trigger SUP_A_SIGNER
    before delete
    on A_SIGNER
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'DUREE',
          :old.DUREE,
          :new.DUREE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'NIVEAU',
          :old.NIVEAU,
          :new.NIVEAU,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_AVIS_ENG',
          :old.D_AVIS_ENG,
          :new.D_AVIS_ENG,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'AVIS_ENG',
          :old.AVIS_ENG,
          :new.AVIS_ENG,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_ACT',
          :old.D_ACT,
          :new.D_ACT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'N_ACT',
          :old.N_ACT,
          :new.N_ACT,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'UNITEE',
          :old.UNITEE,
          :new.UNITEE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'ARME',
          :old.ARME,
          :new.ARME,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'GRADE',
          :old.GRADE,
          :new.GRADE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_ENG',
          :old.D_ENG,
          :new.D_ENG,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'TYPE_ENG',
          :old.TYPE_ENG,
          :new.TYPE_ENG,
          'SUP');
END;
/

