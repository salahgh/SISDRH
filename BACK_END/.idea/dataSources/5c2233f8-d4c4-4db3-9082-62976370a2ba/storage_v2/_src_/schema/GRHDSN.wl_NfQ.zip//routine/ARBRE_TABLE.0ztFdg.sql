create FUNCTION "ARBRE_TABLE" ( MAT VARCHAR2) RETURN VARCHAR2 IS 
CURSOR tab IS SELECT table_name FROM ALL_TAB WHERE TABLE_NAME NOT IN ('MISSION','CONJOIN') ORDER BY NIVEAU   ;


nbr   NUMBER(5):=0;
var varchar2(30000):=null;
ex varchar2(30000):=null;
instr varchar(30000):=null;
begin

for p in tab loop
ex:=arbre_table_mat(mat,p.table_name);
if (ex is not null) then
var:=VAR||'%'||ex;
end if;
end loop;
return (var);
end;
/

