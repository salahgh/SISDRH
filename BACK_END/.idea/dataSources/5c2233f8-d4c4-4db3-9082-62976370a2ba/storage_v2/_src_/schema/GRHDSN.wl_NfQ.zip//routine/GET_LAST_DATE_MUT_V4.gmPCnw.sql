create FUNCTION        GET_LAST_DATE_MUT_V4 (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
        SELECT M.UNITEE,
               M.D_MUTATION,
               M.STAGE,
               C.UNITE,
               SUBSTR (C.CSN, 1, 2) AS STR
          FROM GRHDSN.EST_MUTER M, (SELECT * FROM R_CSN UNION SELECT * FROM GRHDSN.R_CSN_OLD) C
         WHERE M.MATRICULE = MAT AND C.UNITE(+) = M.UNITEE
      ORDER BY M.D_MUTATION DESC;

   V$I       INTEGER := 0;
   V$STR     VARCHAR2 (10);
   V$DUREE   VARCHAR2 (10) := '0';
   V$D_MUT   DATE;
BEGIN
   FOR C IN CUR
   LOOP
      IF C.STAGE != 1 AND V$I = 0
      THEN
         V$STR := C.STR;
         V$DUREE := TO_DATE ('16/09/2024') - C.D_MUTATION;
         V$I := 1;
         V$D_MUT := C.D_MUTATION;
      ELSE
         IF V$I = 1 AND C.STAGE != 1
         THEN
            IF V$STR = C.STR
            THEN
               V$DUREE := V$DUREE + (V$D_MUT - C.D_MUTATION);
               V$D_MUT := C.D_MUTATION;
            ELSE
               V$I := 2;
            END IF;
         ELSE
            IF     V$I = 1
               AND C.STAGE = 1
               AND GRHDSN.GET_STRUCT_AVANT_V1 (MAT, C.D_MUTATION) = V$STR
            THEN
               --V$DUREE := V$DUREE - (V$D_MUT - C.D_MUTATION);
               V$D_MUT := C.D_MUTATION;
            ELSE
               V$I := 2;
            END IF;
         END IF;
      END IF;
   END LOOP;
   RETURN V$DUREE;
END;
/

