create FUNCTION        GET_DATE_FONCT (MAT     IN NUMBER,
                                                 D_MUT   IN DATE,
                                                 UNITE   IN NUMBER)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
        SELECT A.D_AFFECTATION, A.UNITE
          FROM GRHDSN.EST_AFFECT A
         WHERE     A.MATRICULE = MAT
               --AND A.TYPE_FONCT = '0'
               ORDER BY A.D_AFFECTATION ;

   I          INTEGER := 1;
   DEBUT      INTEGER := 1;
   COMPTE     INTEGER := 0;
   RESULTAT   VARCHAR2 (1000);
   V$DATE     DATE;
BEGIN
   SELECT GRHDSN.GET_D_BET_MUT(MAT, D_MUT) INTO V$DATE FROM DUAL;
   FOR A IN CUR
   LOOP
      IF D_MUT <= A.D_AFFECTATION AND A.D_AFFECTATION <= V$DATE AND I = 1
      THEN
         IF A.UNITE = UNITE
         THEN
            IF DEBUT = 1
            THEN
               RESULTAT := RESULTAT || TO_CHAR(D_MUT, 'YYYY/MM/DD');
               DEBUT := 0; 
            ELSE
               RESULTAT := RESULTAT || '<br>' || TO_CHAR(A.D_AFFECTATION, 'YYYY/MM/DD');
            END IF;
         ELSE
            I := 0;
         END IF;
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;
/

