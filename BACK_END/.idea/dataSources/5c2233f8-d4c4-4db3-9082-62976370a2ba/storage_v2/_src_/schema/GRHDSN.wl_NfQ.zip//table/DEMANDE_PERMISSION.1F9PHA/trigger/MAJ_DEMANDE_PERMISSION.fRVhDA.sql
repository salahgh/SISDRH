create trigger MAJ_DEMANDE_PERMISSION
    before update
    on DEMANDE_PERMISSION
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;


   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'ACCORDER',
          :old.ACCORDER,
          :new.ACCORDER,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'MOTIF',
          :old.MOTIF,
          :new.MOTIF,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'APC',
          :old.APC,
          :new.APC,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_F_PERM',
          :old.D_F_PERM,
          :new.D_F_PERM,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_D_PERM',
          :old.D_D_PERM,
          :new.D_D_PERM,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'NBR_JOURS',
          :old.NBR_JOURS,
          :new.NBR_JOURS,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'D_DEM_PERM',
          :old.D_DEM_PERM,
          :new.D_DEM_PERM,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'DEMANDE_PERMISSION',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'MAJ');
END;
/

