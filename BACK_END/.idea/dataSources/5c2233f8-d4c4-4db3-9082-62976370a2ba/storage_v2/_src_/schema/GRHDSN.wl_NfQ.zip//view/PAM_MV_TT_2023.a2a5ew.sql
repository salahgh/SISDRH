create view PAM_MV_TT_2023 as
SELECT STR,
          OBS,
          DECODE (OFF, NULL, 0, OFF) AS OFF,
          DECODE (SOFF, NULL, 0, SOFF) AS SOFF,
          DECODE (HDR, NULL, 0, HDR) AS HDR
     FROM (  SELECT "STR",
                    "OBS",
                    "OFF",
                    "SOFF",
                    "HDR"
               FROM (  SELECT STR,
                              OBS,
                              CAT,
                              SUM (CPT) CPT
                         FROM (  SELECT STR,
                                        OBS,
                                        CAT,
                                        COUNT (1) CPT
                                   FROM (SELECT D.CSN_DEPART STR,
                                                'PERTE' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     (   (    D.TYPE_MUTATION NOT IN
                                                                ('0',
                                                                 '2',
                                                                 '3',
                                                                 '4',
                                                                 '5',
                                                                 '9')
                                                         AND D.GRADE > 39)
                                                     OR (    D.TYPE_MUTATION NOT IN
                                                                ('0', '2', '3', '4', '5', '9')
                                                         AND D.GRADE <= 39))
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE
                                                AND D.CSN_DEPART IS NOT NULL
                                         UNION
                                         SELECT D.CSN_DEPART STR,
                                                'PERTE_R' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     (   (    D.TYPE_MUTATION NOT IN
                                                                ('0',
                                                                 '2',
                                                                 '3',
                                                                 '4',
                                                                 '5',
                                                                 '9')
                                                         AND D.GRADE > 39)
                                                     OR (    D.TYPE_MUTATION NOT IN
                                                                ('0', '2', '3', '4', '5', '9')
                                                         AND D.GRADE <= 39))
                                                AND D.D_MR_DEPART IS NOT NULL
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE
                                         UNION
                                         SELECT D.CSN_ARRIVE STR,
                                                'GAIN' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     (   (    D.TYPE_MUTATION NOT IN
                                                                ('0',
                                                                 '2',
                                                                 '3',
                                                                 '4',
                                                                 '9',
                                                                 '5')
                                                         AND D.GRADE > 39)
                                                     OR (    D.TYPE_MUTATION NOT IN
                                                                ('0', '3', '4', '9', '5')
                                                         AND D.GRADE <= 39))
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE
                                         UNION
                                         SELECT D.CSN_ARRIVE STR,
                                                'GAIN_R' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     (   (    D.TYPE_MUTATION NOT IN
                                                                ('0',
                                                                 '2',
                                                                 '3',
                                                                 '9',
                                                                 '5')
                                                         AND D.GRADE > 39)
                                                     OR (    D.TYPE_MUTATION NOT IN
                                                                ('0', '3', '9', '5')
                                                         AND D.GRADE <= 39))
                                                AND D.D_MR_ARRIVE IS NOT NULL
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE
                                         UNION
                                         SELECT D.CSN_ARRIVE STR,
                                                'INTERNE' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     D.TYPE_MUTATION IN ('0', '9')
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE
                                         UNION
                                         SELECT D.CSN_ARRIVE STR,
                                                'INTERNE_R' OBS,
                                                MATRICULE,
                                                RC.CAT
                                           FROM D_MOUVEMENT_GRH D,
                                                R_GRADE R,
                                                R_CAT_GRADE RC
                                          WHERE     D.TYPE_MUTATION IN ('0', '9')
                                                AND D.D_MR_DEPART IS NOT NULL
                                                AND R.GRADE = D.GRADE
                                                AND R.CAT_GRADE = RC.CAT_GRADE)
                               GROUP BY STR, OBS, CAT
                               UNION
                               SELECT CSN STR,
                                      R.OBS,
                                      F.CAT,
                                      0 CPT
                                 FROM R_CSN D,
                                      (SELECT DISTINCT (CAT)
                                         FROM R_CAT_GRADE
                                        WHERE CAT IN ('1', '2', '3')) F,
                                      (SELECT 'INTERNE' OBS FROM DUAL
                                       UNION
                                       SELECT 'INTERNE_R' OBS FROM DUAL
                                       UNION
                                       SELECT 'GAIN' OBS FROM DUAL
                                       UNION
                                       SELECT 'GAIN_R' OBS FROM DUAL
                                       UNION
                                       SELECT 'PERTE_R' OBS FROM DUAL
                                       UNION
                                       SELECT 'PERTE' OBS FROM DUAL) R
                                WHERE CSN NOT IN ('9999'))
                     GROUP BY STR, OBS, CAT) PIVOT (SUM (CPT)
                                             FOR CAT
                                             IN ('1' OFF, '2' SOFF, '3' HDR))
           ORDER BY STR, OBS)
/

