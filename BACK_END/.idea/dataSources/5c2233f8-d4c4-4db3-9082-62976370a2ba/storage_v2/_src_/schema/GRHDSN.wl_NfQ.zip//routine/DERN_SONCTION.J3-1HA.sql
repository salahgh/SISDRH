create FUNCTION        "DERN_SONCTION" (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT *
  FROM (SELECT ROWNUM R, C.*
          FROM (  SELECT TO_CHAR (S.D_SANCTION, 'YYYY/MM/DD') AS DSANCTION,
                         TRIM (RS.LIB_SANCTION_AR) AS LIB_SONCTION,
                         S.AUTORITE
                    FROM EST_SANCTIONNE S, R_SANCTION RS, GRHDSN.EST_MUTER M
                   WHERE     S.MATRICULE = MAT
                         AND RS.CODE_SANCTION = S.CODE_SANCTION
                         AND S.MATRICULE = M.MATRICULE
                         AND M.D_MUTATION = (SELECT MAX (MM.D_MUTATION)
                                               FROM GRHDSN.EST_MUTER MM
                                              WHERE M.MATRICULE = MM.MATRICULE)
                         AND S.D_SANCTION >= M.D_MUTATION
                ORDER BY S.D_SANCTION DESC) C) WHERE R = 2;

   RESULTAT   VARCHAR2 (250);
BEGIN
   FOR P IN TAB
   LOOP
      RESULTAT :=
            RESULTAT
         || P.LIB_SONCTION
         || ' بتاريخ '
         || P.DSANCTION
         || ' من طرف '
         || P.AUTORITE;
   END LOOP;

   RETURN RESULTAT;
END;
/

