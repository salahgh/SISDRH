create trigger MAJ_EST_STAGIERE
    before update
    on EST_STAGIERE
    for each row
declare x$user varchar2(40); begin x$user := SECTION_EN_COURS;P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'DIPLOME', :old.DIPLOME, :new.DIPLOME, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'D_REF_F_STAGE', :old.D_REF_F_STAGE, :new.D_REF_F_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'REF_F_STAGE', :old.REF_F_STAGE, :new.REF_F_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'D_REF_STAGE', :old.D_REF_STAGE, :new.D_REF_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'REF_STAGE', :old.REF_STAGE, :new.REF_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'D_F_STAGE', :old.D_F_STAGE, :new.D_F_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'D_D_STAGE', :old.D_D_STAGE, :new.D_D_STAGE, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'ETABLISSEMENT', :old.ETABLISSEMENT, :new.ETABLISSEMENT, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'TYPE_ETAB', :old.TYPE_ETAB, :new.TYPE_ETAB, 'MAJ');P_CPR(:new.MATRICULE,x$user,'EST_STAGIERE', 'MATRICULE', :old.MATRICULE, :new.MATRICULE, 'MAJ'); End;

/

