create FUNCTION        SIT_GLOBAL_ABS_2 (STR IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT 'ال' || DECODE(G.GRADE, '90', 'مستخدم مدني شبيه', '91', 'مستخدم مدني متعاقد', G.LIB_GRADE_AR) || ' ' || P.NOMA || ' ' || P.PNOMA
                AS IDENTITE
        FROM GRHDSN.PERSONNELS P,
             GRHDSN.EST_INDISPONIBLE I,
             GRHDSN.R_GRADE G,
             GRHDSN.EST_AFFECT A
       WHERE     P.MATRICULE = I.MATRICULE
             AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
             AND P.GRADE = G.GRADE
             AND (A.MATRICULE, A.D_AFFECTATION) IN
                    (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                         FROM GRHDSN.EST_AFFECT AA
                     GROUP BY AA.MATRICULE)
             AND P.MATRICULE = A.MATRICULE
             AND SUBSTR(A.STRUCT,1,3) = STR
             AND P.CSN = '0000'
             AND P.POSITION LIKE '1%'
             ORDER BY P.GRADE, P.MATRICULE;

   CURSOR COUNTE
   IS
      SELECT COUNT (*) AS CPT
        FROM GRHDSN.PERSONNELS P,
             GRHDSN.EST_INDISPONIBLE I,
             GRHDSN.R_GRADE G,
             GRHDSN.EST_AFFECT A
       WHERE     P.MATRICULE = I.MATRICULE
             AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
             AND P.GRADE = G.GRADE
             AND (A.MATRICULE, A.D_AFFECTATION) IN
                    (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                         FROM GRHDSN.EST_AFFECT AA
                     GROUP BY AA.MATRICULE)
             AND P.MATRICULE = A.MATRICULE
             AND SUBSTR(A.STRUCT,1,3) = STR
             AND P.CSN = '0000'
             AND P.POSITION LIKE '1%'
             ORDER BY P.MATRICULE;

   COMPTE     INTEGER := 0;
   I          INTEGER := 1;


   RESULTAT   VARCHAR2 (600);
BEGIN
   FOR C IN COUNTE
   LOOP
      COMPTE := C.CPT;
   END LOOP;

   FOR P IN TAB
   LOOP
      IF I < COMPTE
      THEN
         RESULTAT := RESULTAT || '' || P.IDENTITE || ' <br> ';
         I := I + 1;
      ELSE
         RESULTAT := RESULTAT || '' || P.IDENTITE;
         
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;
/

