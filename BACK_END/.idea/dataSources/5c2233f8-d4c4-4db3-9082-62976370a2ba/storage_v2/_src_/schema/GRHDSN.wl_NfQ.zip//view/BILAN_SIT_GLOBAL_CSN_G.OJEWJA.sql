create view BILAN_SIT_GLOBAL_CSN_G as
SELECT LIB_CSN_AR AS CSN,
          "OFF",
          "SOFF",
          "HDR",
          "CIV",
          CSN AS C
     FROM (  SELECT S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE,
                                    DECODE (G.CAT_GRADE,
                                            '1', '1',
                                            '2', '1',
                                            '3', '1',
                                            '6', '1',
                                            '4', '2',
                                            '7', '2',
                                            '11', '2',
                                            '5', '3',
                                            '8', '3',
                                            '9', '4',
                                            G.CAT_GRADE)
                                       AS CAT_GRADE,
                                    C.LIB_CSN_AR,
                                    C.CSN
                               FROM GRHDSN.PERSONNELS P,
                                    GRHDSN.R_CSN C,
                                    GRHDSN.R_GRADE G
                              WHERE     P.POSITION LIKE '1%'
                                    AND P.GRADE = G.GRADE
                                    AND C.CSN = SUBSTR (P.CSN, 1, 2) || '00') PIVOT (COUNT (
                                                                                        MATRICULE)
                                                                              FOR CAT_GRADE
                                                                              IN  ('1' AS "OFF",
                                                                                  '2' AS "SOFF",
                                                                                  '3' AS "HDR",
                                                                                  '4' AS "CIV"))) S
           ORDER BY S.CSN)
/

