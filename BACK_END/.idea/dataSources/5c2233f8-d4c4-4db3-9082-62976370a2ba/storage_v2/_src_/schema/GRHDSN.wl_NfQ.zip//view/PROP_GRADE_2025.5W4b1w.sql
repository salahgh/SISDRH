create view PROP_GRADE_2025 as
SELECT P.MATRICULE,
             P.NOMA,
             P.PNOMA,
             P.GRADE,
             P.LIB_GRADE,
             P.METHOD_ENG,
             P.LIB_DIP_AR,
             P.PERIODE,
             P.PROP,
             (SELECT F.LIB_FONCTION_AR
               FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
              WHERE     A.MATRICULE = P.MATRICULE
                    AND A.D_AFFECTATION =
                        (SELECT MAX (AA.D_AFFECTATION)
                          FROM GRHDSN.EST_AFFECT AA
                         WHERE     AA.MATRICULE = A.MATRICULE
                               AND AA.TYPE_FONCT = '0')
                    AND A.TYPE_FONCT = '0'
                    AND A.FONCT = F.FONCTION)                          AS FONCTION,
             (SELECT C.LIB_CSN_AR || '/' || C.REGION
                FROM GRHDSN.PERSONNELS PP, GRHDSN.R_CSN C
               WHERE PP.MATRICULE = P.MATRICULE AND PP.CSN = C.CSN)    AS STRUCTURE
        FROM ((SELECT "MATRICULE",
                      "NOMA",
                      "PNOMA",
                      "GRADE",
                      "LIB_GRADE",
                      "METHOD_ENG",
                      "LIB_DIP_AR",
                      "PERIODE",
                      "PROP"
                 FROM (SELECT P.MATRICULE,
                              P.NOMA,
                              P.PNOMA,
                              P.GRADE,
                              G.LIB_GRADE_AR
                                  AS LIB_GRADE,
                              E.METHOD_ENG,
                              D.LIB_DIP_AR,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY'))
                                  AS PERIODE,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY') - 5)
                                  AS PROP
                         FROM GRHDSN.PERSONNELS   P,
                              GRHDSN.EST_NOMINER_G N,
                              GRHDSN.R_GRADE      G,
                              GRHDSN.R_DIPLOME    D,
                              GRHDSN.A_SIGNER     E
                        WHERE     P.MATRICULE = N.MATRICULE
                              AND E.MATRICULE = P.MATRICULE
                              AND E.NIVEAU = D.DIP
                              AND (   P.POSITION LIKE '1%'
                                   OR P.POSITION LIKE '2%'
                                   OR P.POSITION LIKE '3%')
                              AND G.GRADE = P.GRADE
                              AND P.ARME != '31'
                              AND N.D_NOMIN =
                                  (SELECT MAX (NN.D_NOMIN)
                                     FROM GRHDSN.EST_NOMINER_G NN
                                    WHERE N.MATRICULE = NN.MATRICULE)
                              AND P.GRADE BETWEEN 1 AND 31)
                WHERE PERIODE >= 5
               UNION
               SELECT "MATRICULE",
                      "NOMA",
                      "PNOMA",
                      "GRADE",
                      "LIB_GRADE",
                      "METHOD_ENG",
                      "LIB_DIP_AR",
                      "PERIODE",
                      "PROP"
                 FROM (SELECT P.MATRICULE,
                              P.NOMA,
                              P.PNOMA,
                              P.GRADE,
                              G.LIB_GRADE_AR
                                  AS LIB_GRADE,
                              E.METHOD_ENG,
                              D.LIB_DIP_AR,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY'))
                                  AS PERIODE,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY') - 4)
                                  AS PROP
                         FROM GRHDSN.PERSONNELS   P,
                              GRHDSN.EST_NOMINER_G N,
                              GRHDSN.R_GRADE      G,
                              GRHDSN.A_SIGNER     E,
                              GRHDSN.R_DIPLOME    D
                        WHERE     P.MATRICULE = N.MATRICULE
                              AND E.MATRICULE = P.MATRICULE
                              AND E.NIVEAU = D.DIP
                              AND (P.POSITION LIKE '1%' OR P.POSITION LIKE '2%')
                              AND G.GRADE = P.GRADE
                              AND D.DIP != '0014'
                              AND P.ARME != '31'
                              AND N.D_NOMIN =
                                  (SELECT MAX (NN.D_NOMIN)
                                     FROM GRHDSN.EST_NOMINER_G NN
                                    WHERE N.MATRICULE = NN.MATRICULE)
                              AND P.GRADE = '33')
                WHERE PERIODE >= 4
               UNION
               SELECT "MATRICULE",
                      "NOMA",
                      "PNOMA",
                      "GRADE",
                      "LIB_GRADE",
                      "METHOD_ENG",
                      "LIB_DIP_AR",
                      "PERIODE",
                      "PROP"
                 FROM (SELECT P.MATRICULE,
                              P.NOMA,
                              P.PNOMA,
                              P.GRADE,
                              G.LIB_GRADE_AR
                                  AS LIB_GRADE,
                              E.METHOD_ENG,
                              D.LIB_DIP_AR,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY'))
                                  AS PERIODE,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY') - 4)
                                  AS PROP
                         FROM GRHDSN.PERSONNELS   P,
                              GRHDSN.EST_NOMINER_G N,
                              GRHDSN.R_GRADE      G,
                              GRHDSN.A_SIGNER     E,
                              GRHDSN.R_DIPLOME    D
                        WHERE     P.MATRICULE = N.MATRICULE
                              AND E.MATRICULE = P.MATRICULE
                              AND E.NIVEAU = D.DIP
                              AND (P.POSITION LIKE '1%' OR P.POSITION LIKE '2%')
                              AND G.GRADE = P.GRADE
                              AND D.DIP = '0014'
                              AND P.ARME != '31'
                              AND N.D_NOMIN =
                                  (SELECT MAX (NN.D_NOMIN)
                                     FROM GRHDSN.EST_NOMINER_G NN
                                    WHERE N.MATRICULE = NN.MATRICULE)
                              AND P.GRADE = '33')
                WHERE PERIODE >= 4
               UNION
               SELECT "MATRICULE",
                      "NOMA",
                      "PNOMA",
                      "GRADE",
                      "LIB_GRADE",
                      "METHOD_ENG",
                      "LIB_DIP_AR",
                      "PERIODE",
                      "PROP"
                 FROM (SELECT P.MATRICULE,
                              P.NOMA,
                              P.PNOMA,
                              P.GRADE,
                              G.LIB_GRADE_AR
                                  AS LIB_GRADE,
                              E.METHOD_ENG,
                              D.LIB_DIP_AR,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY'))
                                  AS PERIODE,
                              (2025 - TO_CHAR (N.D_NOMIN, 'YYYY') - 3)
                                  AS PROP
                         FROM GRHDSN.PERSONNELS   P,
                              GRHDSN.EST_NOMINER_G N,
                              GRHDSN.R_GRADE      G,
                              GRHDSN.A_SIGNER     E,
                              GRHDSN.R_DIPLOME    D
                        WHERE     P.MATRICULE = N.MATRICULE
                              AND E.MATRICULE = P.MATRICULE
                              AND E.NIVEAU = D.DIP
                              AND (P.POSITION LIKE '1%' OR P.POSITION LIKE '2%')
                              AND G.GRADE = P.GRADE
                              AND P.ARME != '31'
                              AND N.D_NOMIN =
                                  (SELECT MAX (NN.D_NOMIN)
                                     FROM GRHDSN.EST_NOMINER_G NN
                                    WHERE N.MATRICULE = NN.MATRICULE)
                              AND P.GRADE = '35')
                WHERE PERIODE >= 3)) P
    ORDER BY GRHDSN.CODE_GRD_ANNEE (MATRICULE)
/

