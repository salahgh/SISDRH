create PROCEDURE       RAF_EST_RECRUTE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_RECRUTE@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_RECRUTE  
where  MATRICULE=vcur.MATRICULE and D_RECRUT=vcur.D_RECRUT 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_RECRUTE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_RECRUTE  
(  MATRICULE ,D_RECRUT ,AVIS_RECRUT ,D_AVIS_RECRUT ,UNITE ,NIVEAU ,GRADE )  
values(  vcur.MATRICULE ,vcur.D_RECRUT ,vcur.AVIS_RECRUT ,vcur.D_AVIS_RECRUT ,vcur.UNITE ,vcur.NIVEAU ,vcur.GRADE 
) ; 
end if ;
else 
update  EST_RECRUTE set  
AVIS_RECRUT=vcur.AVIS_RECRUT,
D_AVIS_RECRUT=vcur.D_AVIS_RECRUT,
UNITE=vcur.UNITE,
NIVEAU=vcur.NIVEAU,
GRADE=vcur.GRADE
where  MATRICULE=vcur.MATRICULE and D_RECRUT=vcur.D_RECRUT 
 ; 
end if ;
else
delete from EST_RECRUTE   
where  MATRICULE=vcur.MATRICULE and D_RECRUT=vcur.D_RECRUT 
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_RECRUTE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_RECRUTE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

