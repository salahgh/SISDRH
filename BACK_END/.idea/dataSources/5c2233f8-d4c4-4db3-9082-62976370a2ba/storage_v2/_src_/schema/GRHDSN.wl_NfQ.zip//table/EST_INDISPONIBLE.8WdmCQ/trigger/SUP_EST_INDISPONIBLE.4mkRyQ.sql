create trigger SUP_EST_INDISPONIBLE
    before delete
    on EST_INDISPONIBLE
    for each row
DECLARE
   x$user   VARCHAR2 (40);
BEGIN
   x$user := SECTION_EN_COURS;
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'OBS',
          :old.OBS,
          :new.OBS,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'MOTIF',
          :old.MOTIF,
          :new.MOTIF,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'CODE_DIST',
          :old.CODE_DIST,
          :new.CODE_DIST,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'NBR_JOURS',
          :old.NBR_JOURS,
          :new.NBR_JOURS,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'D_F_ABS',
          :old.D_F_ABS,
          :new.D_F_ABS,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'D_D_ABS',
          :old.D_D_ABS,
          :new.D_D_ABS,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'CODE_ABS',
          :old.CODE_ABS,
          :new.CODE_ABS,
          'SUP');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_INDISPONIBLE',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'SUP');
  INSERT INTO CORBEILLE.EST_INDISPONIBLE ( MATRICULE,CODE_ABS,D_D_ABS,D_F_ABS,NBR_JOURS,CODE_DIST,MOTIF,OBS ) VALUES (  :OLD.MATRICULE, :OLD.CODE_ABS, :OLD.D_D_ABS, :OLD.D_F_ABS, :OLD.NBR_JOURS, :OLD.CODE_DIST, :OLD.MOTIF, :OLD.OBS );

END;
/

