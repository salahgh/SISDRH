create FUNCTION "ARBRE_TABLE_MAT" ( mat varchar2, tab varchar2) return varchar2 is 
nbr   NUMBER(5):=0;
instr varchar(30000):=null;
var varchar2(30000):=NULL;
ex varchar2(30000):=null;
begin

instr:= 'select count(*) from '||tab||' where matricule = '||mat; 

execute immediate instr into ex;
if (ex  = 1) then var := var||tab;  end if;
return (VAR);
EXCEPTION when INVALID_NUMBER then 
return (VAR); 
end;


/

