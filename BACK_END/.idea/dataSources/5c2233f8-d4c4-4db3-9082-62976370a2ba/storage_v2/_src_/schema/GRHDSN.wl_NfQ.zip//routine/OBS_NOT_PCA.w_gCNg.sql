create FUNCTION        OBS_NOT_PCA (V$MAT       IN VARCHAR2,
                                               V$ANNEE   IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR COUNTE
   IS
      SELECT COUNT (N.MATRICULE) AS CPT
        FROM GRHDSN.EST_NOTE_PCA N
       WHERE N.MATRICULE = V$MAT AND N.ANNEE = V$ANNEE;

   CURSOR TAB
   IS
      SELECT TO_NUMBER(DECODE(N.CONT_TRAV, '1', '6', '2', '4,8', '3', '4,2', '4', '3,6', '5', '3', null)) +
       TO_NUMBER(DECODE(N.QUALITEE_TRAV, '1', '3', '2', '2,4', '3', '2,1', '4', '1,8', '5', '1,5', null)) +
       TO_NUMBER(DECODE(N.CONAIS_TRAV, '1', '2', '2', '1,6', '3', '1,4', '4', '1,2', '5', '1', null)) +
       TO_NUMBER(DECODE(N.PRECISION, '1', '4', '2', '3,2', '3', '2,8', '4', '2,4', '5', '2', null)) +
       TO_NUMBER(DECODE(N.CONDUITE, '1', '3', '2', '2,4', '3', '2,1', '4', '1,8', '5', '1,5', null)) +
       TO_NUMBER(DECODE(N.CONFIDENTIALITE, '1', '1', '2', '0,8', '3', '0,7', '4', '0,6', '5', '0,5', null)) +
       TO_NUMBER(DECODE(N.SANTE, '1', '1', '2', '0,8', '3', '0,7', '4', '0,6', '5', '0,5', null)) AS NOTE
        FROM GRHDSN.EST_NOTE_PCA N
       WHERE N.MATRICULE = V$MAT AND N.ANNEE = V$ANNEE;


   COMPTE     INTEGER := 0;
   RESULTAT   VARCHAR2 (250) := null;
BEGIN
   FOR C IN COUNTE
   LOOP
      COMPTE := C.CPT;
   END LOOP;
 DBMS_OUTPUT.PUT_LINE(COMPTE);
   FOR P IN TAB
   LOOP
      IF COMPTE = 0
      THEN
         RESULTAT := '/';
      ELSE
         RESULTAT := P.NOTE;
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;

/

