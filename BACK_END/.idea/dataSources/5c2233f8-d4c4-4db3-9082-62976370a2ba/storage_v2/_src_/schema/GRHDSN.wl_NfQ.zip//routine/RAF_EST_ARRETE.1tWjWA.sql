create PROCEDURE       RAF_EST_ARRETE (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_ARRETE@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_ARRETE  
where  MATRICULE=vcur.MATRICULE and D_D_ARRET=vcur.D_D_ARRET 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_ARRETE@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_ARRETE  
(  MATRICULE ,D_D_ARRET ,D_F_ARRET ,REF_ARRET ,D_REF_ARRET ,REF_CESS_ARRET ,D_REF_CESS_ARRET ,UNITEE )  
values(  vcur.MATRICULE ,vcur.D_D_ARRET ,vcur.D_F_ARRET ,vcur.REF_ARRET ,vcur.D_REF_ARRET ,vcur.REF_CESS_ARRET ,vcur.D_REF_CESS_ARRET ,vcur.UNITEE 
) ; 
end if ;
else 
update  EST_ARRETE set  
D_F_ARRET=vcur.D_F_ARRET,
REF_ARRET=vcur.REF_ARRET,
D_REF_ARRET=vcur.D_REF_ARRET,
REF_CESS_ARRET=vcur.REF_CESS_ARRET,
D_REF_CESS_ARRET=vcur.D_REF_CESS_ARRET,
UNITEE=vcur.UNITEE
where  MATRICULE=vcur.MATRICULE and D_D_ARRET=vcur.D_D_ARRET 
 ; 
end if ;
else
delete from EST_ARRETE   
where  MATRICULE=vcur.MATRICULE and D_D_ARRET=vcur.D_D_ARRET 
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_ARRETE@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_ARRETE@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

