create view BILAN_SIT_GLOBAL_CSN_OFF as
SELECT LIB_CSN_AR AS CSN,
          "لواء",
          "عميد",
          "عقيد",
          "مقدم",
          "رائد",
          "نقيب",
          "ملازم أول",
          "ملازم"
     FROM (  SELECT S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE,
                                    P.GRADE,
                                    C.LIB_CSN_AR,
                                    C.CSN
                               FROM GRHDSN.PERSONNELS P, GRHDSN.R_CSN C
                              WHERE     P.POSITION LIKE '1%' AND P.ARME != '31'
                                    AND C.CSN = SUBSTR (P.CSN, 1, 2) || '00') PIVOT (COUNT (
                                                                                        MATRICULE)
                                                                              FOR GRADE
                                                                              IN  ('16' AS "لواء",
                                                                                  '18' AS "عميد",
                                                                                  '22' AS "عقيد",
                                                                                  '24' AS "مقدم",
                                                                                  '26' AS "رائد",
                                                                                  '31' AS "نقيب",
                                                                                  '33' AS "ملازم أول",
                                                                                  '35' AS "ملازم"))) S
           ORDER BY S.CSN)
/

