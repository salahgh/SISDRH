create PROCEDURE        MOUV_PROC (P$MAT NUMBER)
AS
   V$CON_MOUV     INTEGER;
   V$CSN_DEPART   VARCHAR (10);
   V$CSN_ARRIVE   VARCHAR (10);

   CURSOR CUR
   IS
        SELECT TABLE_NAME,
               DECODE (TABLE_NAME,  'PERSONNELS', '0',  'CONJOIN', '1',  '2')
                  AS ORDRE
          FROM (SELECT T.TABLE_NAME
                  FROM SYS.ALL_TABLES T
                 WHERE ( T.TABLE_NAME IN
                            ('PERSONNELS',
                             'INFO_PLUS',
                             'A_DESERTER',
                             'CONJOIN',
                             'DEMANDE_PERMISSION',
                             'DICISION',
                             'FICHE_VOEUX',
                             'MISE_ROUTE',
                             'PHOTOS',
                             'A_SIGNER')
                      OR T.TABLE_NAME LIKE 'EST_%') AND T.TABLE_NAME NOT IN ('EST_PRESENT', 'EST_AFFECTER') AND T.OWNER = 'GRHDSN')
      ORDER BY ORDRE;
BEGIN
   SELECT DECODE (SUBSTR (M.CSN_ARRIVE, 1, 1),
                  '0', '10',
                  '2', SUBSTR (M.CSN_ARRIVE, 2, 2),
                  (SELECT B.CSN
                     FROM GRHDSN.R_BSN B
                    WHERE B.BSN = SUBSTR (M.CSN_ARRIVE, 2, 2)))
     INTO V$CSN_ARRIVE
     FROM GRHDSN.A_MOUVEMENT M
    WHERE P$MAT = M.MATRICULE AND M.ANNEE = TO_CHAR (SYSDATE, 'YYYY');

   SELECT DECODE (SUBSTR (M.CSN_DEPART, 1, 1),
                  '0', '10',
                  '2', SUBSTR (M.CSN_DEPART, 2, 2),
                  (SELECT B.CSN
                     FROM GRHDSN.R_BSN B
                    WHERE B.BSN = SUBSTR (M.CSN_DEPART, 2, 2)))
     INTO V$CSN_DEPART
     FROM GRHDSN.A_MOUVEMENT M
    WHERE P$MAT = M.MATRICULE AND M.ANNEE = TO_CHAR (SYSDATE, 'YYYY');

   SELECT COUNT (*)
     INTO V$CON_MOUV
     FROM A_MOUVEMENT M
    WHERE     P$MAT = M.MATRICULE
          AND M.ANNEE = TO_CHAR (SYSDATE, 'YYYY')
          AND M.MER = 'O'
          AND M.J_ARRIVE IS NULL;

   IF V$CON_MOUV >= 0
   THEN
      FOR T IN CUR
      LOOP
         IF V$CSN_ARRIVE = '10' OR V$CSN_ARRIVE IS NULL
         THEN
            -- NE RIEN FAIRE JUSTE UNE REPLICATION
            NULL;
         ELSE
            EXECUTE IMMEDIATE (CREATE_INSERT_GLOB (P$MAT, T.TABLE_NAME, V$CSN_ARRIVE));
            --DBMS_OUTPUT.PUT_LINE (CREATE_INSERT_GLOB (P$MAT, T.TABLE_NAME, V$CSN_ARRIVE));
         END IF;
      END LOOP;
   END IF;
   UPDATE GRHDSN.A_MOUVEMENT M
      SET M.J_DEPART = SYSDATE
    WHERE M.MATRICULE = P$MAT AND M.ANNEE = TO_CHAR (SYSDATE, 'YYYY');
    
   UPDATE GRHDSN.PERSONNELS P SET P.CSN = V$CSN_ARRIVE WHERE P.MATRICULE = P$MAT;
   IF V$CSN_DEPART = '10' THEN
   EXECUTE IMMEDIATE ('UPDATE GRHDSN.PERSONNELS P SET P.ARCHIVER = ''1'' WHERE P.MATRICULE = '''||P$MAT||'''');
   ELSE
   EXECUTE IMMEDIATE ('UPDATE GRHDSN.PERSONNELS@GRHDSN'|| V$CSN_DEPART || ' P SET P.ARCHIVER = ''1'' WHERE P.MATRICULE = '''||P$MAT||'''');
   END IF;
   IF V$CSN_ARRIVE != '10' THEN
   EXECUTE IMMEDIATE ('UPDATE GRHDSN.PERSONNELS@GRHDSN'|| V$CSN_ARRIVE || ' P SET P.ARCHIVER = ''1'', P.CSN = '''|| V$CSN_ARRIVE || ''' WHERE P.MATRICULE = '''||P$MAT||'''');
   END IF;
   COMMIT;
END;
/

