create view VV_PERSONNELS_DIPLOME as
select PERSONNELS.MATRICULE,
       NOMA,
       PNOMA,
       NOM,
       PNOM,
       LIB_GRADE_AR,
       PERSONNELS.GRADE,
       POSITION,
       case
           when substr(R_CSN.CSN, 0, 1) = '0' then LIB_CSN_AR || '/و د و'
           else LIB_CSN_AR || '/ ن ع ' || substr(R_CSN.CSN, 0, 1)
           end                                                                                   lib_csn,
       dc.LIB_DIP_AR                as                                                           diplome_civile,
       dc.DIPLOME                   as                                                           code_diplome_civile,
       dc.D_F_STAGE           as D_F_STAGE_civile ,
       diplome_militaire.LIB_DIP_AR as                                                           diplome_militaire,
       diplome_militaire.DIPLOME    as                                                           code_diplome_militaire,
       diplome_militaire.D_F_STAGE as D_F_STAGE_militaire ,
       --------------------------------------------------------------------
       case
           when POSITION like '1%' then -extract(year from diplome_militaire.D_F_STAGE) + extract(year from sysdate)
           else 0 end                                                                            rendement_mil_exacte,
       case
           when POSITION like '2%' then 0
           when (POSITION like '1%' and
                 -extract(year from diplome_militaire.D_F_STAGE) + extract(year from sysdate) > 3) then 4
           else -extract(year from diplome_militaire.D_F_STAGE) + extract(year from sysdate) end rendement_mil,
       --------------------------------------------------------------------
       case
           when POSITION like '1%' then -extract(year from dc.D_F_STAGE) + extract(year from sysdate)
           else 0 end                                                                            rendement_civile_exacte,
       case
           when POSITION like '1%' and -extract(year from dc.D_F_STAGE) + extract(year from sysdate) > 3 then 4
           when POSITION like '1%' and -extract(year from dc.D_F_STAGE) + extract(year from sysdate) <= 3 then -extract(year from dc.D_F_STAGE) + extract(year from sysdate)
           else 0 end                rendement_civ


from PERSONNELS
         inner join R_GRADE on PERSONNELS.GRADE = R_GRADE.GRADE
         inner join R_CSN on PERSONNELS.CSN = R_CSN.CSN
         left join (select max_stage.MATRICULE,
                           D_D_STAGE,
                           D_F_STAGE,
                           DIPLOME,
                           LIB_DIP_AR
                    from EST_STAGIERE
                             inner join (
                        select MATRICULE, max(D_F_STAGE) as max_d_f_stage
                        from EST_STAGIERE
                        where DIPLOME like '1%'
--         and MATRICULE = 201709008217
                        group by MATRICULE
                    ) max_stage on max_stage.MATRICULE = EST_STAGIERE.MATRICULE and max_d_f_stage = D_F_STAGE
                             inner join R_DIPLOME on EST_STAGIERE.DIPLOME = R_DIPLOME.DIP) diplome_militaire
                   on PERSONNELS.MATRICULE = diplome_militaire.MATRICULE
         inner join (
    select EST_STAGIERE.MATRICULE as MATRICULE,
           EST_STAGIERE.D_D_STAGE,
           EST_STAGIERE.D_F_STAGE,
           EST_STAGIERE.DIPLOME,
           dip.LIB_DIP_AR
    from EST_STAGIERE
             inner join R_DIPLOME dip on EST_STAGIERE.DIPLOME = dip.DIP
             inner join tmp_max_diplome_civile
                        on tmp_max_diplome_civile.MATRICULE = EST_STAGIERE.MATRICULE
                            and dip.NIVEAU = tmp_max_diplome_civile.min_niv
    where dip.DIP like '0%'
--              and EST_STAGIERE.MATRICULE = 201709008217
) dc
                    on PERSONNELS.MATRICULE = dc.MATRICULE
where R_GRADE.GRADE <= 35
  and ARME <> 31
  and (POSITION like '1%' or POSITION like '2%')
--   and PERSONNELS.MATRICULE = 201709008217
order by R_CSN.CSN, R_GRADE.GRADE
/

