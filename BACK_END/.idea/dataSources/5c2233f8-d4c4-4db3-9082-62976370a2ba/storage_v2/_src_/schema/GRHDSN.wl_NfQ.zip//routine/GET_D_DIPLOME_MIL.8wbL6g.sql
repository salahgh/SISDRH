create FUNCTION        GET_D_DIPLOME_MIL (MAT IN VARCHAR2)
   RETURN DATE
IS
   CURSOR CUR
   IS
      SELECT D_F_STAGE  AS D_F_STAGE
        FROM (  SELECT D_F_STAGE, MIN (NIVEAU)
                  FROM (SELECT S.D_F_STAGE, D.NIVEAU
                          FROM GRHDSN.EST_STAGIERE S,
                               GRHDSN.R_DIPLOME D
                         WHERE     S.MATRICULE = MAT
                               AND S.D_F_STAGE =
                                      (SELECT MAX (SS.D_F_STAGE)
                                         FROM GRHDSN.EST_STAGIERE SS
                                        WHERE     SS.MATRICULE = S.MATRICULE
                                              AND SS.DIPLOME LIKE '1%')
                               AND S.DIPLOME LIKE '1%'
                               AND S.DIPLOME = D.DIP)
              GROUP BY D_F_STAGE);

   V$RESULTAT   DATE;
BEGIN
   FOR C IN CUR
   LOOP
      V$RESULTAT := C.D_F_STAGE;
   END LOOP;

   RETURN V$RESULTAT;
END;
/

