create trigger CONJOIN_TRG
    before insert
    on CONJOIN
    for each row
BEGIN
-- For Toad:  Highlight column ID_CONJOIN
IF :new.ID_CONJOIN IS NULL THEN
  :new.ID_CONJOIN := CONJOIN_SEQ.nextval;
  END IF;
END CONJOIN_TRG;
/

