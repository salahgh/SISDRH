create view ETATSIGNAL as
SELECT P.MATRICULE,
          TO_CHAR (M.D_MUTATION, 'YYYY/MM/DD') AS DDATE,
          'MUTATION' AS MOTIF,
          DECODE (M.REF_MUT, NULL, '/', M.REF_MUT) AS RREF,
             'حول إلى '
          || TRIM (U.LIB_UNITEE_AR)
          || DECODE (U.REGION, '0', '/و.د.و', '/ن.ع')
          || DECODE (U.REGION, '0', NULL, U.REGION)
             AS OBS,
          DECODE (
             GRHDSN.GRADE_MUT (P.MATRICULE, M.D_MUTATION),
             NULL, (SELECT G.ABR_GRADE_AR
                      FROM GRHDSN.A_SIGNER E, GRHDSN.R_GRADE G
                     WHERE     MATRICULE = P.MATRICULE
                           AND G.GRADE = E.GRADE
                           AND E.TYPE_ENG = 0),
             GRHDSN.GRADE_MUT (P.MATRICULE, M.D_MUTATION))
             AS GRADE
     FROM EST_MUTER M, PERSONNELS P, R_UNITEE U
    WHERE     P.MATRICULE != 0
          AND P.MATRICULE = M.MATRICULE(+)
          AND U.UNITEE = M.UNITEE
   UNION
   SELECT P.MATRICULE,
          TO_CHAR (E.D_ENG, 'YYYY/MM/DD') AS DDATE,
          '//ENG//' AS MOTIF,
          DECODE (E.AVIS_ENG, NULL, '/', E.AVIS_ENG) AS RREF,
             'جند ب'
          || TRIM (U.LIB_UNITEE_AR)
          || DECODE (U.REGION, '0', '/و.د.و', '/ن.ع')
          || DECODE (U.REGION, '0', NULL, U.REGION)
             AS OBS,
          TRIM (G.ABR_GRADE_AR) AS GRADE
     FROM A_SIGNER E,
          PERSONNELS P,
          R_UNITEE U,
          R_GRADE G
    WHERE     P.MATRICULE = E.MATRICULE(+)
          AND P.MATRICULE != 0
          AND E.TYPE_ENG = 0
          AND E.UNITEE = U.UNITEE
          AND G.GRADE = E.GRADE
   UNION
   SELECT P.MATRICULE,
          TO_CHAR (N.D_NOMIN, 'YYYY/MM/DD') AS DDATE,
          '//NOMINATION//' AS MOTIF,
          DECODE (N.REF_NOMIN, NULL, '/', N.REF_NOMIN) AS RREF,
          'رقي إلى رتبة ' || TRIM (G.LIB_GRADE_AR) AS OBS,
          TRIM (G.LIB_GRADE_AR) AS GRADE
     FROM EST_NOMINER_G N, PERSONNELS P, R_GRADE G
    WHERE     P.MATRICULE = N.MATRICULE(+)
          AND P.MATRICULE != 0
          AND G.GRADE = N.GRADE
   UNION
   SELECT P.MATRICULE,
          TO_CHAR (E.D_ENG, 'YYYY/MM/DD') AS DDATE,
          '//RENG//' AS MOTIF,
          DECODE (E.AVIS_ENG, NULL, '/', E.AVIS_ENG) AS RREF,
             'أعاد التجنيد ب'
          || TRIM (U.LIB_UNITEE_AR)
          || DECODE (U.REGION, '0', '/و.د.و', '/ن.ع')
          || DECODE (U.REGION, '0', NULL, U.REGION)
             AS OBS,
          TRIM (G.LIB_GRADE_AR) AS GRADE
     FROM A_SIGNER E,
          PERSONNELS P,
          R_UNITEE U,
          R_GRADE G
    WHERE     P.MATRICULE = E.MATRICULE(+)
          AND P.MATRICULE != 0
          AND E.TYPE_ENG = 1
          AND E.UNITEE = U.UNITEE
          AND G.GRADE = E.GRADE
   ORDER BY MATRICULE, DDATE
/

