create PROCEDURE        SUIVI_PANDEMIE
AS
BEGIN
   INSERT INTO GRHDSN.D_SUIVI_PANDEMIE
      (SELECT *
         FROM (  SELECT TRUNC (SYSDATE),
                        P.MATRICULE,
                        DECODE (I.CODE_ABS, '26', '01', NULL) AS TYPE_PANDEMIE,
                        C.CSN,
                        P.GRADE
                   FROM GRHDSN.PERSONNELS P,
                        GRHDSN.EST_INDISPONIBLE I,
                        GRHDSN.R_CSN C
                  WHERE     I.MATRICULE = P.MATRICULE
                        AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
                        AND I.CODE_ABS IN ('26')
                        AND SUBSTR (P.CSN, 1, 2) || '00' = C.CSN
               ORDER BY SUBSTR (C.CSN, 1, 2), P.GRADE, P.MATRICULE));
END;
/

