create FUNCTION        "CREATE_TRIGGER_SUITE" (V$TABLE    VARCHAR2,
                                                    V$OP       VARCHAR2,
                                                    V$TRAIT    VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
        SELECT T.TABLE_NAME, C.COLUMN_NAME
          FROM SYS.ALL_TABLES T, SYS.ALL_TAB_COLUMNS C
         WHERE     T.OWNER = 'GRHDSN'
               AND T.TABLE_NAME = V$TABLE
               AND C.TABLE_NAME = T.TABLE_NAME
               AND C.OWNER = T.OWNER
      ORDER BY T.TABLE_NAME;

   CURSOR COL
   IS
      SELECT C.COLUMN_NAME, C.DATA_TYPE
        FROM SYS.ALL_TAB_COLS C
       WHERE C.OWNER = 'GRHDSN' AND C.TABLE_NAME = V$TABLE;

   V$RESULTAT   VARCHAR2 (32767)
      :=    'CREATE OR REPLACE TRIGGER '
         || V$OP
         || '_'
         || V$TABLE
         || ' AFTER '
         || V$TRAIT
         || ' on '
         || V$TABLE
         || ' for each row declare x$user varchar2(40); CURSOR CUR IS SELECT CONDITION, MSG, ERR FROM GRHDSN.A_CONTROLE_MAJ WHERE BLOC = '''||V$TABLE||'''; x$request   VARCHAR2 (1000); x$count     INTEGER; x$message   VARCHAR2 (255); begin x$user := SECTION_EN_COURS; FOR C IN CUR LOOP x$request := ''SELECT COUNT(*) FROM DUAL WHERE ''|| C.CONDITION; ';
BEGIN
   FOR C IN COL LOOP
       IF C.DATA_TYPE IN ('VARCHAR2', 'CHAR', 'DATE') THEN
           V$RESULTAT := V$RESULTAT || 'x$request := replace(x$request, ''V$'||C.COLUMN_NAME||''', ''''''''||:new.'||C.COLUMN_NAME||'||'''''''');';
       ELSE
           V$RESULTAT := V$RESULTAT || 'x$request := replace(x$request, ''V$'||C.COLUMN_NAME||''', :new.'||C.COLUMN_NAME||'); ';
       END IF;
   END LOOP;
   V$RESULTAT := V$RESULTAT || 'EXECUTE IMMEDIATE (x$request) INTO x$count; IF (x$count > 0) THEN x$message := C.MSG; RAISE_APPLICATION_ERROR (''-20101'', ''خطأ رقم : ''||C.ERR||'' : ''||x$message, TRUE); END IF; END LOOP;';
   /*FOR P IN TAB
   LOOP
      V$RESULTAT :=
            V$RESULTAT
         || 'P_CPR(:new.MATRICULE,x$user,'
         || ''''
         || P.TABLE_NAME
         || ''''
         || ', '
         || ''''
         || P.COLUMN_NAME
         || ''''
         || ', :old.'
         || P.COLUMN_NAME
         || ', :new.'
         || P.COLUMN_NAME
         || ', '''
         || V$OP
         || ''');';
   END LOOP;*/
   RETURN V$RESULTAT;
END;
/

