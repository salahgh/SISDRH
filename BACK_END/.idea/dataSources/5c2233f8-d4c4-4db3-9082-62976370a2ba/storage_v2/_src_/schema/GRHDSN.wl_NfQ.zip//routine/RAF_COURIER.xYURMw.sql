create PROCEDURE       RAF_COURIER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.COURIER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from COURIER  
where  MATRICULE=vcur.MATRICULE and EXP=vcur.EXP and D_ENVOIE=vcur.D_ENVOIE 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.COURIER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into COURIER  
(  MATRICULE ,EXP ,DIST ,D_ENVOIE ,TYPE_MESS ,CONTENU ,MESSAGE ,CSN )  
values(  vcur.MATRICULE ,vcur.EXP ,vcur.DIST ,vcur.D_ENVOIE ,vcur.TYPE_MESS ,vcur.CONTENU ,vcur.MESSAGE ,vcur.CSN 
) ; 
end if ;
else 
update  COURIER set  
DIST=vcur.DIST,
TYPE_MESS=vcur.TYPE_MESS,
CONTENU=vcur.CONTENU,
MESSAGE=vcur.MESSAGE,
CSN=vcur.CSN
where  MATRICULE=vcur.MATRICULE and EXP=vcur.EXP and D_ENVOIE=vcur.D_ENVOIE 
 ; 
end if ;
else
delete from COURIER   
where  MATRICULE=vcur.MATRICULE and EXP=vcur.EXP and D_ENVOIE=vcur.D_ENVOIE 
 ; ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.COURIER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.COURIER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

