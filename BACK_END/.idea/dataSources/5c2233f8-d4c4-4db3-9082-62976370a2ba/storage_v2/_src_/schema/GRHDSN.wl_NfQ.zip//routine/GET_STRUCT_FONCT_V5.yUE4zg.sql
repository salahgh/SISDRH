create FUNCTION        GET_STRUCT_FONCT_V5 (FONCTION IN NUMBER)
   RETURN VARCHAR2
IS
   RESULTAT          VARCHAR2 (1000) := '';
   V$LIB_STRUCTURE   VARCHAR2 (1000) := '';
   V$STRUCTURE       VARCHAR2 (20) := '';
   V$FONCTION        VARCHAR2 (20) := FONCTION;
   V$COMPTE          INT := 0;
BEGIN
   WHILE V$COMPTE = 0
   LOOP
      SELECT COUNT (1)
        INTO V$COMPTE
        FROM (SELECT RPAD (SUBSTR (FONCT, 1, LONGUEUR - 1), 13, '0')
                        AS STRUCTURE
                FROM (SELECT RTRIM (
                                DECODE (S.STRUCTURE,
                                        '0180000000000', '0060000000000',
                                        '0110000000000', '0060000000000',
                                        S.STRUCTURE),
                                '0')
                                AS FONCT,
                             LENGTH (RTRIM (S.STRUCTURE, '0')) AS LONGUEUR
                        FROM GRHDSN.R_STRUCT S
                       WHERE S.STRUCTURE = V$FONCTION AND S.PARENT = '1')) S,
             GRHDSN.R_STRUCT SS
       WHERE S.STRUCTURE = SS.STRUCTURE;

      IF (V$COMPTE > 0)
      THEN
         SELECT SS.STRUCTURE
           INTO V$STRUCTURE
           FROM (SELECT RPAD (SUBSTR (FONCT, 1, LONGUEUR - 1), 13, '0')
                           AS STRUCTURE
                   FROM (SELECT RTRIM (
                                   DECODE (S.STRUCTURE,
                                           '0180000000000', '0060000000000',
                                           '0110000000000', '0060000000000',
                                           S.STRUCTURE),
                                   '0')
                                   AS FONCT,
                                LENGTH (RTRIM (S.STRUCTURE, '0')) AS LONGUEUR
                           FROM GRHDSN.R_STRUCT S
                          WHERE S.STRUCTURE = V$FONCTION AND S.PARENT = '1')) S,
                GRHDSN.R_STRUCT SS
          WHERE S.STRUCTURE = SS.STRUCTURE;
      ELSE
         V$FONCTION :=
            RPAD (
               SUBSTR (RTRIM (V$FONCTION, '0'),
                       1,
                       LENGTH (RTRIM (V$FONCTION, '0')) - 1),
               13,
               '0');
      END IF;
   V$STRUCTURE := V$FONCTION;
   END LOOP;
   FOR C
      IN (SELECT SS.LIB_STRUCTURE_AR, SS.STRUCTURE
            FROM (SELECT FONCT
                            AS STRUCTURE
                    FROM (SELECT 
                                    DECODE (S.STRUCTURE,
                                            '0180000000000', '0060000000000',
                                            '0110000000000', '0060000000000',
                                            S.STRUCTURE)
                                    AS FONCT,
                                 LENGTH (RTRIM (S.STRUCTURE, '0'))
                                    AS LONGUEUR
                            FROM GRHDSN.R_STRUCT S
                           WHERE S.STRUCTURE = V$STRUCTURE AND S.PARENT = '1')) S,
                 GRHDSN.R_STRUCT SS
           WHERE S.STRUCTURE = SS.STRUCTURE)
   LOOP
      RESULTAT := '/' || C.LIB_STRUCTURE_AR;
      V$LIB_STRUCTURE := C.LIB_STRUCTURE_AR;
      V$STRUCTURE := C.STRUCTURE;

      WHILE (   V$LIB_STRUCTURE NOT LIKE '%مركز الخدمة%'
             OR V$LIB_STRUCTURE NOT LIKE '%مديرية%فرعية%'
             OR V$LIB_STRUCTURE NOT LIKE
                   '%مركز الإقليمي للخدمة الوطنية%'
             OR V$LIB_STRUCTURE NOT LIKE '%مكتب%خدمة%وطنية%')
      LOOP
         V$LIB_STRUCTURE := GRHDSN.GET_STRUCT_FONCT (V$STRUCTURE);
         RESULTAT := RESULTAT || V$LIB_STRUCTURE;
         V$STRUCTURE :=
            RPAD (
               SUBSTR (RTRIM (V$STRUCTURE, '0'),
                       1,
                       LENGTH (RTRIM (V$STRUCTURE, '0')) - 1),
               13,
               '0');
      END LOOP;
   END LOOP;

   RETURN RESULTAT;
END;
/

