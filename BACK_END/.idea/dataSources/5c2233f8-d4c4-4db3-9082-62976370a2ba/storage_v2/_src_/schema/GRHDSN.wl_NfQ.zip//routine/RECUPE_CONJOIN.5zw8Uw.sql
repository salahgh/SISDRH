create FUNCTION        "RECUPE_CONJOIN" (P$MATRICULE NUMBER)
   RETURN VARCHAR2
IS
CURSOR TAB
   IS
      SELECT C.ID_CONJOIN
        FROM GRHDSN.CONJOIN C
       WHERE C.ID_CONJOIN IN (SELECT M.ID_CONJOIN
                                FROM GRHDSN.EST_MARIER M
                               WHERE M.MATRICULE = P$MATRICULE);
   V$RESULTAT   VARCHAR2 (1000);
   I            INT := 1;
   COMPTE       INT := 0;
   CUR          SYS_REFCURSOR;
   LOOP_CUR     TAB%ROWTYPE;
BEGIN
   
   -----------------------------
   
   EXECUTE IMMEDIATE 'SELECT COUNT (*)
     FROM GRHDSN.CONJOIN C
    WHERE C.ID_CONJOIN IN (SELECT M.ID_CONJOIN
                             FROM GRHDSN.EST_MARIER M
                            WHERE M.MATRICULE = '||P$MATRICULE||')' INTO COMPTE;
   
   
   OPEN CUR FOR 'SELECT C.ID_CONJOIN
        FROM GRHDSN.CONJOIN C
       WHERE C.ID_CONJOIN IN (SELECT M.ID_CONJOIN
                                FROM GRHDSN.EST_MARIER M
                               WHERE M.MATRICULE = '||P$MATRICULE||')';
   LOOP
   FETCH CUR INTO LOOP_CUR;
   EXIT WHEN CUR%NOTFOUND;
   IF I = COMPTE
      THEN
         V$RESULTAT := V$RESULTAT || LOOP_CUR.ID_CONJOIN;
      ELSE
         V$RESULTAT := V$RESULTAT || LOOP_CUR.ID_CONJOIN || ',';
         I := I + 1;
      END IF;
   END LOOP;
   CLOSE CUR;
   -----------------------------

   IF COMPTE = 0
   THEN
      RETURN '''0''';
   ELSE
      RETURN V$RESULTAT;
   END IF;
END;

/

