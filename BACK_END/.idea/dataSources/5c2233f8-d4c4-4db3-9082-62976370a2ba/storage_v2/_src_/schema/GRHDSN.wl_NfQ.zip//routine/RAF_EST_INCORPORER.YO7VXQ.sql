create PROCEDURE       RAF_EST_INCORPORER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_INCORPORER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_INCORPORER  
where  MATRICULE=vcur.MATRICULE and CTG=vcur.CTG and D_INCORPORATION=vcur.D_INCORPORATION 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_INCORPORER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_INCORPORER  
(  MATRICULE ,CTG ,D_INCORPORATION ,GRADE ,ARME ,UNITEE ,AVIS_INCO ,D_AVIS_INCO ,NIVEAU ,FONCTION ,SPECIALITE )  
values(  vcur.MATRICULE ,vcur.CTG ,vcur.D_INCORPORATION ,vcur.GRADE ,vcur.ARME ,vcur.UNITEE ,vcur.AVIS_INCO ,vcur.D_AVIS_INCO ,vcur.NIVEAU ,vcur.FONCTION ,vcur.SPECIALITE 
) ; 
end if ;
else 
update  EST_INCORPORER set  
GRADE=vcur.GRADE,
ARME=vcur.ARME,
UNITEE=vcur.UNITEE,
AVIS_INCO=vcur.AVIS_INCO,
D_AVIS_INCO=vcur.D_AVIS_INCO,
NIVEAU=vcur.NIVEAU,
FONCTION=vcur.FONCTION,
SPECIALITE=vcur.SPECIALITE
where  MATRICULE=vcur.MATRICULE and CTG=vcur.CTG and D_INCORPORATION=vcur.D_INCORPORATION 
 ; 
end if ;
else
delete from EST_INCORPORER   
where  MATRICULE=vcur.MATRICULE and CTG=vcur.CTG and D_INCORPORATION=vcur.D_INCORPORATION 
 ;  ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_INCORPORER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_INCORPORER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
--rollback;
end;
end loop; 
commit; 
end;
/

