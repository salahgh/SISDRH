create FUNCTION        "R_DISTINATION" (P$CSN VARCHAR2)
   RETURN VARCHAR2
IS
   V$CSN   VARCHAR2 (250);
BEGIN
   IF SUBSTR (P$CSN, 1, 1) = '0' OR SUBSTR (P$CSN, 1, 1) = '2'
   THEN
      SELECT C.LIB_CSN_AR
        INTO V$CSN
        FROM GRHDSN.R_CSN C
       WHERE C.CSN = SUBSTR (P$CSN, 2, 2);
   ELSE
      SELECT 'مكتب الخدمة الوطنية ب' || B.WILAYA
        INTO V$CSN
        FROM GRHDSN.R_BSN B
       WHERE B.BSN = SUBSTR (P$CSN, 2, 2);
   END IF;
   RETURN V$CSN;
END;

/

