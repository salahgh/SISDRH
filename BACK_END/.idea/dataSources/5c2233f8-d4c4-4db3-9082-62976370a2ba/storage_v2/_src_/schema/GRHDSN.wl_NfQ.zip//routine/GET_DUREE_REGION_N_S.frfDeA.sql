create FUNCTION        GET_DUREE_REGION_N_S (MAT        IN VARCHAR2,
                                                    TYPE_REG      VARCHAR2)
   RETURN NUMBER
IS
   CURSOR CUR
   IS
        SELECT M.UNITEE,
               M.D_MUTATION,
               M.STAGE,
               C.UNITE,
               U.REGION,
               SUBSTR (C.CSN, 1, 2) AS STR
          FROM GRHDSN.EST_MUTER M,
               (SELECT * FROM R_CSN
                UNION
                SELECT * FROM R_CSN_OLD) C,
               GRHDSN.R_UNITEE U
         WHERE     M.MATRICULE = MAT
               AND C.UNITE(+) = M.UNITEE
               AND M.UNITEE = U.UNITEE
      ORDER BY M.D_MUTATION DESC;

   V$I          INTEGER := 0;
   V$STR        VARCHAR2 (10);
   V$DUREE      VARCHAR2 (10) := '0';
   V$REGION_0   VARCHAR2 (10) := '0';
   V$REGION_1   VARCHAR2 (10) := '0';
   V$REGION_2   VARCHAR2 (10) := '0';
   V$REGION_3   VARCHAR2 (10) := '0';
   V$REGION_4   VARCHAR2 (10) := '0';
   V$REGION_5   VARCHAR2 (10) := '0';
   V$REGION_6   VARCHAR2 (10) := '0';
   V$D_MUT      DATE;
BEGIN
   FOR C IN CUR
   LOOP
   --DBMS_OUTPUT.PUT_LINE(MAT);
      IF C.STAGE != 1 AND V$I = 0
      THEN
         V$STR := C.STR;

         IF C.REGION = 0
         THEN
            V$REGION_0 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 1
         THEN
            V$REGION_1 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 2
         THEN
            V$REGION_2 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 3
         THEN
            V$REGION_3 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 4
         THEN
            V$REGION_4 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 5
         THEN
            V$REGION_5 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         IF C.REGION = 6
         THEN
            V$REGION_6 := TO_DATE ('16/10/2023') - C.D_MUTATION;
         END IF;

         V$I := 1;
         V$D_MUT := C.D_MUTATION;
      ELSE
         IF V$I = 1 AND C.STAGE != 1
         THEN
            IF C.REGION = 0
            THEN
               V$REGION_0 := V$REGION_0 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 1
            THEN
               V$REGION_1 := V$REGION_1 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 2
            THEN
               V$REGION_2 := V$REGION_2 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 3
            THEN
               V$REGION_3 := V$REGION_3 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 4
            THEN
               V$REGION_4 := V$REGION_4 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 5
            THEN
               V$REGION_5 := V$REGION_5 + (V$D_MUT - C.D_MUTATION);
            END IF;

            IF C.REGION = 6
            THEN
               V$REGION_6 := V$REGION_6 + (V$D_MUT - C.D_MUTATION);
            END IF;

            V$D_MUT := C.D_MUTATION;
         ELSE
            V$D_MUT := C.D_MUTATION;
         END IF;
      END IF;
   END LOOP;


   IF (TYPE_REG = 'N')
   THEN
      RETURN   TO_NUMBER (TO_CHAR ( (V$REGION_0 / 365), 'fm99D00'))
             + TO_NUMBER (TO_CHAR ( (V$REGION_1 / 365), 'fm99D00'))
             + TO_NUMBER (TO_CHAR ( (V$REGION_2 / 365), 'fm99D00'))
             + TO_NUMBER (TO_CHAR ( (V$REGION_5 / 365), 'fm99D00'));
   ELSE
      RETURN   TO_NUMBER (TO_CHAR ( (V$REGION_3 / 365), 'fm99D00'))
             + TO_NUMBER (TO_CHAR ( (V$REGION_4 / 365), 'fm99D00'))
             + TO_NUMBER (TO_CHAR ( (V$REGION_6 / 365), 'fm99D00'));
   END IF;
END;
/

