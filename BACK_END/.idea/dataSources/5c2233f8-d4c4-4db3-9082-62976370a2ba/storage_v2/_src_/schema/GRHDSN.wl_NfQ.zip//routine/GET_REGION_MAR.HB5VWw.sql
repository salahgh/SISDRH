create FUNCTION        GET_REGION_MAR (MAT      IN VARCHAR2,
                                                  D_AUTO   IN DATE)
   RETURN VARCHAR2
IS
   I          INT := 0;
   REG        VARCHAR2 (250);
   RESULTAT   VARCHAR2 (250);
BEGIN
   FOR D IN (  SELECT U.REGION, M.D_MUTATION
                 FROM GRHDSN.EST_MUTER M, GRHDSN.R_UNITEE U
                WHERE M.MATRICULE = MAT AND U.UNITEE = M.UNITEE
             ORDER BY M.D_MUTATION)
   LOOP
      IF (D_AUTO < D.D_MUTATION AND I = 0)
      THEN
         I := 1;
      END IF;

      IF (D_AUTO > D.D_MUTATION AND I = 0)
      THEN
         REG := D.REGION;
      END IF;
   END LOOP;



   RETURN REG;
END;
/

