create FUNCTION        SIT_GLOBAL_ABS_MOTIF (STR IN VARCHAR2)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
        SELECT DECODE (
                  I.CODE_ABS,
                  '1', 'المعني في حالة غياب غير شرعي',
                  '2', 'المعني في حالة فرار',
                  '3',    'إجازة قصيرة إلى غاية  '
                       || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '4',    'إجازة إلى غاية '
                       || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '5',    'عطلة إلى غاية '
                       || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '6',    'مهمة إلى يوم '
                       || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '7', 'متأخر عن الإجازة ',
                  '9',    'توقيف إلى غاية '
                       || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '10',    'نقاهة إلى غاية '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '11',    'عطلة أمومة إلى غاية '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '12',    'عطلة مرضية إلى غاية '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '13',    'إستدعاع ليوم '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '14',    'إستشفاء إلى يوم '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  '15', 'متأخر عن مهمة ',
                  '16', 'تأخر عن نقاهة ',
                  '17', 'متأخر عن عطلة ',
                  '20',    'مرخص  '
                        ||I.OBS ,
                        '21',    'مأذون ليوم '
                        || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                   '22', 'محال أمام المحكمة العسكرية',
                   '23', 'نقاهة طويلة المدى إلى غاية ' || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                   '24', 'إيقاف عن العمل إلى غاية ' || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                   '25', 'إسترجاع خفارة يوم ' || TO_CHAR (I.D_F_ABS, 'DD/MM/YYYY'),
                  NULL)
                  AS MOTIF
          FROM GRHDSN.EST_INDISPONIBLE I, GRHDSN.EST_AFFECTER A, GRHDSN.PERSONNELS P
         WHERE     TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
               AND (A.MATRICULE, A.D_AFFECTATION) IN
                      (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                           FROM GRHDSN.EST_AFFECTER AA
                       GROUP BY AA.MATRICULE)
               AND I.MATRICULE = A.MATRICULE
               AND I.MATRICULE = P.MATRICULE
               AND A.STRUCT = STR
               AND P.CSN = '10'
               AND P.ARCHIVER = '0'
      ORDER BY A.MATRICULE;

   CURSOR COUNTE
   IS
        SELECT COUNT (*) AS CPT
          FROM GRHDSN.PERSONNELS P,
               GRHDSN.EST_INDISPONIBLE I,
               GRHDSN.R_GRADE G,
               GRHDSN.EST_AFFECTER A
         WHERE     P.MATRICULE = I.MATRICULE
               AND TRUNC (SYSDATE) BETWEEN I.D_D_ABS AND I.D_F_ABS
               AND P.GRADE = G.GRADE
               AND (A.MATRICULE, A.D_AFFECTATION) IN
                      (  SELECT AA.MATRICULE, MAX (AA.D_AFFECTATION)
                           FROM GRHDSN.EST_AFFECTER AA
                       GROUP BY AA.MATRICULE)
               AND P.MATRICULE = A.MATRICULE
               AND A.STRUCT = STR
               AND P.CSN = '10'
               AND P.ARCHIVER = '0'
      ORDER BY A.MATRICULE;

   COMPTE     INTEGER := 0;
   I          INTEGER := 1;
   RESULTAT   VARCHAR2 (250);
BEGIN
   FOR C IN COUNTE
   LOOP
      COMPTE := C.CPT;
   END LOOP;

   FOR P IN TAB
   LOOP
      IF I < COMPTE
      THEN
         RESULTAT := RESULTAT || '' || P.MOTIF || ' <br> ';
         I := I + 1;
      ELSE
         RESULTAT := RESULTAT || '' || P.MOTIF;
      END IF;
   END LOOP;

   RETURN RESULTAT;
END;

/

