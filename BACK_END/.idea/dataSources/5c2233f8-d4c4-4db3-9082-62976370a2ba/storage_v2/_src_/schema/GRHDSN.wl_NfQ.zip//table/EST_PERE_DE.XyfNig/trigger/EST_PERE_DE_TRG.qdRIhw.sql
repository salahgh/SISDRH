create trigger EST_PERE_DE_TRG
    before insert
    on EST_PERE_DE
    for each row
BEGIN
-- For Toad:  Highlight column ID_ENF
IF :new.ID_ENF IS NULL THEN
  :new.ID_ENF := EST_PERE_DE_SEQ.nextval;
  END IF;
END EST_PERE_DE_TRG;
/

