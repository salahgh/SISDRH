create trigger INS_EST_NOTE_OFF
    before insert
    on EST_NOTE_OFF
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'EST_NOTE_OFF';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request :=
         REPLACE (x$request, 'V$FONCTION', '''' || :new.FONCTION || '''');
      x$request :=
         REPLACE (x$request, 'V$FONCT_SUP', '''' || :new.FONCT_SUP || '''');
      x$request :=
         REPLACE (x$request, 'V$CAS_PROM', '''' || :new.CAS_PROM || '''');
      x$request :=
         REPLACE (x$request,
                  'V$CAP_CAS_PROM',
                  '''' || :new.CAP_CAS_PROM || '''');
      x$request :=
         REPLACE (x$request, 'V$GRD_FINAL', '''' || :new.GRD_FINAL || '''');
      x$request :=
         REPLACE (x$request, 'V$CAP_OFF', '''' || :new.CAP_OFF || '''');
      x$request :=
         REPLACE (x$request, 'V$COTE_FONCT', '''' || :new.COTE_FONCT || '''');
      x$request :=
         REPLACE (x$request, 'V$COTE_SPEC', '''' || :new.COTE_SPEC || '''');
      x$request :=
         REPLACE (x$request, 'V$NIV_HAUT', '''' || :new.NIV_HAUT || '''');
      x$request :=
         REPLACE (x$request, 'V$CDT_FORM', '''' || :new.CDT_FORM || '''');
      x$request :=
         REPLACE (x$request,
                  'V$ADJ_CDT_FORM',
                  '''' || :new.ADJ_CDT_FORM || '''');
      x$request :=
         REPLACE (x$request, 'V$E_MAJOR', '''' || :new.E_MAJOR || '''');
      x$request :=
         REPLACE (x$request,
                  'V$ENTRAINEMENT',
                  '''' || :new.ENTRAINEMENT || '''');
      x$request :=
         REPLACE (x$request, 'V$FONCT_TECH', '''' || :new.FONCT_TECH || '''');
      x$request :=
         REPLACE (x$request,
                  'V$FONCT_ADMIN',
                  '''' || :new.FONCT_ADMIN || '''');
      x$request :=
         REPLACE (x$request,
                  'V$FONCTION_CHEF',
                  '''' || :new.FONCTION_CHEF || '''');
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request :=
         REPLACE (x$request,
                  'V$D_D_NOTATION',
                  '''' || :new.D_D_NOTATION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$D_F_NOTATION',
                  '''' || :new.D_F_NOTATION || '''');
      x$request := REPLACE (x$request, 'V$CAUSE_NOT', :new.CAUSE_NOT);
      x$request :=
         REPLACE (x$request,
                  'V$AUTRE_CAUSE',
                  '''' || :new.AUTRE_CAUSE || '''');
      x$request := REPLACE (x$request, 'V$APPARENCE', :new.APPARENCE);
      x$request := REPLACE (x$request, 'V$PHYSIQUE', :new.PHYSIQUE);
      x$request := REPLACE (x$request, 'V$TRAVAIL', :new.TRAVAIL);
      x$request :=
         REPLACE (x$request, 'V$ADMINISTRATION', :new.ADMINISTRATION);
      x$request := REPLACE (x$request, 'V$MAITRISE_SOI', :new.MAITRISE_SOI);
      x$request := REPLACE (x$request, 'V$AUTORITE', :new.AUTORITE);
      x$request :=
         REPLACE (x$request, 'V$RESPONSABILITE', :new.RESPONSABILITE);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_PARTICIP', :new.ESPRIT_PARTICIP);
      x$request :=
         REPLACE (x$request,
                  'V$QUALITEE_ENTRAINEUR',
                  :new.QUALITEE_ENTRAINEUR);
      x$request :=
         REPLACE (x$request,
                  'V$QUALITEE_INSTRCUTEUR',
                  :new.QUALITEE_INSTRCUTEUR);
      x$request := REPLACE (x$request, 'V$INTILLIGENCE', :new.INTILLIGENCE);
      x$request := REPLACE (x$request, 'V$APRECIATION', :new.APRECIATION);
      x$request := REPLACE (x$request, 'V$ORGANISATION', :new.ORGANISATION);
      x$request := REPLACE (x$request, 'V$CONVERSATION', :new.CONVERSATION);
      x$request := REPLACE (x$request, 'V$PREOCCUP_SUB', :new.PREOCCUP_SUB);
      x$request := REPLACE (x$request, 'V$ESPRIT_AIDE', :new.ESPRIT_AIDE);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_DICIPLINE', :new.ESPRIT_DICIPLINE);
      x$request := REPLACE (x$request, 'V$EDUCATION', :new.EDUCATION);
      x$request := REPLACE (x$request, 'V$NOTE_FONCTION', :new.NOTE_FONCTION);
      x$request :=
         REPLACE (x$request,
                  'V$AMELIOR_FONCTION',
                  '''' || :new.AMELIOR_FONCTION || '''');
      x$request := REPLACE (x$request, 'V$ACTIVITE', :new.ACTIVITE);
      x$request :=
         REPLACE (x$request, 'V$APPR_CHEF', '''' || :new.APPR_CHEF || '''');
      x$request := REPLACE (x$request, 'V$CHEF', '''' || :new.CHEF || '''');
      x$request := REPLACE (x$request, 'V$UNITE', :new.UNITE);

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;

   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'D_D_NOTATION',
          :old.D_D_NOTATION,
          :new.D_D_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'D_F_NOTATION',
          :old.D_F_NOTATION,
          :new.D_F_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CAUSE_NOT',
          :old.CAUSE_NOT,
          :new.CAUSE_NOT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'AUTRE_CAUSE',
          :old.AUTRE_CAUSE,
          :new.AUTRE_CAUSE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'APPARENCE',
          :old.APPARENCE,
          :new.APPARENCE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'PHYSIQUE',
          :old.PHYSIQUE,
          :new.PHYSIQUE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'TRAVAIL',
          :old.TRAVAIL,
          :new.TRAVAIL,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ADMINISTRATION',
          :old.ADMINISTRATION,
          :new.ADMINISTRATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'MAITRISE_SOI',
          :old.MAITRISE_SOI,
          :new.MAITRISE_SOI,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'AUTORITE',
          :old.AUTORITE,
          :new.AUTORITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'RESPONSABILITE',
          :old.RESPONSABILITE,
          :new.RESPONSABILITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ESPRIT_PARTICIP',
          :old.ESPRIT_PARTICIP,
          :new.ESPRIT_PARTICIP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'QUALITEE_ENTRAINEUR',
          :old.QUALITEE_ENTRAINEUR,
          :new.QUALITEE_ENTRAINEUR,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'QUALITEE_INSTRCUTEUR',
          :old.QUALITEE_INSTRCUTEUR,
          :new.QUALITEE_INSTRCUTEUR,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'INTILLIGENCE',
          :old.INTILLIGENCE,
          :new.INTILLIGENCE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'APRECIATION',
          :old.APRECIATION,
          :new.APRECIATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ORGANISATION',
          :old.ORGANISATION,
          :new.ORGANISATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CONVERSATION',
          :old.CONVERSATION,
          :new.CONVERSATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'PREOCCUP_SUB',
          :old.PREOCCUP_SUB,
          :new.PREOCCUP_SUB,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ESPRIT_AIDE',
          :old.ESPRIT_AIDE,
          :new.ESPRIT_AIDE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ESPRIT_DICIPLINE',
          :old.ESPRIT_DICIPLINE,
          :new.ESPRIT_DICIPLINE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'EDUCATION',
          :old.EDUCATION,
          :new.EDUCATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'NOTE_FONCTION',
          :old.NOTE_FONCTION,
          :new.NOTE_FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'AMELIOR_FONCTION',
          :old.AMELIOR_FONCTION,
          :new.AMELIOR_FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ACTIVITE',
          :old.ACTIVITE,
          :new.ACTIVITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'APPR_CHEF',
          :old.APPR_CHEF,
          :new.APPR_CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CHEF',
          :old.CHEF,
          :new.CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'UNITE',
          :old.UNITE,
          :new.UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'FONCT_SUP',
          :old.FONCT_SUP,
          :new.FONCT_SUP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CAS_PROM',
          :old.CAS_PROM,
          :new.CAS_PROM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CAP_CAS_PROM',
          :old.CAP_CAS_PROM,
          :new.CAP_CAS_PROM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'GRD_FINAL',
          :old.GRD_FINAL,
          :new.GRD_FINAL,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CAP_OFF',
          :old.CAP_OFF,
          :new.CAP_OFF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'COTE_FONCT',
          :old.COTE_FONCT,
          :new.COTE_FONCT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'COTE_SPEC',
          :old.COTE_SPEC,
          :new.COTE_SPEC,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'NIV_HAUT',
          :old.NIV_HAUT,
          :new.NIV_HAUT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'CDT_FORM',
          :old.CDT_FORM,
          :new.CDT_FORM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ADJ_CDT_FORM',
          :old.ADJ_CDT_FORM,
          :new.ADJ_CDT_FORM,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'E_MAJOR',
          :old.E_MAJOR,
          :new.E_MAJOR,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'ENTRAINEMENT',
          :old.ENTRAINEMENT,
          :new.ENTRAINEMENT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'FONCT_TECH',
          :old.FONCT_TECH,
          :new.FONCT_TECH,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'FONCT_ADMIN',
          :old.FONCT_ADMIN,
          :new.FONCT_ADMIN,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_OFF',
          'FONCTION_CHEF',
          :old.FONCTION_CHEF,
          :new.FONCTION_CHEF,
          'INS');
END;


/* Formatted on 10/09/2020 10:16:35 (QP5 v5.215.12089.38647) */
/

