create PROCEDURE       RAF_A_DESERTER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.A_DESERTER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from A_DESERTER  
where  MATRICULE=vcur.MATRICULE and D_DESERTION=vcur.D_DESERTION 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.A_DESERTER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into A_DESERTER  
(  MATRICULE ,D_DESERTION ,UNITEE ,REF_BR_UNITEE ,D_REF_BR_UNITEE ,REF_BR_DRRH ,D_REF_BR_DRRH ,DESERTION ,D_RETOUR ,REF_BCR_UNITEE ,D_REF_BCR_UNITEE ,REF_BCR_DRRH ,D_REF_BCR_DRRH ,RETOUR )  
values(  vcur.MATRICULE ,vcur.D_DESERTION ,vcur.UNITEE ,vcur.REF_BR_UNITEE ,vcur.D_REF_BR_UNITEE ,vcur.REF_BR_DRRH ,vcur.D_REF_BR_DRRH ,vcur.DESERTION ,vcur.D_RETOUR ,vcur.REF_BCR_UNITEE ,vcur.D_REF_BCR_UNITEE ,vcur.REF_BCR_DRRH ,vcur.D_REF_BCR_DRRH ,vcur.RETOUR 
) ; 
end if ;
else 
update  A_DESERTER set  
UNITEE=vcur.UNITEE,
REF_BR_UNITEE=vcur.REF_BR_UNITEE,
D_REF_BR_UNITEE=vcur.D_REF_BR_UNITEE,
REF_BR_DRRH=vcur.REF_BR_DRRH,
D_REF_BR_DRRH=vcur.D_REF_BR_DRRH,
DESERTION=vcur.DESERTION,
D_RETOUR=vcur.D_RETOUR,
REF_BCR_UNITEE=vcur.REF_BCR_UNITEE,
D_REF_BCR_UNITEE=vcur.D_REF_BCR_UNITEE,
REF_BCR_DRRH=vcur.REF_BCR_DRRH,
D_REF_BCR_DRRH=vcur.D_REF_BCR_DRRH,
RETOUR=vcur.RETOUR
where  MATRICULE=vcur.MATRICULE and D_DESERTION=vcur.D_DESERTION 
 ; 
end if ;
else
delete from A_DESERTER   
where  MATRICULE=vcur.MATRICULE and D_DESERTION=vcur.D_DESERTION 
 ; ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.A_DESERTER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.A_DESERTER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

