create view POSTE_TED_OFF as
SELECT P."MATRICULE",P."NOMA",P."PNOMA",P."DN",P."GRADE",P."NOMIN",P."ARME",P."DETACHE",P."FONCTION",P."STRUCTURE",P."FONCT",P."D_AFFECT",P."POSTE",P."LIB_CAT_AR",P."ORD",P."TYPE_FONCT",P."DIP_CIV",P."DIP_MIL",P."D_ARR",P."C", C.LIB_CSN_AR
  FROM (  SELECT *
            FROM (SELECT P.MATRICULE,
                         P.NOMA,
                         P.PNOMA,
                         P.DN,
                         P.GRADE,
                         (SELECT TO_CHAR (MAX (N.D_NOMIN), 'YYYY/MM/DD')
                            FROM GRHDSN.EST_NOMINER_G N
                           WHERE P.MATRICULE = N.MATRICULE)
                            AS NOMIN,
                         P.ARME,
                         P.DETACHE,
                         F.LIB_FONCTION_AR AS FONCTION,
                         F.LIB_STRUCTURE_AR AS STRUCTURE,
                         F.FONCTION AS FONCT,
                         P.D_AFFECT,
                         F.POSTE AS POSTE,
                         DECODE (F.LIB_CAT_AR,
                                 'ضباط', 'ضابط',
                                 'صف ضباط', 'صف ضابط',
                                 F.LIB_CAT_AR)
                            AS LIB_CAT_AR,
                         DECODE (SUBSTR (F.FONCTION, 1, 3),
                                 '000', '0',
                                 '001', '0',
                                 '002', '0',
                                 '003', '0',
                                 '004', '0',
                                 '005', '0',
                                 '006', '0',
                                 '007', '0',
                                 '008', '0',
                                 '009', '0',
                                 '010', '0',
                                 '011', '0',
                                 '018', '0',
                                 '1')
                            AS ORD,
                         P.TYPE_FONCT,
                         DECODE (GRHDSN.GET_DIPLOME_CIV (P.MATRICULE),
                                 '0', NULL,
                                 GRHDSN.GET_DIPLOME_CIV (P.MATRICULE))
                            AS DIP_CIV,
                         DECODE (GRHDSN.GET_DIPLOME_MIL (P.MATRICULE),
                                 '0', NULL,
                                 GRHDSN.GET_DIPLOME_MIL (P.MATRICULE))
                            AS DIP_MIL,
                         TO_CHAR (
                            TO_DATE (GRHDSN.GET_LAST_DATE_MUT_V2 (P.MATRICULE)),
                            'YYYY/MM/DD')
                            AS D_ARR,
                         P.C
                    FROM (SELECT C.LIB_CSN_AR || '/' || C.REGION AS CSN,
                                 P.MATRICULE,
                                 P.NOMA,
                                 P.PNOMA,
                                 P.DN,
                                 G.LIB_GRADE_AR AS GRADE,
                                 A.LIB_ARME_AR AS ARME,
                                 DECODE (P.DETACHE, 0, 'لا', 'تعم')
                                    AS DETACHE,
                                 RF.LIB_FONCTION_AR AS FONCTION,
                                 TO_CHAR (A.D_AFFECTATION, 'YYYY/MM/DD')
                                    AS D_AFFECT,
                                 RF.POSTE POSTE,
                                 RCG.LIB_CAT_AR,
                                 A.FONCT,
                                 DECODE (A.TYPE_FONCT,
                                         '0', 'أصلية',
                                         'بالنيابة')
                                    AS TYPE_FONCT,
                                 P.CSN AS C
                            FROM GRHDSN.PERSONNELS P,
                                 GRHDSN.R_CSN C,
                                 GRHDSN.R_GRADE G,
                                 GRHDSN.R_ARME A,
                                 GRHDSN.EST_AFFECT A,
                                 GRHDSN.R_CAT_GRADE RCG,
                                 GRHDSN.R_FONCT RF
                           WHERE     P.POSITION LIKE '1%'
                                 AND RF.POSTE IS NOT NULL
                                 AND C.CSN = P.CSN
                                 AND P.GRADE <= '39'
                                 AND RF.LIB_STRUCTURE_AR NOT LIKE
                                        '%المديرية الجهوي%'
                                 AND P.GRADE = G.GRADE
                                 AND P.ARME = A.ARME
                                 AND A.MATRICULE = P.MATRICULE
                                 AND A.D_AFFECTATION =
                                        (SELECT MAX (AA.D_AFFECTATION)
                                           FROM GRHDSN.EST_AFFECT AA
                                          WHERE     A.MATRICULE = AA.MATRICULE
                                                AND AA.TYPE_FONCT = '0')
                                 AND A.FONCT = RF.FONCTION
                                 AND A.TYPE_FONCT = '0'
                                 AND RCG.CAT_GRADE = RF.CATEGORIE
                          UNION
                          SELECT C.LIB_CSN_AR || '/' || C.REGION AS CSN,
                                 P.MATRICULE,
                                 P.NOMA,
                                 P.PNOMA,
                                 P.DN,
                                 G.LIB_GRADE_AR AS GRADE,
                                 RA.LIB_ARME_AR AS ARME,
                                 DECODE (P.DETACHE, 0, 'لا', 'نعم')
                                    AS DETACHE,
                                 RF.LIB_FONCTION_AR AS FONCTION,
                                 TO_CHAR (A.D_AFFECTATION, 'YYYY/MM/DD')
                                    AS D_AFFECT,
                                 RF.POSTE POSTE,
                                 RCG.LIB_CAT_AR,
                                 A.FONCT,
                                 DECODE (A.TYPE_FONCT,
                                         '0', 'أصلية',
                                         'بالنيابة')
                                    AS TYPE_FONCT,
                                 P.CSN AS C
                            FROM GRHDSN.PERSONNELS P,
                                 GRHDSN.R_CSN C,
                                 GRHDSN.R_GRADE G,
                                 GRHDSN.R_ARME RA,
                                 GRHDSN.EST_AFFECT A,
                                 GRHDSN.R_CAT_GRADE RCG,
                                 GRHDSN.R_FONCT RF,
                                 GRHDSN.EST_MUTER M
                           WHERE     P.POSITION LIKE '1%'
                                 AND RF.POSTE IS NOT NULL
                                 AND C.CSN = P.CSN
                                 AND P.GRADE <= '39'
                                 AND RF.LIB_STRUCTURE_AR NOT LIKE
                                        '%المديرية الجهوي%'
                                 AND P.GRADE = G.GRADE
                                 AND P.ARME = RA.ARME
                                 AND A.MATRICULE = P.MATRICULE
                                 AND RCG.CAT_GRADE = RF.CATEGORIE
                                 AND A.D_AFFECTATION =
                                        (SELECT MAX (AA.D_AFFECTATION)
                                           FROM GRHDSN.EST_AFFECT AA
                                          WHERE     A.MATRICULE = AA.MATRICULE
                                                AND AA.TYPE_FONCT = '1')
                                 AND A.TYPE_FONCT = '1'
                                 AND A.FONCT = RF.FONCTION
                                 AND M.MATRICULE = P.MATRICULE
                                 AND M.D_MUTATION =
                                        (SELECT MAX (MM.D_MUTATION)
                                           FROM GRHDSN.EST_MUTER MM
                                          WHERE M.MATRICULE = MM.MATRICULE)
                                 AND A.UNITE = M.UNITEE
                                 AND A.D_REF_CESS_FONCTION IS NULL) P,
                         (  SELECT F.FONCTION,
                                   F.LIB_STRUCTURE_AR,
                                   F.LIB_FONCTION_AR,
                                   F.POSTE,
                                   RCG.LIB_CAT_AR
                              FROM GRHDSN.R_FONCT F, GRHDSN.R_CAT_GRADE RCG
                             WHERE     F.POSTE IS NOT NULL
                                   AND RCG.CAT_GRADE = F.CATEGORIE
                                   AND F.CATEGORIE IN ('1', '2', '3')
                                   AND F.LIB_STRUCTURE_AR NOT LIKE
                                          '%المديرية الجهوي%'
                          ORDER BY FONCTION) F
                   WHERE F.FONCTION = P.FONCT(+))
        ORDER BY ORD, FONCT, STRUCTURE) P,
       (SELECT *
          FROM GRHDSN.R_CSN
         WHERE     SUBSTR (CSN, 3, 2) = '00'
               AND CSN NOT IN
                      ('1000', '2000', '3000', '4000', '5000', '6000')) C
 WHERE P.C = C.CSN(+)
/

