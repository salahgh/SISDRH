create FUNCTION        GET_LIB_GRD_PRE (MAT NUMBER)
   RETURN VARCHAR2
IS
   GRD        VARCHAR2 (100);
   GRD_PRE    VARCHAR2 (100);
   COMPTE     INT := 0;
   RESULTAT   VARCHAR (100);

   CURSOR C1
   IS
        SELECT N.GRADE, G.LIB_GRADE_AR, G.GRADE_INF
          FROM GRHDSN.EST_NOMINER_G N, GRHDSN.R_GRADE G
         WHERE N.MATRICULE = mat AND N.GRADE = G.GRADE
      ORDER BY N.GRADE;
BEGIN
     SELECT COUNT (1)
       INTO COMPTE
       FROM GRHDSN.EST_NOMINER_G N
      WHERE N.MATRICULE = MAT
   ORDER BY N.GRADE;

   IF COMPTE = 1
   THEN
      FOR C IN C1
      LOOP
         GRD := C.GRADE;
      END LOOP;

      SELECT DECODE (
                E.METHOD_ENG,
                '1', DECODE (GRD,
                             '33', 'الطلب الضابط العامل',
                             NULL),
                '0', DECODE (
                        GRD,
                        '52', 'الطلب الرتيب',
                        '54', 'الطلب الرتيب',
                        '47', 'الطلب الصف ضابط المتعاقد',
                        NULL),
                NULL)
        INTO RESULTAT
        FROM GRHDSN.A_SIGNER E
       WHERE     E.MATRICULE = MAT
             AND E.D_ENG = (SELECT MIN (EE.D_ENG)
                              FROM GRHDSN.A_SIGNER EE
                             WHERE EE.MATRICULE = E.MATRICULE);
   END IF;

   IF COMPTE = 2
   THEN
      FOR C IN C1
      LOOP
         IF (GRD IS NULL)
         THEN
            GRD := C.GRADE;
         ELSE
            GRD_PRE := C.GRADE;
         END IF;
      END LOOP;

      DBMS_OUTPUT.PUT_LINE ('GRD : ' || GRD);
      DBMS_OUTPUT.PUT_LINE ('GRD_PRE : ' || GRD_PRE);

      IF (GRD = '33' AND GRD_PRE = '39')
      THEN
         RESULTAT := 'الطالب الضابط العامل';
      END IF;
   ELSE
      IF (GRD IN ('54', '52') AND GRD_PRE = '55')
      THEN
         RESULTAT := 'الطالب الرتيب';
      ELSE
         SELECT G.GRADE_INF
           INTO GRD
           FROM GRHDSN.EST_NOMINER_G N, GRHDSN.R_GRADE G
          WHERE     N.MATRICULE = MAT
                AND N.D_NOMIN = (SELECT MAX (NN.D_NOMIN)
                                   FROM GRHDSN.EST_NOMINER_G NN
                                  WHERE NN.MATRICULE = N.MATRICULE)
                AND G.GRADE = N.GRADE;

         SELECT G.LIB_GRADE_AR
           INTO RESULTAT
           FROM GRHDSN.R_GRADE G
          WHERE G.GRADE = GRD;
      END IF;
   END IF;


   IF COMPTE > 2
   THEN
      SELECT G.GRADE_INF
        INTO GRD
        FROM GRHDSN.EST_NOMINER_G N, GRHDSN.R_GRADE G
       WHERE     N.MATRICULE = MAT
             AND N.D_NOMIN = (SELECT MAX (NN.D_NOMIN)
                                FROM GRHDSN.EST_NOMINER_G NN
                               WHERE NN.MATRICULE = N.MATRICULE)
             AND G.GRADE = N.GRADE;

      SELECT G.LIB_GRADE_AR
        INTO RESULTAT
        FROM GRHDSN.R_GRADE G
       WHERE G.GRADE = GRD;
   END IF;

   RETURN RESULTAT;
END;
/

