create FUNCTION        GET_MUT_FONCT (MAT     IN NUMBER,
                                                 D_MUT   IN DATE,
                                                 UNITE   IN NUMBER)
    RETURN VARCHAR2
IS
    CURSOR CUR IS
          SELECT A.D_AFFECTATION,
                 A.UNITE,
                 DECODE (
                     A.TYPE_FONCT,
                     '0', DECODE (A.FONCT_DET,
                                  '/', F.LIB_FONCTION_AR,
                                  A.FONCT_DET),
                     DECODE (A.FONCT_DET,
                             '/', F.LIB_FONCTION_AR || ' (ملحقة)',
                             A.FONCT_DET || ' (ملحقة)'))    AS FONCTION,
                 A.FONCT
            FROM GRHDSN.EST_AFFECT A, GRHDSN.R_FONCT F
           WHERE A.MATRICULE = MAT AND F.FONCTION = A.FONCT
        ORDER BY A.D_AFFECTATION ASC;

    I          INTEGER := 1;
    DEBUT      INTEGER := 1;
    RESULTAT   VARCHAR2 (1000);
    V$DATE     DATE;
BEGIN
    SELECT GRHDSN.GET_D_BET_MUT (MAT, D_MUT) INTO V$DATE FROM DUAL;

    FOR A IN CUR
    LOOP
        IF D_MUT <= A.D_AFFECTATION AND A.D_AFFECTATION <= V$DATE AND I = 1
        THEN
            IF A.UNITE = UNITE
            THEN
                IF DEBUT = 1
                THEN
                    IF A.FONCT LIKE '9%'
                    THEN
                        RESULTAT := RESULTAT || ' ' || A.FONCTION;
                    ELSE
                        RESULTAT :=
                               RESULTAT
                            || ' '
                            || A.FONCTION
                            || ' '
                            || GRHDSN.GET_STRUCT_FONCT (A.FONCT);
                    END IF;

                    DEBUT := 0;
                ELSE
                    IF A.FONCT LIKE '9%'
                    THEN
                        RESULTAT := RESULTAT || '<br>' || A.FONCTION;
                    ELSE
                        RESULTAT :=
                               RESULTAT
                            || '<br>'
                            || A.FONCTION
                            || ' '
                            || GRHDSN.GET_STRUCT_FONCT (A.FONCT);
                    END IF;
                END IF;
            ELSE
                I := 0;
            END IF;
        END IF;
    END LOOP;

    RETURN RESULTAT;
END;
/

