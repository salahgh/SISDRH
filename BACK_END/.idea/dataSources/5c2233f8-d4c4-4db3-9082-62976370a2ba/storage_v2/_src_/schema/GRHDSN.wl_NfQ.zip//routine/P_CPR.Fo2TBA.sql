create procedure        P_CPR(v$mat varchar2, v$ut varchar2, v$table varchar2,  v$champ varchar2, 
          v$o varchar2, v$n varchar2, v$op varchar2) AS
         
ch1 varchar2(4000);
ch2 varchar2(4000);
x$o varchar2(400);
x$n varchar2(400);
BEGIN
  If v$op = 'INS' And TRIM(v$n) Is Not Null Then
    x$n := SubStrB(TRIM(v$n), 1, 400);
      insert into TRACES (identifiant, matricule,ut,champs,val_old,val_new,date_transaction,type_transaction,csn)
      values(to_char(sysdate,'DD-MM-YYYY HH:MI:SS_')||sys_context('USERENV','SESSIONID'),v$mat, v$ut, v$table||'.'||v$champ, Null, x$n, sysdate, v$op, '00');
  ElsIf v$op = 'SUP' And TRIM(v$o) Is Not Null Then
    x$o := SubStrB(TRIM(v$o), 1, 400);
      insert into TRACES (identifiant, matricule,ut,champs,val_old,val_new,date_transaction,type_transaction,csn)
      values(to_char(sysdate,'DD-MM-YYYY HH:MI:SS_')||sys_context('USERENV','SESSIONID'),v$mat, v$ut, v$table||'.'||v$champ, x$o, Null, sysdate, v$op, '00');
  ElsIf v$op = 'MAJ' Then      
    ch1 := NVL(RTRIM(v$o),'#');
    ch2 := NVL(RTRIM(v$n),'#');
    IF ch1!=ch2 then
      x$n := SubStrB(RTRIM(v$n), 1, 400);
      x$o := SubStrB(RTRIM(v$o), 1, 400);
      insert into TRACES (identifiant, matricule,ut,champs,val_old,val_new,date_transaction,type_transaction,csn)
      values(to_char(sysdate,'DD-MM-YYYY HH:MI:SS_')||sys_context('USERENV','SESSIONID'),v$mat, v$ut, v$table||'.'||v$champ, x$o, x$n, sysdate, v$op, '00');
    end if;
  End If;
END;
/

