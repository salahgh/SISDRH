create trigger INSERT_PERSONNELS
    before insert
    on PERSONNELS
    for each row
DECLARE
   CURSOR CUR IS SELECT CONDITION, MSG FROM GRHDSN.A_CONTROLE_MAJ WHERE BLOC = 'PERSONNELS';
   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
   Ex exception;
   
BEGIN
   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE '|| C.CONDITION;
      x$request := replace(x$request, 'v$adresse', :new.ADRESSE);
      EXECUTE IMMEDIATE (x$request) INTO x$count;
      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR('-20001', x$message);
      END IF;
   END LOOP;
END;
/

