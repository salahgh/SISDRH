create PROCEDURE       RAF_MISSION (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.MISSION@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from MISSION  
where  N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM 
 ; 
if (ext =0) then

insert into MISSION  
(  N_REF_OM ,D_REF_OM ,D_D_MISSION ,D_F_MISSION ,VEHICULE ,MOYENS ,MOTIF ,OBS ,DISTINATION )  
values(  vcur.N_REF_OM ,vcur.D_REF_OM ,vcur.D_D_MISSION ,vcur.D_F_MISSION ,vcur.VEHICULE ,vcur.MOYENS ,vcur.MOTIF ,vcur.OBS ,vcur.DISTINATION 
) ; 

else 
update  MISSION set  
D_D_MISSION=vcur.D_D_MISSION,
D_F_MISSION=vcur.D_F_MISSION,
VEHICULE=vcur.VEHICULE,
MOYENS=vcur.MOYENS,
MOTIF=vcur.MOTIF,
OBS=vcur.OBS,
DISTINATION=vcur.DISTINATION
where  N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM  ; 

end if ;
else
delete from MISSION   where  N_REF_OM=vcur.N_REF_OM and D_REF_OM=vcur.D_REF_OM  ; 
ext  :=1;
end if ;
if  (ext <>0) then
delete from  GRHDSNJ.MISSION@DBL235 where current of cur_j ; i:=i+1;

end if ;

exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.MISSION@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

