create FUNCTION        "LIST_DEM_OM" (VN_REF_OM   IN NUMBER)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
      SELECT G.ABR_GRADE_AR,
             P.NOMA,
             P.PNOMA,
             P.MATRICULE
        FROM PERSONNELS P, ELEMENT_DEM_MISS E, R_GRADE G
       WHERE     P.MATRICULE = E.MATRICULE
             AND E.N_DEMANDE = VN_REF_OM
             AND P.GRADE = G.GRADE ORDER BY P.GRADE;

   LIST   VARCHAR2 (500) := NULL;
BEGIN
   FOR P IN TAB
   LOOP
      LIST :=
            LIST
         || 'ال'
         || P.ABR_GRADE_AR
         || ' '
         || P.NOMA
         || ' '
         || P.PNOMA
         ||  '،  ';
   END LOOP;

   IF LIST IS NULL
   THEN
      RETURN '.';
   ELSE
      RETURN LIST;
   END IF;
END;
/

