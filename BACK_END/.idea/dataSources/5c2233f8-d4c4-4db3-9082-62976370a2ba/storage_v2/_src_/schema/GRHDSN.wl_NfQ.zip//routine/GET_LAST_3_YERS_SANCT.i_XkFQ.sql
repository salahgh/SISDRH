create FUNCTION        GET_LAST_3_YERS_SANCT (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   RESULTAT   VARCHAR2 (1000);
BEGIN
   FOR S
      IN (SELECT RS.LIB_SANCTION_AR AS SANCTION,
                 TO_CHAR (S.D_SANCTION, 'YYYY/MM/DD') AS D_SANCTION
            FROM GRHDSN.EST_SANCTIONNE S, GRHDSN.R_SANCTION RS
           WHERE     S.MATRICULE = MAT
                 AND S.D_SANCTION <
                        (SELECT MAX (SS.D_SANCTION)
                           FROM GRHDSN.EST_SANCTIONNE SS
                          WHERE     S.MATRICULE = SS.MATRICULE
                                AND SS.CODE_SANCTION IN
                                       ('2', '3', '4', '5', '7', '8', '9'))
                 AND TO_CHAR (S.D_SANCTION, 'YYYY') >=
                        TO_CHAR (SYSDATE, 'YYYY') - 2
                 AND S.CODE_SANCTION = RS.CODE_SANCTION
                 AND S.CODE_SANCTION IN ('2', '3', '4', '5', '7', '8', '9'))
   LOOP
      RESULTAT := RESULTAT || S.SANCTION || ' بتاريخ ' || S.D_SANCTION || '. ';
   END LOOP;

   RETURN RESULTAT;
END;
/

