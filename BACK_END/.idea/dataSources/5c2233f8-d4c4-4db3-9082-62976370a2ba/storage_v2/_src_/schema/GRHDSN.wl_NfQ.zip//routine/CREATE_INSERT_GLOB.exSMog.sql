create FUNCTION        "CREATE_INSERT_GLOB" (
   P$MATRICULE    NUMBER,
   P$TABLE        VARCHAR,
   P$DBL_DIST VARCHAR)
   RETURN VARCHAR2
IS
   CURSOR TAB
   IS
        SELECT C.COLUMN_NAME
          FROM SYS.ALL_TAB_COLUMNS C
         WHERE C.TABLE_NAME = P$TABLE AND C.OWNER = 'GRHDSN'
      ORDER BY C.COLUMN_ID;

   CURSOR TAB2
   IS
        SELECT C.COLUMN_NAME
          FROM SYS.ALL_TAB_COLUMNS C
         WHERE C.TABLE_NAME = P$TABLE AND C.OWNER = 'GRHDSN'
      ORDER BY C.COLUMN_ID;


   V$RESULTAT   VARCHAR2 (10000) := 'INSERT INTO GRHDSN.' || P$TABLE || '@GRHDSN' || P$DBL_DIST || ' (';
   I            INT := 1;
   COMPTE       INT := 0;
BEGIN
     SELECT COUNT (*)
       INTO COMPTE
       FROM SYS.ALL_TAB_COLUMNS C
      WHERE C.TABLE_NAME = P$TABLE AND C.OWNER = 'GRHDSN'
   ORDER BY C.COLUMN_ID;

   FOR P IN TAB
   LOOP
      IF I = COMPTE
      THEN
         V$RESULTAT := V$RESULTAT || P.COLUMN_NAME;
      ELSE
         V$RESULTAT := V$RESULTAT || P.COLUMN_NAME || ',';
         I := I + 1;
      END IF;
   END LOOP;

   V$RESULTAT := V$RESULTAT || ' ) (SELECT ';
   I := 1;

   FOR P IN TAB
   LOOP
      IF I = COMPTE
      THEN
         V$RESULTAT := V$RESULTAT || P.COLUMN_NAME;
      ELSE
         V$RESULTAT := V$RESULTAT || P.COLUMN_NAME || ',';
         I := I + 1;
      END IF;
   END LOOP;

   IF P$TABLE = 'CONJOIN'
   THEN
      V$RESULTAT :=
            V$RESULTAT
         || ' FROM GRHDSN.'
         || P$TABLE
         || ' WHERE ID_CONJOIN IN ( '
         || GRHDSN.RECUPE_CONJOIN (P$MATRICULE)
         || '))';
   ELSE
      V$RESULTAT :=
            V$RESULTAT
         || ' FROM GRHDSN.'
         || P$TABLE
         || ' WHERE MATRICULE = '''
         || P$MATRICULE
         || ''')';
   END IF;

   RETURN V$RESULTAT;
END;

/

