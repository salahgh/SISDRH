create FUNCTION        GET_IF_FONCT_SS (MAT IN VARCHAR2)
   RETURN VARCHAR2
IS
   RESPONSE   VARCHAR (50);
   COMPTE     INT;
BEGIN
   SELECT COUNT (1)
     INTO COMPTE
     FROM GRHDSN.EST_AFFECT A
    WHERE     A.MATRICULE = MAT
          AND (   A.FONCT LIKE '012016%'
               OR A.FONCT LIKE '012026%'
               OR A.FONCT LIKE '013016%'
               OR A.FONCT LIKE '013026%'
               OR A.FONCT LIKE '013036%'
               OR A.FONCT LIKE '014016%'
               OR A.FONCT LIKE '015016%'
               OR A.FONCT LIKE '016016%'
               OR A.FONCT LIKE '016026%'
               OR A.FONCT LIKE '016036%'
               OR A.FONCT LIKE '017016%')
          AND (   A.FONCT NOT LIKE '012016%'
               OR A.FONCT NOT LIKE '01202602%'
               OR A.FONCT NOT LIKE '01301602%'
               OR A.FONCT NOT LIKE '01302602%'
               OR A.FONCT NOT LIKE '01303602%'
               OR A.FONCT NOT LIKE '01401602%'
               OR A.FONCT NOT LIKE '01501602%'
               OR A.FONCT NOT LIKE '01601602%'
               OR A.FONCT NOT LIKE '01602602%'
               OR A.FONCT NOT LIKE '01603602%'
               OR A.FONCT NOT LIKE '01701602%');

   IF COMPTE = 0
   THEN
      RESPONSE := '0';
   ELSE
      RESPONSE := '1';
   END IF;

   RETURN RESPONSE;
END;
/

