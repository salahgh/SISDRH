create PROCEDURE       RAF_EST_MARIER (v_csn varchar2,n number) 
as 
i number:=0;          cursor cur_j is select * from GRHDSNJ.EST_MARIER@DBL235 where raf<>'O'  and csnJ= v_csn  order by d_op  for update; 
EXT number:=0;
err_msg varchar2(100);
err_code varchar2(100);
begin  
for vcur in cur_j loop  
begin
if i>n then  
exit;  
end if;   
if (( vcur.op='INS') or (vcur.op='MAJ')) then  
ext  :=0;
SELECT count(1) into ext from EST_MARIER  
where  ID_CONJOIN=vcur.ID_CONJOIN and MATRICULE=vcur.MATRICULE 
 ; 
if (ext =0) then
ext  :=0;
SELECT COUNT(1) into ext from PERSONNELS where   MATRICULE=vcur.MATRICULE  ;
if  (ext =0) then
update    GRHDSNJ.EST_MARIER@DBL235  set  raf='P',ERREUR ='manque tablee personnel mat' where  current of cur_j; i:=i+1; 
else
insert into EST_MARIER  
(  ID_CONJOIN ,MATRICULE ,REF_AUTO ,D_REF_AUTO ,REF_RECON ,D_REF_RECON ,N_ACT_MARIAGE ,D_ACT ,REF_BORD_AUTO ,D_REF_BORD_AUTO ,D_DEC_HONNEUR ,REF_BORD_RECON ,D_REF_BORD_RECON ,D_DEMANDE_AUTO_MAR ,APC_MAR ,D_INSC_MAR )  
values(  vcur.ID_CONJOIN ,vcur.MATRICULE ,vcur.REF_AUTO ,vcur.D_REF_AUTO ,vcur.REF_RECON ,vcur.D_REF_RECON ,vcur.N_ACT_MARIAGE ,vcur.D_ACT ,vcur.REF_BORD_AUTO ,vcur.D_REF_BORD_AUTO ,vcur.D_DEC_HONNEUR ,vcur.REF_BORD_RECON ,vcur.D_REF_BORD_RECON ,vcur.D_DEMANDE_AUTO_MAR ,vcur.APC_MAR ,vcur.D_INSC_MAR 
) ; 
end if ;
else 
update  EST_MARIER set  
REF_AUTO=vcur.REF_AUTO,
D_REF_AUTO=vcur.D_REF_AUTO,
REF_RECON=vcur.REF_RECON,
D_REF_RECON=vcur.D_REF_RECON,
N_ACT_MARIAGE=vcur.N_ACT_MARIAGE,
D_ACT=vcur.D_ACT,
REF_BORD_AUTO=vcur.REF_BORD_AUTO,
D_REF_BORD_AUTO=vcur.D_REF_BORD_AUTO,
D_DEC_HONNEUR=vcur.D_DEC_HONNEUR,
REF_BORD_RECON=vcur.REF_BORD_RECON,
D_REF_BORD_RECON=vcur.D_REF_BORD_RECON,
D_DEMANDE_AUTO_MAR=vcur.D_DEMANDE_AUTO_MAR,
APC_MAR=vcur.APC_MAR,
D_INSC_MAR=vcur.D_INSC_MAR
where  ID_CONJOIN=vcur.ID_CONJOIN and MATRICULE=vcur.MATRICULE 
 ; 
end if ;
else
delete from EST_MARIER   
where  ID_CONJOIN=vcur.ID_CONJOIN and MATRICULE=vcur.MATRICULE 
 ; 
 ext  :=1;
 end if ;
 if  (ext <>0) then
delete from  GRHDSNJ.EST_MARIER@DBL235 where current of cur_j ; i:=i+1;
end if ;
exception when others then
err_msg  := substr(sqlerrm,1,100);
err_code := sqlcode;
update    GRHDSNJ.EST_MARIER@DBL235  set  raf='E',ERREUR =ERREUR|| err_code||'-'||err_msg where  current of cur_j; i:=i+1;
rollback;
end;
end loop; 
commit; 
end;
/

