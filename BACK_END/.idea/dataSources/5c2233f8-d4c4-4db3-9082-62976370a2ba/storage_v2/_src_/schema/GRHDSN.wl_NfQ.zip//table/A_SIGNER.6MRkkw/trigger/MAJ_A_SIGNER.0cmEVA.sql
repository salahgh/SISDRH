create trigger MAJ_A_SIGNER
    after update
    on A_SIGNER
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'A_SIGNER' AND ETAT = 'O';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request :=
         REPLACE (x$request, 'V$METHOD_ENG', '''' || :new.METHOD_ENG || '''');
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request := REPLACE (x$request, 'V$D_ENG', '''' || :new.D_ENG || '''');
      x$request := REPLACE (x$request, 'V$GRADE', :new.GRADE);
      x$request := REPLACE (x$request, 'V$ARME', :new.ARME);
      x$request := REPLACE (x$request, 'V$UNITEE', :new.UNITEE);
      x$request := REPLACE (x$request, 'V$N_ACT', :new.N_ACT);
      x$request := REPLACE (x$request, 'V$D_ACT', '''' || :new.D_ACT || '''');
      x$request :=
         REPLACE (x$request, 'V$AVIS_ENG', '''' || :new.AVIS_ENG || '''');
      x$request :=
         REPLACE (x$request, 'V$D_AVIS_ENG', '''' || :new.D_AVIS_ENG || '''');
      x$request :=
         REPLACE (x$request, 'V$NIVEAU', '''' || :new.NIVEAU || '''');
      x$request := REPLACE (x$request, 'V$DUREE', :new.DUREE);
      x$request := REPLACE (x$request, 'V$TYPE_ENG', :new.TYPE_ENG);

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;
   
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'TYPE_ENG',
          :old.TYPE_ENG,
          :new.TYPE_ENG,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'DUREE',
          :old.DUREE,
          :new.DUREE,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'NIVEAU',
          :old.NIVEAU,
          :new.NIVEAU,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_AVIS_ENG',
          :old.D_AVIS_ENG,
          :new.D_AVIS_ENG,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'AVIS_ENG',
          :old.AVIS_ENG,
          :new.AVIS_ENG,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_ACT',
          :old.D_ACT,
          :new.D_ACT,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'N_ACT',
          :old.N_ACT,
          :new.N_ACT,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'UNITEE',
          :old.UNITEE,
          :new.UNITEE,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'ARME',
          :old.ARME,
          :new.ARME,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'GRADE',
          :old.GRADE,
          :new.GRADE,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'D_ENG',
          :old.D_ENG,
          :new.D_ENG,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'MAJ');
   P_CPR (:new.MATRICULE,
          x$user,
          'A_SIGNER',
          'METHOD_ENG',
          :old.METHOD_ENG,
          :new.METHOD_ENG,
          'MAJ');
   
END;
/

