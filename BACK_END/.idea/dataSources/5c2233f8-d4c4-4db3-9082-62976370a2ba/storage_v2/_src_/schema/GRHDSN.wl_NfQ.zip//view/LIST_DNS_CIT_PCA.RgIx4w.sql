create view LIST_DNS_CIT_PCA as
(SELECT COUNT(P.MATRICULE) AS MATRICULE, YEAR, P.CSN
      FROM (  SELECT MATRICULE, MIN (YEAR) AS YEAR, MIN (MONTH) AS MONTH
                FROM (SELECT P.MATRICULE,
                               35
                             - TRUNC (
                                    TRUNC (
                                         MONTHS_BETWEEN (SYSDATE, R.D_RECRUT)
                                       + P.SERVICE)
                                  / 12)
                                AS YEAR,
                             MOD (
                                  420
                                - TRUNC (MONTHS_BETWEEN (SYSDATE, R.D_RECRUT))
                                - P.SERVICE,
                                12)
                                AS MONTH
                        FROM GRHDSN.PERSONNELS P, GRHDSN.EST_RECRUTE R
                       WHERE     P.MATRICULE = R.MATRICULE
                             AND P.GRADE = '90'
                             AND P.POSITION LIKE '1%'
                             AND R.D_RECRUT =
                                    (SELECT MAX (RR.D_RECRUT)
                                       FROM GRHDSN.EST_RECRUTE RR
                                      WHERE RR.MATRICULE = R.MATRICULE)
                      UNION
                      SELECT P.MATRICULE,
                               60
                             - TRUNC (
                                    TRUNC (
                                         MONTHS_BETWEEN (SYSDATE, P.DN)
                                       + P.SERVICE)
                                  / 12)
                                AS YEAR,
                             MOD (
                                  720
                                - TRUNC (MONTHS_BETWEEN (SYSDATE, P.DN))
                                - P.SERVICE,
                                12)
                                AS MONTH
                        FROM GRHDSN.PERSONNELS P, GRHDSN.DICISION D
                       WHERE     P.GRADE = '90'
                             AND P.SEX = 'ذكر'
                             AND D.CATEGORIE IN
                                    ('5',
                                     '6',
                                     '7',
                                     '8',
                                     '9',
                                     '10',
                                     '11',
                                     '12',
                                     '13',
                                     '14',
                                     '15',
                                     '16',
                                     '17',
                                     'SD1',
                                     'SD2',
                                     'SD3',
                                     'SD4',
                                     'SD5',
                                     'SD6',
                                     'SD7')
                             AND D.D_DICISION =
                                    (SELECT MAX (DD.D_DICISION)
                                       FROM GRHDSN.DICISION DD
                                      WHERE DD.MATRICULE = D.MATRICULE)
                             AND D.MATRICULE = P.MATRICULE
                             AND P.POSITION LIKE '1%'
                      UNION
                      SELECT P.MATRICULE,
                               55
                             - TRUNC (
                                    TRUNC (
                                         MONTHS_BETWEEN (SYSDATE, P.DN)
                                       + P.SERVICE)
                                  / 12)
                                AS YEAR,
                             MOD (
                                  720
                                - TRUNC (MONTHS_BETWEEN (SYSDATE, P.DN))
                                - P.SERVICE,
                                12)
                                AS MONTH
                        FROM GRHDSN.PERSONNELS P, GRHDSN.DICISION D
                       WHERE     P.GRADE = '90'
                             AND P.SEX = 'ذكر'
                             AND D.CATEGORIE IN ('1', '2', '3', '4')
                             AND D.D_DICISION =
                                    (SELECT MAX (DD.D_DICISION)
                                       FROM GRHDSN.DICISION DD
                                      WHERE DD.MATRICULE = D.MATRICULE)
                             AND D.MATRICULE = P.MATRICULE
                             AND P.POSITION LIKE '1%'
                      UNION
                      SELECT P.MATRICULE,
                               55
                             - TRUNC (
                                    TRUNC (
                                         MONTHS_BETWEEN (SYSDATE, P.DN)
                                       + P.SERVICE)
                                  / 12)
                                AS YEAR,
                             MOD (
                                  720
                                - TRUNC (MONTHS_BETWEEN (SYSDATE, P.DN))
                                - P.SERVICE,
                                12)
                                AS MONTH
                        FROM GRHDSN.PERSONNELS P, GRHDSN.DICISION D
                       WHERE     P.GRADE = '90'
                             AND P.SEX = 'أنثى'
                             AND D.CATEGORIE IN
                                    ('7',
                                     '8',
                                     '9',
                                     '10',
                                     '11',
                                     '12',
                                     '13',
                                     '14',
                                     '15',
                                     '16',
                                     '17',
                                     'SD1',
                                     'SD2',
                                     'SD3',
                                     'SD4',
                                     'SD5',
                                     'SD6',
                                     'SD7')
                             AND D.D_DICISION =
                                    (SELECT MAX (DD.D_DICISION)
                                       FROM GRHDSN.DICISION DD
                                      WHERE DD.MATRICULE = D.MATRICULE)
                             AND D.MATRICULE = P.MATRICULE
                             AND P.POSITION LIKE '1%'
                      UNION
                      SELECT P.MATRICULE,
                               50
                             - TRUNC (
                                    TRUNC (
                                         MONTHS_BETWEEN (SYSDATE, P.DN)
                                       + P.SERVICE)
                                  / 12)
                                AS YEAR,
                             MOD (
                                  720
                                - TRUNC (MONTHS_BETWEEN (SYSDATE, P.DN))
                                - P.SERVICE,
                                12)
                                AS MONTH
                        FROM GRHDSN.PERSONNELS P, GRHDSN.DICISION D
                       WHERE     P.GRADE = '90'
                             AND P.SEX = 'أنثى'
                             AND D.CATEGORIE IN ('1', '2', '3', '4', '5', '6')
                             AND D.D_DICISION =
                                    (SELECT MAX (DD.D_DICISION)
                                       FROM GRHDSN.DICISION DD
                                      WHERE DD.MATRICULE = D.MATRICULE)
                             AND D.MATRICULE = P.MATRICULE
                             AND P.POSITION LIKE '1%')
            GROUP BY MATRICULE) C,
           GRHDSN.PERSONNELS P
     WHERE C.MATRICULE = P.MATRICULE
     GROUP BY YEAR, P.CSN)
/

