create trigger TRG_GET_ID_MOUVEMENT
    before insert
    on D_MOUVEMENT_GRH
    for each row
BEGIN
    :NEW.ID_MOUVEMENT := GET_ID_MOUVEMENT ( P$CSN_DEPART=>:NEW.CSN_DEPART , 
                                            P$CSN_ARRIVE =>:NEW.CSN_ARRIVE ,
                                            P$TYPE_MUTATION =>:NEW.TYPE_MUTATION ,
                                            P$ANNEE =>:NEW.ANNEE )
                                            ;
    DBMS_OUTPUT.put_line(:NEW.ID_MOUVEMENT);
    IF  :NEW.ID_MOUVEMENT IN ('-1','-500' ) THEN 
         RAISE_APPLICATION_ERROR('-20101', 'Erreur de type_mutation = '||:NEW.TYPE_MUTATION||' Ou csn_arrive = '||:NEW.CSN_ARRIVE||'  Ou csn_depart = '||:NEW.CSN_DEPART||' la personne '||:new.matricule  );
    end if ;
    EXCEPTION
          WHEN OTHERS THEN 
          RAISE_APPLICATION_ERROR('-20500' , :NEW.ID_MOUVEMENT||'  ' ||SQLERRM);
END;
/

