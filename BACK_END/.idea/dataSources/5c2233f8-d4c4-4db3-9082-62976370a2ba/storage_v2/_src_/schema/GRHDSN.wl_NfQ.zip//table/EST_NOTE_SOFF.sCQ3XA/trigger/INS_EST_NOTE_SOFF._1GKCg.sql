create trigger INS_EST_NOTE_SOFF
    before insert
    on EST_NOTE_SOFF
    for each row
DECLARE
   x$user      VARCHAR2 (40);

   CURSOR CUR
   IS
      SELECT CONDITION, MSG, ERR
        FROM GRHDSN.A_CONTROLE_MAJ
       WHERE BLOC = 'EST_NOTE_SOFF';

   x$request   VARCHAR2 (1000);
   x$count     INTEGER;
   x$message   VARCHAR2 (255);
BEGIN
   x$user := SECTION_EN_COURS;

   FOR C IN CUR
   LOOP
      x$request := 'SELECT COUNT(*) FROM DUAL WHERE ' || C.CONDITION;
      x$request :=
         REPLACE (x$request, 'V$FONCTION', '''' || :new.FONCTION || '''');
      x$request := REPLACE (x$request, 'V$UNITE', :new.UNITE);
      x$request := REPLACE (x$request, 'V$MATRICULE', :new.MATRICULE);
      x$request :=
         REPLACE (x$request,
                  'V$D_D_NOTATION',
                  '''' || :new.D_D_NOTATION || '''');
      x$request :=
         REPLACE (x$request,
                  'V$D_F_NOTATION',
                  '''' || :new.D_F_NOTATION || '''');
      x$request := REPLACE (x$request, 'V$CAUSE_NOT', :new.CAUSE_NOT);
      x$request :=
         REPLACE (x$request,
                  'V$AUTRE_CAUSE',
                  '''' || :new.AUTRE_CAUSE || '''');
      x$request := REPLACE (x$request, 'V$PHYSIQUE', :new.PHYSIQUE);
      x$request := REPLACE (x$request, 'V$EDUCATION', :new.EDUCATION);
      x$request := REPLACE (x$request, 'V$APPARENCE', :new.APPARENCE);
      x$request := REPLACE (x$request, 'V$INTILLIGENCE', :new.INTILLIGENCE);
      x$request := REPLACE (x$request, 'V$CONVERSATION', :new.CONVERSATION);
      x$request := REPLACE (x$request, 'V$TRAVAIL', :new.TRAVAIL);
      x$request := REPLACE (x$request, 'V$MAITRISE_SOI', :new.MAITRISE_SOI);
      x$request := REPLACE (x$request, 'V$COMMANDEMENT', :new.COMMANDEMENT);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_PARTICIP', :new.ESPRIT_PARTICIP);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_COLLECT', :new.ESPRIT_COLLECT);
      x$request :=
         REPLACE (x$request, 'V$ESPRIT_DISPLINE', :new.ESPRIT_DISPLINE);
      x$request := REPLACE (x$request, 'V$PREOCCUP_SUB', :new.PREOCCUP_SUB);
      x$request := REPLACE (x$request, 'V$FORMATION_SUB', :new.FORMATION_SUB);
      x$request :=
         REPLACE (x$request, 'V$QUALITEE_INSTRCUT', :new.QUALITEE_INSTRCUT);
      x$request := REPLACE (x$request, 'V$NOTE_FONCTION', :new.NOTE_FONCTION);
      x$request :=
         REPLACE (x$request,
                  'V$AMELIOR_FONCTION',
                  '''' || :new.AMELIOR_FONCTION || '''');
      x$request := REPLACE (x$request, 'V$NOTE_GLOBAL', :new.NOTE_GLOBAL);
      x$request :=
         REPLACE (x$request, 'V$GRADE_SUP', '''' || :new.GRADE_SUP || '''');
      x$request := REPLACE (x$request, 'V$DERNIER_GRADE', :new.DERNIER_GRADE);
      x$request :=
         REPLACE (x$request, 'V$EXP_GRADE', '''' || :new.EXP_GRADE || '''');
      x$request :=
         REPLACE (x$request,
                  'V$DEPASSE_GRADE',
                  '''' || :new.DEPASSE_GRADE || '''');
      x$request :=
         REPLACE (x$request, 'V$DETAIL', '''' || :new.DETAIL || '''');
      x$request := REPLACE (x$request, 'V$APPRECIATION', :new.APPRECIATION);
      x$request := REPLACE (x$request, 'V$CHEF', '''' || :new.CHEF || '''');
      x$request := REPLACE (x$request, 'V$OBS_NOTE', :new.OBS_NOTE);
      x$request :=
         REPLACE (x$request, 'V$OBS_CHEF', '''' || :new.OBS_CHEF || '''');
      x$request :=
         REPLACE (x$request, 'V$CHEF_UNITE', '''' || :new.CHEF_UNITE || '''');

      EXECUTE IMMEDIATE (x$request) INTO x$count;

      IF (x$count > 0)
      THEN
         x$message := C.MSG;
         RAISE_APPLICATION_ERROR (
            '-20101',
            'خطأ رقم : ' || C.ERR || ' : ' || x$message,
            TRUE);
      END IF;
   END LOOP;

   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CHEF_UNITE',
          :old.CHEF_UNITE,
          :new.CHEF_UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'OBS_CHEF',
          :old.OBS_CHEF,
          :new.OBS_CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'OBS_NOTE',
          :old.OBS_NOTE,
          :new.OBS_NOTE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CHEF',
          :old.CHEF,
          :new.CHEF,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'APPRECIATION',
          :old.APPRECIATION,
          :new.APPRECIATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DETAIL',
          :old.DETAIL,
          :new.DETAIL,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DEPASSE_GRADE',
          :old.DEPASSE_GRADE,
          :new.DEPASSE_GRADE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'EXP_GRADE',
          :old.EXP_GRADE,
          :new.EXP_GRADE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'DERNIER_GRADE',
          :old.DERNIER_GRADE,
          :new.DERNIER_GRADE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'GRADE_SUP',
          :old.GRADE_SUP,
          :new.GRADE_SUP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'NOTE_GLOBAL',
          :old.NOTE_GLOBAL,
          :new.NOTE_GLOBAL,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'AMELIOR_FONCTION',
          :old.AMELIOR_FONCTION,
          :new.AMELIOR_FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'NOTE_FONCTION',
          :old.NOTE_FONCTION,
          :new.NOTE_FONCTION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'QUALITEE_INSTRCUT',
          :old.QUALITEE_INSTRCUT,
          :new.QUALITEE_INSTRCUT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'FORMATION_SUB',
          :old.FORMATION_SUB,
          :new.FORMATION_SUB,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'PREOCCUP_SUB',
          :old.PREOCCUP_SUB,
          :new.PREOCCUP_SUB,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_DISPLINE',
          :old.ESPRIT_DISPLINE,
          :new.ESPRIT_DISPLINE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_COLLECT',
          :old.ESPRIT_COLLECT,
          :new.ESPRIT_COLLECT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'ESPRIT_PARTICIP',
          :old.ESPRIT_PARTICIP,
          :new.ESPRIT_PARTICIP,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'COMMANDEMENT',
          :old.COMMANDEMENT,
          :new.COMMANDEMENT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'MAITRISE_SOI',
          :old.MAITRISE_SOI,
          :new.MAITRISE_SOI,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'TRAVAIL',
          :old.TRAVAIL,
          :new.TRAVAIL,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CONVERSATION',
          :old.CONVERSATION,
          :new.CONVERSATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'INTILLIGENCE',
          :old.INTILLIGENCE,
          :new.INTILLIGENCE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'APPARENCE',
          :old.APPARENCE,
          :new.APPARENCE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'EDUCATION',
          :old.EDUCATION,
          :new.EDUCATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'PHYSIQUE',
          :old.PHYSIQUE,
          :new.PHYSIQUE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'AUTRE_CAUSE',
          :old.AUTRE_CAUSE,
          :new.AUTRE_CAUSE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'CAUSE_NOT',
          :old.CAUSE_NOT,
          :new.CAUSE_NOT,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'D_F_NOTATION',
          :old.D_F_NOTATION,
          :new.D_F_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'D_D_NOTATION',
          :old.D_D_NOTATION,
          :new.D_D_NOTATION,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'MATRICULE',
          :old.MATRICULE,
          :new.MATRICULE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'UNITE',
          :old.UNITE,
          :new.UNITE,
          'INS');
   P_CPR (:new.MATRICULE,
          x$user,
          'EST_NOTE_SOFF',
          'FONCTION',
          :old.FONCTION,
          :new.FONCTION,
          'INS');
END;

/* Formatted on 10/09/2020 10:23:59 (QP5 v5.215.12089.38647) */
/

