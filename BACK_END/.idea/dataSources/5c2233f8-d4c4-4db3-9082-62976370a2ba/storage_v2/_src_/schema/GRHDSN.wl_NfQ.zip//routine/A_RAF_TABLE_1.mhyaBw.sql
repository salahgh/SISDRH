create PROCEDURE A_RAF_TABLE_1 ( P$TAB_name VARCHAR2 , P$CSN VARCHAR2 , P$NBR NUMBER ) AS
V$J_TAB_name VARCHAR2(50)  ;
V$COLS LONG  := NULL ;
V$CURSORS_COLS LONG:= NULL;
V_REQ_SELECT LONG ;
V$EXEC LONG;
V$EXIST_COL_CSN BOOLEAN := FALSE;
BEGIN
V$J_TAB_name :=  'J_'||P$TAB_name;

FOR COL IN ( select COL.COLUMN_NAME
             from USER_TAB_COLS COL                                 
             WHERE COL.TABLE_NAME = V$J_TAB_NAME 
             AND  COL.COLUMN_NAME NOT LIKE 'SYS%'
              AND  COL.COLUMN_NAME NOT LIKE '%$$%'
              )
LOOP 
        IF COL.COLUMN_NAME IN ('CSN','CSN_ORIGINE') THEN
            V$EXIST_COL_CSN := TRUE;
        END IF;
         IF COL.COLUMN_NAME NOT IN ('OP','D_OP','RAF','CONDITION_OLD','MV_CSN','N') THEN 
             IF V$COLS IS NULL  THEN          
                   V$COLS := COL.COLUMN_NAME ;
                   V$CURSORS_COLS :='V$CUR.'|| COL.COLUMN_NAME ;
             ELSE
                  V$COLS := V$COLS||','||COL.COLUMN_NAME ;
                   V$CURSORS_COLS := V$CURSORS_COLS ||','||'V$CUR.'|| COL.COLUMN_NAME ;
            END IF;
       END IF;
END LOOP;



V_REQ_SELECT := 'SELECT *
                 FROM (
                         SELECT TAB.*,TAB.ROWID
                         FROM '||V$J_TAB_name||' TAB 
                         WHERE RAF =''N''
                         AND MV_CSN='''||P$CSN||'''
                         ORDER BY D_OP ASC
                       )
                WHERE ROWNUM <= '||P$NBR||' ORDER BY N ASC';
V$EXEC :='declare sql_code varchar2(10) ;
                  sql_errm varchar2(200);
                  ROWIDX ROWID;
            BEGIN    FOR V$CUR IN ( '||V_REQ_SELECT||' )
                   LOOP
                                 BEGIN 

                                    IF V$CUR.CONDITION_OLD IS NOT NULL THEN 
                                           EXECUTE IMMEDIATE ''DELETE FROM GRHDSN.'||P$TAB_name||' WHERE ''||V$CUR.CONDITION_OLD;                                            
                                    END IF;
                                    IF V$CUR.OP =''MAJ'' OR V$CUR.OP =''INS''  THEN 
                                         INSERT INTO GRHDSN.'||P$TAB_name||' ('||V$COLS||') VALUES ('||V$CURSORS_COLS||'); 
                                    END IF;                                          
                                    EXECUTE IMMEDIATE ''UPDATE JGRH.'||V$J_TAB_name||' SET RAF =''''Y''''  WHERE rowid=:1''  USING V$CUR.rowid;
                                    commit;
                                   exception when others then  
                                       ROLLBACK;
                                       sql_code := sqlcode;
                                       sql_errm := SUBSTR(SQLERRM,1,200);
                                       INSERT INTO a_journal_ref_error (    table_name,    j_tab_rowid,    date_err,    sql_code,    sql_errm)
                                                                  VALUES ('''||V$J_TAB_name||''',V$CUR.rowid, sysdate ,sql_code,sql_errm);
                                                                  commit;
                                END;
                   END LOOP; 
                   END ;';
                   --DBMS_OUTPUT.PUT_LINE(V$COLS);
--DBMS_OUTPUT.PUT_LINE(V$CURSORS_COLS);
EXECUTE IMMEDIATE V$EXEC;
            
--DBMS_OUTPUT.PUT_LINE(V$COLS);
--DBMS_OUTPUT.PUT_LINE(V$CURSORS_COLS);
END A_RAF_TABLE_1;
/

