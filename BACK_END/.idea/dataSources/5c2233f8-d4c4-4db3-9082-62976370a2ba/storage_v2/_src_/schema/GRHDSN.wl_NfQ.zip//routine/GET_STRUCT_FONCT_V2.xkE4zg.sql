create FUNCTION        GET_STRUCT_FONCT_V2 (FONCTION IN NUMBER)
   RETURN VARCHAR2
IS
   CURSOR CUR
   IS
      SELECT SS.LIB_STRUCTURE_AR, SS.STRUCTURE
        FROM (SELECT RPAD (SUBSTR (FONCT, 1, LONGUEUR - 1), 13, '0')
                        AS STRUCTURE
                FROM (SELECT RTRIM (
                                DECODE (S.STRUCTURE,
                                        '0180000000000', '0060000000000',
                                        '0110000000000', '0060000000000',
                                        S.STRUCTURE),
                                '0')
                                AS FONCT,
                             LENGTH (RTRIM (S.STRUCTURE, '0')) AS LONGUEUR
                        FROM GRHDSN.R_STRUCT S
                       WHERE S.STRUCTURE = FONCTION AND S.PARENT = '1')) S,
             GRHDSN.R_STRUCT SS
       WHERE S.STRUCTURE = SS.STRUCTURE;

   RESULTAT          VARCHAR2 (1000) := '';
   V$LIB_STRUCTURE   VARCHAR2 (1000) := '';
   V$STRUCTURE       VARCHAR2 (20) := '';
   V$EXIT            VARCHAR (1) := '0';
   V$DEBUT            VARCHAR (1) := '0';
BEGIN
   FOR C IN CUR
   LOOP
      RESULTAT := '/' || C.LIB_STRUCTURE_AR;
      V$LIB_STRUCTURE := C.LIB_STRUCTURE_AR;
      V$STRUCTURE := C.STRUCTURE;

      WHILE V$EXIT = '0'
      LOOP
         DBMS_OUTPUT.PUT_LINE (V$STRUCTURE);
         V$LIB_STRUCTURE := GRHDSN.GET_STRUCT_FONCT_ (V$STRUCTURE);
         IF V$DEBUT != '0' THEN
            RESULTAT := RESULTAT || V$LIB_STRUCTURE;
         ELSE
            V$DEBUT := '1';
         END IF;
         V$STRUCTURE :=
            RPAD (
               SUBSTR (RTRIM (V$STRUCTURE, '0'),
                       1,
                       LENGTH (RTRIM (V$STRUCTURE, '0')) - 1),
               13,
               '0');

         IF (   V$LIB_STRUCTURE LIKE '%مركز الخدمة%'
             OR V$LIB_STRUCTURE LIKE '%مديرية%فرعية%'
             OR V$LIB_STRUCTURE LIKE
                   '%مركز الإقليمي للخدمة الوطنية%'
             OR V$LIB_STRUCTURE LIKE '%مكتب%خدمة%وطنية%'
             OR V$LIB_STRUCTURE LIKE '%مديرية%الخدمة%الوطنية%'
             OR V$LIB_STRUCTURE LIKE '%مفتشية%الخدمة%الوطنية%'
             OR V$LIB_STRUCTURE LIKE '%مديرية%جهوية%خدمة%')
         THEN
            V$EXIT := '1';
         END IF;
      END LOOP;
   END LOOP;

   RETURN RESULTAT;
END;
/

