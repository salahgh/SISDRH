create view BILAN_SIT_ENS_GRADE as
SELECT LIB_GRADE_AR AS GRADE,
          "0",
          "سنة",
          "سنتان",
          "3 سنوات",
          "4 سنوات",
          "5 سنوات",
          "6 سنوات",
          "7 سنوات",
          "8 سنوات",
          "9 سنوات",
          "10 سنوات",
          "11 سنة",
          "12 سنة",
          "13 سنة",
          "14 سنة",
          "15 سنة",
          "16 سنة",
          "17 سنة",
          "18 سنة",
          "19 سنة"
     FROM (  SELECT G.LIB_GRADE_AR, S.*
               FROM (SELECT *
                       FROM (SELECT P.MATRICULE,
                                    P.GRADE,
                                    2022 - TO_CHAR (N.D_NOMIN, 'YYYY') AS ENS
                               FROM GRHDSN.PERSONNELS P, GRHDSN.EST_NOMINER_G N
                              WHERE    P.MATRICULE = N.MATRICULE --AND P.MATRICULE NOT IN
                                     --       ('200429000802', '199838003502')
                                        AND P.POSITION LIKE '1%'
                                       AND P.GRADE BETWEEN 1 AND 59
                                       AND N.D_NOMIN =
                                              (SELECT MAX (NN.D_NOMIN)
                                                 FROM GRHDSN.EST_NOMINER_G NN
                                                WHERE N.MATRICULE =
                                                         NN.MATRICULE)) PIVOT (COUNT (
                                                                                  MATRICULE)
                                                                        FOR ENS
                                                                        IN  ('0' AS "0",
                                                                            '1' AS "سنة",
                                                                            '2' AS "سنتان",
                                                                            '3' AS "3 سنوات",
                                                                            '4' AS "4 سنوات",
                                                                            '5' AS "5 سنوات",
                                                                            '6' AS "6 سنوات",
                                                                            '7' AS "7 سنوات",
                                                                            '8' AS "8 سنوات",
                                                                            '9' AS "9 سنوات",
                                                                            '10' AS "10 سنوات",
                                                                            '11' AS "11 سنة",
                                                                            '12' AS "12 سنة",
                                                                            '13' AS "13 سنة",
                                                                            '14' AS "14 سنة",
                                                                            '15' AS "15 سنة",
                                                                            '16' AS "16 سنة",
                                                                            '17' AS "17 سنة",
                                                                            '18' AS "18 سنة",
                                                                            '19' AS "19 سنة"))) S,
                    GRHDSN.R_GRADE G
              WHERE G.GRADE = S.GRADE
           ORDER BY G.GRADE)
/

